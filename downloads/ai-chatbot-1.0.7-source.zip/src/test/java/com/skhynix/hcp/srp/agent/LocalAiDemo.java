package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;

/** Standalone loopback-only demo. Test classes are excluded from the application WAR. */
public final class LocalAiDemo {
    private static final String DEMO_TOKEN = "synthetic-browser-test-value-0001";
    private static final String OTHER_TOKEN = "synthetic-browser-other-value-0001";
    private static final String HELPER_OPEN = "/fixture/open";
    private static final String HELPER_CLOSE = "/fixture/close";
    private final boolean evidence;
    private final boolean persistent;
    private final ObjectMapper json = new ObjectMapper();
    private final Map<String, Integer> sessions = new ConcurrentHashMap<>();
    private final Map<String, Receipt> replies = new ConcurrentHashMap<>();

    private record Operation(String path, String actor, String session, String content, String visibility) {}
    private record Receipt(Operation operation, Object value) {}

    private LocalAiDemo(boolean evidence, boolean persistent) {
        this.evidence = evidence;
        this.persistent = persistent;
    }

    public static void main(String[] args) throws Exception {
        boolean persistent = args.length == 1 && "--isolated-db".equals(args[0]);
        if (args.length != 0 && !persistent) throw new IllegalArgumentException("Unsupported demo mode.");
        new LocalAiDemo(false, persistent).run();
    }

    private void run() throws Exception {
        var ai = startHelper();
        var evidenceAi = new LocalAiDemo(true, persistent).startHelper();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            ai.stop(0);
            evidenceAi.stop(0);
        }));
        try {
            URI apiOrigin = URI.create("http://127.0.0.1:" + ai.getAddress().getPort());
            var helper = new AiHelperHttpClient(json, apiOrigin, "", HELPER_OPEN, HELPER_CLOSE);
            URI evidenceOrigin = URI.create("http://127.0.0.1:" + evidenceAi.getAddress().getPort());
            var evidenceHelper = new AiHelperHttpClient(json, evidenceOrigin, "", HELPER_OPEN, HELPER_CLOSE);
            var tokens = Map.of("DEMO", DEMO_TOKEN, "DEMO2", OTHER_TOKEN);
            ChatServlet servlet;
            if (persistent) {
                String jdbc = System.getenv("SOL_PROFILE_DB_URL");
                if (jdbc == null || !jdbc.matches("jdbc:postgresql://127\\.0\\.0\\.1:(?!5432/)[1-9][0-9]{3,4}/db")) {
                    throw new IllegalArgumentException("The persistent demo requires its dedicated loopback DB.");
                }
                String password = System.getenv("SOL_PROFILE_DB_PASSWORD");
                if (password == null || password.isEmpty()) throw new IllegalArgumentException("Missing profile credential.");
                var store = new PostgresChatStore(jdbc, "admin", password, json, helper, "fixture");
                var evidenceStore = new com.skhynix.hcp.srp.agent.ai.AiEvidenceReviewChat(
                        jdbc, "admin", password, json, evidenceHelper::openSession, "fixture-evidence");
                store.initializeSchema();
                evidenceStore.initializeSchema();
                servlet = new ChatServlet(json, store, helper, tokens, store::ordered, evidenceStore, evidenceHelper);
            } else {
                var sequence = new java.util.concurrent.atomic.AtomicLong();
                var store = new MemoryChatStore(helper, sequence);
                var evidenceStore = new MemoryChatStore(evidenceHelper, sequence);
                servlet = new ChatServlet(json, store, helper, tokens, store::ordered, evidenceStore, evidenceHelper);
            }
            try (var app = AiChatApplication.start(servlet, 0)) {
                var server = (ServletWebServerApplicationContext) app;
                server.getServletContext().setAttribute("localDemoToken", DEMO_TOKEN);
                server.getServletContext().setAttribute("localDemoPersistent", persistent);
                System.out.println("Chat demo: http://127.0.0.1:" + server.getWebServer().getPort() + "/");
                System.out.println("Local review mock AI API: " + apiOrigin);
                System.out.println("Local evidence mock AI API: " + evidenceOrigin);
                new CountDownLatch(1).await();
            }
        } finally {
            ai.stop(0);
            evidenceAi.stop(0);
        }
    }

    private HttpServer startHelper() throws IOException {
        var server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 8);
        server.createContext("/", this::handle);
        server.start();
        return server;
    }

    private void handle(HttpExchange exchange) throws IOException {
        try (exchange) {
            if (!"POST".equals(exchange.getRequestMethod())) {
                respond(exchange, 405, Map.of("error", "Use POST."));
                return;
            }
            JsonNode data;
            try {
                byte[] body = exchange.getRequestBody().readNBytes(65_537);
                if (body.length > 65_536) {
                    respond(exchange, 413, Map.of("error", "Request is too large."));
                    return;
                }
                data = json.readTree(body);
            } catch (IOException malformed) {
                respond(exchange, 400, Map.of("error", "Expected JSON."));
                return;
            }
            if (data == null || !java.util.Set.of("DEMO", "DEMO2").contains(data.path("emp_no").asText())) {
                respond(exchange, 400, Map.of("error", "Expected the synthetic demo actor."));
                return;
            }
            String path = exchange.getRequestURI().getPath();
            String key = exchange.getRequestHeaders().getFirst("Idempotency-Key");
            if (key == null || !key.matches("[a-f0-9]{64}")) {
                respond(exchange, 400, Map.of("error", "Expected an idempotency key."));
                return;
            }
            String id = data.path("session_id").asText();
            var operation = new Operation(path, data.path("emp_no").asText(), id,
                    data.path("message").asText(), data.path("visibility").asText());
            Receipt previous = replies.get(key);
            if (previous != null) {
                boolean same = previous.operation.equals(operation);
                respond(exchange, same ? 200 : 409,
                        same ? previous.value : Map.of("error", "Idempotency key used for a different request."));
                return;
            }
            if (HELPER_OPEN.equals(path)) {
                String newId = sessionPrefix(operation.actor) + UUID.randomUUID();
                sessions.put(newId, 0);
                commit(exchange, key, operation, Map.of("session_id", newId));
                return;
            }
            if (persistent && id.startsWith(sessionPrefix(operation.actor))
                    && id.substring(sessionPrefix(operation.actor).length()).matches("[a-f0-9-]{36}")) {
                sessions.putIfAbsent(id, 0);
            }
            if (!id.startsWith(sessionPrefix(operation.actor)) || !sessions.containsKey(id)) {
                respond(exchange, 404, Map.of("error", "Unknown demo session."));
                return;
            }
            switch (path) {
                case "/api/v1/sr/helper/message" -> reply(exchange, key, operation, data);
                case "/api/v1/sr/helper/complete" -> {
                    sessions.remove(id);
                    commit(exchange, key, operation, Map.of("draft", evidence
                            ? Map.of("summary", "가상 증적 요약: 조회 기록 예시는 제공됐습니다. 기록 생성 시간과 보관 기간을 추가로 확인해 주세요.")
                            : Map.of(
                            "title", "사내 문서 검색 기능 보안성 검토",
                            "description", "가상 요청입니다. 원본 문서의 접근 권한을 검색 결과에 적용하고, "
                                    + "권한 없는 문서는 검색 결과에서 제외합니다. 검색과 문서 열람 이력을 감사 로그에 기록합니다.")));
                }
                case HELPER_CLOSE -> {
                    sessions.remove(id);
                    commit(exchange, key, operation, Map.of());
                }
                default -> respond(exchange, 404, Map.of("error", "Unknown demo endpoint."));
            }
        }
    }

    private String sessionPrefix(String actor) {
        return (evidence ? "evidence-" : "security-") + actor + "-";
    }

    private void reply(HttpExchange exchange, String key, Operation operation, JsonNode request) throws IOException {
        String message = request.path("message").asText();
        if (message.isBlank() || !request.hasNonNull("visibility") || !request.hasNonNull("sent_at")) {
            respond(exchange, 400, Map.of("error", "Expected a message and context."));
            return;
        }
        int turn = sessions.merge(operation.session, 1, Integer::sum);
        String response = turn == 1
                ? "가상 보안 검토입니다. 검색 결과에는 원본 문서에서 열람 권한이 있는 항목만 포함할 예정인가요?"
                : "가상 검토 초안에 문서 권한 확인과 검색·열람 감사 로그를 포함하겠습니다. 작업 완료를 누르면 내용을 검토하고 수정할 수 있습니다.";
        if (evidence) {
            response = turn == 1
                    ? "가상 증적을 확인했습니다. 조회 기록의 생성 시간과 보관 기간이 있나요?"
                    : "예시 증적에서 확인할 항목을 가상 요약에 정리하겠습니다.";
        }
        commit(exchange, key, operation, Map.of("message", response, "sent_at", Instant.now().toString()));
    }

    private void commit(HttpExchange exchange, String key, Operation operation, Object value) throws IOException {
        String path = exchange.getRequestURI().getPath();
        if (path.equals(AiHelperHttpClient.MESSAGE_PATH) || path.equals(AiHelperHttpClient.COMPLETE_PATH)) {
            value = Map.of("responseAt", Instant.now().toString(), "message", "OK", "data", value);
        }
        replies.put(key, new Receipt(operation, value));
        respond(exchange, 200, value);
    }

    private void respond(HttpExchange exchange, int status, Object value) throws IOException {
        byte[] response = json.writeValueAsBytes(value);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, response.length);
        exchange.getResponseBody().write(response);
    }
}
