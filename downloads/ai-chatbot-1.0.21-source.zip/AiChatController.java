package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.ibatis.exceptions.PersistenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.LinkedHashMap;
import java.util.function.BiFunction;
import java.util.function.Supplier;

@RestController
@RequestMapping("/aiChat")
public class AiChatController {
    private static final String BASE_PATH = "/aiChat";
    static final String PORTAL_CHAT2_SEND_PATH = "/chat2/send";
    static final String CHAT2_SEND_PATH = "/api/ai-agent/chat2/send";
    private static final Logger LOG = LoggerFactory.getLogger(AiChatController.class);
    private static final int MAX_REQUEST = 1024 * 1024;

    private final ObjectMapper json;
    private final Environment env;
    private volatile Backend backend;

    @Autowired
    public AiChatController(Environment env) {
        this.env = env;
        this.json = new ObjectMapper();
    }

    AiChatController(ObjectMapper json, AiApiService store, AiApiService.ClosingHelperClient helper,
                     Map<String, String> tokens, BiFunction<String, Supplier<Object>, Object> ordered) {
        this(json, store, helper, tokens, ordered, null, null);
    }

    AiChatController(ObjectMapper json, AiApiService store, AiApiService.ClosingHelperClient helper,
                     Map<String, String> tokens, BiFunction<String, Supplier<Object>, Object> ordered,
                     AiApiService evidenceStore, AiApiService.ClosingHelperClient evidenceHelper) {
        this.env = null;
        this.json = json;
        this.backend = new Backend(store, helper, ordered, tokens, evidenceStore, evidenceHelper);
    }

    private record Backend(AiApiService store, AiApiService.ClosingHelperClient helper,
                           BiFunction<String, Supplier<Object>, Object> ordered, Map<String, String> tokens,
                           AiApiService evidenceStore, AiApiService.ClosingHelperClient evidenceHelper) {
        Backend {
            tokens = Map.copyOf(tokens);
            if (new HashSet<>(tokens.values()).size() != tokens.size()
                    || tokens.entrySet().stream().anyMatch(e -> e.getKey().isBlank() || e.getValue().length() < 32
                    || e.getValue().chars().anyMatch(c -> c <= 32 || c >= 127))) {
                throw new IllegalArgumentException("Configure distinct employee bearer tokens of at least 32 ASCII characters.");
            }
        }
    }

    private Backend backend() throws IOException {
        Backend current = backend;
        return current != null ? current : initializeBackend();
    }

    private synchronized Backend initializeBackend() throws IOException {
        if (backend == null) {
            var helper = new AiHelperHttpClient(json, URI.create(env.getRequiredProperty("AI_BASE_URL")),
                    env.getProperty("AI_TOKEN", ""), env.getRequiredProperty("AI_OPEN_PATH"),
                    env.getRequiredProperty("AI_CLOSE_PATH"));
            var store = new PostgresChatStore(env.getRequiredProperty("CHAT_DB_URL"),
                    env.getRequiredProperty("CHAT_DB_USER"), env.getProperty("CHAT_DB_PASSWORD", ""),
                    json, helper, env.getRequiredProperty("AI_VISIBILITY"));
            var tokens = json.readValue(env.getProperty("CHAT_USER_TOKENS_JSON", "{}"),
                    new TypeReference<Map<String, String>>() {});
            backend = new Backend(store, helper, store::ordered, tokens, null, null);
        }
        return backend;
    }

    @PostMapping("/chat/start")
    public void startChat(HttpServletRequest request, HttpServletResponse response) throws IOException {
        execute(request, response, "/chat/start");
    }

    @PostMapping({"/chat/send", CHAT2_SEND_PATH, PORTAL_CHAT2_SEND_PATH})
    public void sendMessage(HttpServletRequest request, HttpServletResponse response) throws IOException {
        execute(request, response, CHAT2_SEND_PATH);
    }

    @PostMapping({"/chat/list", "/chat/history", "/chat/select", "/chat/continue", "/chat/end"})
    public void chat(HttpServletRequest request, HttpServletResponse response) throws IOException {
        execute(request, response, requestPath(request));
    }

    private static String requestPath(HttpServletRequest request) {
        return request.getRequestURI().substring(request.getContextPath().length() + BASE_PATH.length());
    }

    private static void responseHeaders(HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Content-Security-Policy",
                "default-src 'self'; frame-ancestors 'none'; style-src 'self' 'unsafe-inline'");
    }

    private void execute(HttpServletRequest request, HttpServletResponse response, String route) throws IOException {
        responseHeaders(response);
        Backend current;
        try {
            current = backend();
        } catch (IOException | IllegalArgumentException | IllegalStateException | PersistenceException e) {
            LOG.warn("Chat initialization failed ({}). Check chat settings and mapper resources.",
                    e.getClass().getSimpleName());
            respond(response, 503, Map.of("error", "Chat service configuration is unavailable."));
            return;
        }
        Map<String, String> tokens = current.tokens();
        String actor = authenticate(request, tokens);
        if (actor == null) {
            if (!tokens.isEmpty()) response.setHeader("WWW-Authenticate", "Bearer");
            respond(response, 401, Map.of("error", "Authentication required."));
            return;
        }
        if (request.getUserPrincipal() != null && !isJson(request.getContentType())) {
            respond(response, 415, Map.of("error", "Use application/json."));
            return;
        }
        Object result;
        try {
            byte[] body = request.getInputStream().readNBytes(MAX_REQUEST + 1);
            if (body.length > MAX_REQUEST) {
                respond(response, 413, Map.of("error", "Request is too large."));
                return;
            }
            JsonNode input = json.readTree(body);
            if (input == null || !input.isObject()) throw new IllegalArgumentException("Expected a JSON object.");
            String type = text(input, "review_type");
            if (!type.isEmpty() && !"security".equals(type) && !"evidence".equals(type)) {
                throw new IllegalArgumentException("Unknown review type.");
            }
            boolean evidence = "evidence".equals(type);
            if (evidence && current.evidenceStore() == null) {
                throw new IllegalStateException("Security evidence review is unavailable in this deployment.");
            }
            var chatService = new AiChatService(() -> actor,
                    evidence ? current.evidenceStore() : current.store(),
                    evidence ? current.evidenceHelper() : current.helper(),
                    draft -> {
                        var verified = draftFields(draft, evidence);
                        if (verified.isEmpty()) {
                            throw new AiHelperHttpClient.HelperFailure("AI draft has no valid fields.");
                        }
                        return verified;
                    });
            result = current.ordered().apply(actor, () -> dispatch(chatService, route, input, evidence));
        } catch (NoSuchElementException e) {
            respond(response, 404, Map.of("error", e.getMessage()));
            return;
        } catch (IllegalArgumentException | com.fasterxml.jackson.core.JsonProcessingException e) {
            respond(response, 400, Map.of("error", "Invalid chat request."));
            return;
        } catch (AiHelperHttpClient.HelperFailure e) {
            respond(response, e.status, Map.of("error", e.getMessage()));
            return;
        } catch (PersistenceException e) {
            System.err.println("Chat database operation failed: " + e.getClass().getSimpleName());
            respond(response, 500, Map.of("error", "Chat database operation failed."));
            return;
        } catch (IllegalStateException e) {
            respond(response, 409, Map.of("error", e.getMessage()));
            return;
        }
        respond(response, 200, result);
    }

    private Object dispatch(AiChatService chatService, String path, JsonNode input, boolean evidence) {
        if ("/chat/start".equals(path)) {
            String room = chatService.startChat();
            return Map.of("room_index", room, "has_open_chat", room.isEmpty() ? "F" : "T");
        }
        if ("/chat/list".equals(path)) {
            return chatService.listRooms(index(input, "before_room_index"), (int) integer(input, "limit", 30, 100));
        }
        String room = index(input, "room_index");
        return switch (path) {
            case "/chat/history", "/chat/select" -> chatService.readRoom(room,
                    integer(input, "afterSeq", 0, Long.MAX_VALUE), (int) integer(input, "limit", 50, 200),
                    "/chat/select".equals(path));
            case "/chat/continue" -> chatService.continueChat(room, text(input, "status"),
                    integer(input, "afterSeq", 0, Long.MAX_VALUE), (int) integer(input, "limit", 50, 200));
            case CHAT2_SEND_PATH -> {
                if (!"S".equals(text(input, "type"))) {
                    throw new IllegalArgumentException("type must be S.");
                }
                yield chatService.sendMessage(room, text(input, "chat_index"), text(input, "message"));
            }
            case "/chat/end" -> localDraft(chatService.endChat(room, text(input, "type")), evidence);
            default -> throw new NoSuchElementException("Unknown chat route.");
        };
    }

    private AiApiService.ChatEnd localDraft(AiApiService.ChatEnd end, boolean evidence) {
        if (end.status != AiApiService.ChatEndStatus.COMPLETED) return end;
        return new AiApiService.ChatEnd(end.room_index, end.status, draftFields(end.draft, evidence));
    }

    private Map<String, String> draftFields(Object value, boolean evidence) {
        JsonNode draft = json.valueToTree(value);
        var verified = new LinkedHashMap<String, String>();
        if (evidence) {
            copyField(draft, verified, "summary", 2000);
        } else {
            copyField(draft, verified, "title", 120);
            copyField(draft, verified, "description", 2000);
        }
        return verified;
    }

    private static void copyField(JsonNode draft, Map<String, String> verified, String key, int maxLength) {
        JsonNode field = draft.path(key);
        if (!field.isTextual()) return;
        String value = field.textValue().strip();
        if (!value.isEmpty() && value.length() <= maxLength
                && value.chars().noneMatch(c -> Character.isISOControl(c) && c != '\n' && c != '\t')
                && (!"title".equals(key) || value.chars().noneMatch(Character::isISOControl))) {
            verified.put(key, value);
        }
    }

    private static boolean isJson(String contentType) {
        return contentType != null
                && "application/json".equalsIgnoreCase(contentType.split(";", 2)[0].trim());
    }

    private static String authenticate(HttpServletRequest request, Map<String, String> tokens) {
        var principal = request.getUserPrincipal();
        if (principal != null && principal.getName() != null && !principal.getName().isBlank()) {
            return principal.getName();
        }
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) return null;
        byte[] supplied = header.substring(7).getBytes(StandardCharsets.UTF_8);
        for (var token : tokens.entrySet()) {
            if (MessageDigest.isEqual(token.getValue().getBytes(StandardCharsets.UTF_8), supplied)) {
                return token.getKey();
            }
        }
        return null;
    }

    private void respond(HttpServletResponse response, int status, Object value) throws IOException {
        byte[] body = json.writeValueAsBytes(value);
        response.setHeader("Content-Type", "application/json; charset=utf-8");
        response.setStatus(status);
        response.setContentLength(body.length);
        response.getOutputStream().write(body);
    }

    private static String text(JsonNode input, String field) {
        JsonNode value = input.get(field);
        if (value == null || value.isNull()) return "";
        if (!value.isTextual()) throw new IllegalArgumentException("Expected string.");
        return value.textValue();
    }

    private static String index(JsonNode input, String field) {
        String value = text(input, field);
        if (!value.isEmpty()) {
            if (!value.matches("[1-9][0-9]{0,18}")) throw new IllegalArgumentException("Invalid room index.");
            Long.parseLong(value);
        }
        return value;
    }

    private static long integer(JsonNode input, String field, long fallback, long max) {
        JsonNode value = input.get(field);
        if (value == null) return fallback;
        if (!value.isIntegralNumber() || !value.canConvertToLong() || value.longValue() < 0 || value.longValue() > max) {
            throw new IllegalArgumentException("Invalid paging number.");
        }
        return value.longValue();
    }

}
