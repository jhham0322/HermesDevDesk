$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    $env:JAVA_HOME = Join-Path $env:USERPROFILE '.jdk\jdk-21.0.11'
    $java = Join-Path $env:JAVA_HOME 'bin\java.exe'
    & 'C:\tools\apache-maven-3.9.6\bin\mvn.cmd' -B -ntp -o verify
    if ($LASTEXITCODE -ne 0) { throw 'Could not build the local demo.' }
    & $java '-Dspring.config.location=optional:classpath:/' `
        '-Dlogging.level.org.apache.tomcat.util.http.parser.Cookie=OFF' `
        '-Dloader.path=target/test-classes,WEB-INF/classes,WEB-INF/lib' `
        '-Dloader.main=com.skhynix.hcp.srp.agent.LocalAiDemo' `
        -cp target/ai-chatbot-1.0.11.war org.springframework.boot.loader.launch.PropertiesLauncher
    if ($LASTEXITCODE -ne 0) { throw 'Local demo stopped with an error.' }
} finally {
    Pop-Location
}
