package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.IOException;
import java.net.URI;
import java.util.Map;


@SpringBootApplication(proxyBeanMethods = false)
public class AiChatApplication {
    public static void main(String[] args) throws IOException {
        Map<String, String> env = System.getenv();
        var json = new ObjectMapper();
        URI origin = URI.create(required(env, "AI_BASE_URL"));
        if (!"127.0.0.1".equals(origin.getHost()) && !"localhost".equals(origin.getHost())) {
            throw new IllegalArgumentException("Phase 1 requires a local AI fixture.");
        }
        var helper = new AiHelperHttpClient(json, origin, env.getOrDefault("AI_TOKEN", ""),
                required(env, "AI_OPEN_PATH"), required(env, "AI_CLOSE_PATH"));
        String jdbc = required(env, "CHAT_DB_URL");
        validateLocalDatabase(jdbc);
        var store = new PostgresChatStore(jdbc, required(env, "CHAT_DB_USER"),
                env.getOrDefault("CHAT_DB_PASSWORD", ""), json, helper, required(env, "AI_VISIBILITY"));
        var tokens = json.readValue(required(env, "CHAT_USER_TOKENS_JSON"), new TypeReference<Map<String, String>>() {});
        var servlet = new ChatServlet(json, store, helper, tokens, store::ordered);
        if ("true".equalsIgnoreCase(env.get("CHAT_INIT_SCHEMA"))) store.initializeSchema();
        start(servlet, Integer.parseInt(env.getOrDefault("CHAT_PORT", "8080")));
    }

    static ConfigurableApplicationContext start(ChatServlet servlet, int port) {
        var app = new SpringApplication(AiChatApplication.class);
        app.addInitializers(ctx -> ctx.getBeanFactory().registerSingleton("chatServletRegistration",
                AiChatServletConfiguration.registration(servlet, true)));
        return app.run("--server.address=127.0.0.1", "--server.port=" + port,
                "--spring.web.resources.add-mappings=false");
    }

    static void validateLocalDatabase(String jdbc) {
        if (!jdbc.matches("^jdbc:postgresql://(?:127\\.0\\.0\\.1|localhost)(?::[0-9]+)?/[^?,/]+(?:\\?.*)?$")) {
            throw new IllegalArgumentException("Use a dedicated local PostgreSQL URL.");
        }
    }

    private static String required(Map<String, String> values, String key) {
        String value = values.get(key);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing environment variable " + key + ".");
        return value;
    }
}
