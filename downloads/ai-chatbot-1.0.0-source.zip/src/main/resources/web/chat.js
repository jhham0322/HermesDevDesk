"use strict";

const byId = id => document.getElementById(id);
const tokenInput = byId("token");
const messageInput = byId("message");
const messages = byId("messages");
const status = byId("status");
let token = "";
let room = "";
let pending = null;
let busy = false;

async function post(path, body) {
    const response = await fetch("/chat/" + path, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
        body: JSON.stringify(body)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "요청에 실패했습니다.");
    return result;
}

async function run(action) {
    if (busy) return;
    busy = true;
    const controls = [...document.querySelectorAll("button, textarea")].filter(control => !control.disabled);
    controls.forEach(control => { control.disabled = true; });
    status.textContent = "처리 중…";
    try {
        await action();
        if (status.textContent === "처리 중…") status.textContent = "";
    } catch (error) {
        status.textContent = error.message;
    } finally {
        controls.forEach(control => { control.disabled = false; });
        if (!room || !byId("choice").hidden) {
            byId("send").hidden = true;
            byId("complete").hidden = byId("cancel").hidden = true;
        }
        busy = false;
    }
}

function append(author, text) {
    const entry = document.createElement("li");
    entry.textContent = author + " · " + (text ?? "");
    messages.append(entry);
    messages.scrollTop = messages.scrollHeight;
}

async function openChat(mode) {
    let afterSeq = 0;
    const history = [];
    while (true) {
        const page = await post("continue", { room_index: room, status: mode, afterSeq, limit: 100 });
        room = page.room_index;
        const batch = page.messages || [];
        history.push(...batch);
        if (batch.length < 100) break;
        afterSeq = Number(batch[batch.length - 1].chat_index);
        if (!Number.isSafeInteger(afterSeq)) throw new Error("메시지 순번을 읽을 수 없습니다.");
    }
    messages.replaceChildren();
    for (const entry of history) append(entry.isbot === "Y" ? "AI" : "나", entry.message);
    pending = null;
    byId("draft").hidden = true;
    byId("choice").hidden = true;
    byId("chat").hidden = false;
    byId("send").hidden = false;
    byId("complete").hidden = byId("cancel").hidden = false;
}

byId("access").addEventListener("submit", event => {
    event.preventDefault();
    run(async () => {
        token = tokenInput.value;
        byId("chat").hidden = true;
        byId("choice").hidden = true;
        const result = await post("start", {});
        tokenInput.value = "";
        room = result.room_index;
        if (room) byId("choice").hidden = false;
        else await openChat("N");
    });
});

byId("resume").addEventListener("click", () => run(() => openChat("R")));
byId("reset").addEventListener("click", () => run(() => openChat("N")));
byId("send").addEventListener("submit", event => {
    event.preventDefault();
    const content = messageInput.value;
    if (!content.trim()) return;
    run(async () => {
        if (!pending || pending.content !== content) pending = { id: crypto.randomUUID(), content };
        const reply = await post("send", { room_index: room, type: "S", message: content, chat_index: pending.id });
        append("나", content);
        append("AI", reply.message);
        if (reply.references?.length) append("참고", JSON.stringify(reply.references));
        pending = null;
        messageInput.value = "";
    });
});

function finish(type) {
    return run(async () => {
        const result = await post("end", { room_index: room, type });
        status.textContent = type === "C" ? "작업이 완료됐습니다." : "채팅을 취소했습니다.";
        if (type === "C") {
            byId("draft").textContent = typeof result.draft === "string" ? result.draft : JSON.stringify(result.draft, null, 2);
            byId("draft").hidden = false;
        }
        room = "";
        pending = null;
    });
}

byId("complete").addEventListener("click", () => finish("C"));
byId("cancel").addEventListener("click", () => finish("X"));
