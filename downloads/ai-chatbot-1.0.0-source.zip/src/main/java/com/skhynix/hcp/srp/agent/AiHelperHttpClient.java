package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;

final class AiHelperHttpClient implements AiApiService.ClosingHelperClient {
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final ObjectMapper json;
    private final URI origin;
    private final String token;
    private final String openPath;
    private final String closePath;

    AiHelperHttpClient(ObjectMapper json, URI origin, String token, String openPath, String closePath) {
        this.json = json;
        this.origin = origin;
        this.token = token;
        this.openPath = openPath;
        this.closePath = closePath;
        if (!"https".equals(origin.getScheme()) && !("http".equals(origin.getScheme())
                && ("127.0.0.1".equals(origin.getHost()) || "localhost".equals(origin.getHost())))) {
            throw new IllegalArgumentException("AI_BASE_URL must use HTTPS or local HTTP.");
        }
        endpoint(openPath);
        endpoint(closePath);
    }

    String openSession(String actor, String visibility) {
        return requiredText(post(openPath, Map.of("emp_no", actor, "visibility", visibility)), "session_id");
    }

    @Override public AiApiService.HelperResponse postMessage(AiApiService.HelperRequest request) {
        JsonNode result = post("/api/v1/sr/helper/message", request);
        JsonNode references = result.get("references");
        if (references != null && !references.isNull() && !references.isArray()) {
            throw new HelperFailure("Invalid AI references payload.");
        }
        List<?> items = references == null || references.isNull() ? List.of() : json.convertValue(references, List.class);
        String sentAt = requiredText(result, "sent_at");
        try {
            sentAt = OffsetDateTime.parse(sentAt).toInstant().toString();
        } catch (DateTimeParseException e) {
            throw new HelperFailure("AI helper returned an invalid sent_at value.");
        }
        return new AiApiService.HelperResponse(requiredText(result, "message"), sentAt, items);
    }

    @Override public Object complete(String session, String actor) {
        JsonNode draft = post("/api/v1/sr/helper/complete", Map.of("session_id", session, "emp_no", actor)).get("draft");
        if (draft == null || draft.isNull()) throw new HelperFailure("AI helper did not return a draft.");
        return draft;
    }

    @Override public void closeSession(String session, String actor) {
        post(closePath, Map.of("session_id", session, "emp_no", actor));
    }

    private URI endpoint(String path) {
        if (!path.startsWith("/") || path.startsWith("//") || path.indexOf('\\') >= 0) {
            throw new IllegalArgumentException("AI endpoint must be an absolute path on AI_BASE_URL.");
        }
        return origin.resolve(path);
    }

    private JsonNode post(String path, Object payload) {
        try {
            HttpRequest.Builder request = HttpRequest.newBuilder(endpoint(path)).timeout(Duration.ofSeconds(60))
                    .header("Content-Type", "application/json").header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofByteArray(json.writeValueAsBytes(payload)));
            if (!token.isEmpty()) request.header("Authorization", "Bearer " + token);
            HttpResponse<byte[]> response = client.send(request.build(), HttpResponse.BodyHandlers.ofByteArray());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new HelperFailure("AI helper returned HTTP " + response.statusCode() + ".");
            }
            if (response.body().length == 0) return json.createObjectNode();
            JsonNode result = json.readTree(response.body());
            if (result == null || !result.isObject()) throw new HelperFailure("Invalid AI response.");
            return result;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new HelperFailure("AI request was interrupted.");
        } catch (IOException e) {
            throw new HelperFailure("AI helper request failed.");
        }
    }

    private static String requiredText(JsonNode node, String field) {
        JsonNode value = node.get(field);
        if (value == null || !value.isTextual() || value.textValue().isBlank()) {
            throw new HelperFailure("AI helper response is missing " + field + ".");
        }
        return value.textValue();
    }

    static final class HelperFailure extends RuntimeException {
        HelperFailure(String message) { super(message); }
    }
}
