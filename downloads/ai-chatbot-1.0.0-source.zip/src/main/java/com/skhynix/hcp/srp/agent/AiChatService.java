package com.skhynix.hcp.srp.agent;

import java.time.Instant;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;

public final class AiChatService {
    private final Supplier<String> currentEmpNo;
    private final AiApiService aiService;
    private final AiApiService.HelperClient helperClient;

    public AiChatService(Supplier<String> currentEmpNo, AiApiService aiService) {
        this(currentEmpNo, aiService, null);
    }

    public AiChatService(Supplier<String> currentEmpNo, AiApiService aiService,
                         AiApiService.HelperClient helperClient) {
        this.currentEmpNo = Objects.requireNonNull(currentEmpNo, "currentEmpNo");
        this.aiService = Objects.requireNonNull(aiService, "aiService");
        this.helperClient = helperClient;
    }

    public String startChat() {
        return aiService.findActiveSessions(requireActorEmpNo()).orElse("");
    }

    public Map<String, Object> continueChat(String roomIndex, String status, long afterSeq, int limit) {
        String actorEmpNo = requireActorEmpNo();
        String chatSq = roomIndex == null ? "" : roomIndex.trim();

        if (!"R".equals(status) && !"N".equals(status)) {
            throw new IllegalArgumentException("status must be R or N.");
        }
        if ("R".equals(status) && (chatSq.isEmpty() || afterSeq < 0 || limit <= 0)) {
            throw new IllegalArgumentException("Resume requires room_index and valid history pagination.");
        }
        if (!(aiService instanceof AiApiService.ContinueStore)) {
            throw new IllegalStateException("The transactional chat session store is not configured.");
        }

        AiApiService.ContinueStore store = (AiApiService.ContinueStore) aiService;
        return store.inSessionTransaction(actorEmpNo, tx -> {
            if ("N".equals(status)) {
                return Collections.singletonMap("room_index", tx.resetSession(chatSq, actorEmpNo));
            }

            String existingRoom = tx.findSession(chatSq, actorEmpNo)
                    .orElseThrow(() -> new NoSuchElementException("No resumable chat room was found."));
            List<AiApiService.Message> messages = findHistory(tx, existingRoom, actorEmpNo, afterSeq, limit);
            tx.refreshSessionSummary(existingRoom, actorEmpNo);

            Map<String, Object> response = new LinkedHashMap<>();
            response.put("room_index", existingRoom);
            response.put("messages", messages);
            return Collections.unmodifiableMap(response);
        });
    }

    public AiApiService.SentMessage sendMessage(String chatSq, String messageId, String content) {
        return sendMessage(chatSq, null, messageId, content);
    }

    public AiApiService.SentMessage sendMessage(String chatSq, String agentSessionId, String messageId,
                                                String content) {
        String actorEmpNo = requireActorEmpNo();
        if (chatSq == null || chatSq.trim().isEmpty() || messageId == null || messageId.trim().isEmpty()
                || content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("room_index, chat_index and message are required.");
        }
        if (!(aiService instanceof AiApiService.SendStore) || helperClient == null) {
            throw new IllegalStateException("The chat send store and AI helper client must be configured.");
        }

        AiApiService.SendStore store = (AiApiService.SendStore) aiService;
        AiApiService.SendContext context = store.findSendContext(chatSq, actorEmpNo)
                .orElseThrow(() -> new NoSuchElementException("No active chat room was found."));
        if (agentSessionId != null && !agentSessionId.equals(context.agentSessionId)) {
            throw new IllegalArgumentException("The AI session does not match the room.");
        }
        Optional<AiApiService.SentMessage> saved = store.findSentMessage(chatSq, actorEmpNo, messageId, content);
        if (saved.isPresent()) {
            return saved.get();
        }

        Instant sentAt = Instant.now();
        AiApiService.HelperResponse response = helperClient.postMessage(
                new AiApiService.HelperRequest(context, content, actorEmpNo, sentAt));
        return store.saveTurn(chatSq, actorEmpNo, messageId, content, sentAt, context.agentSessionId, response);
    }

    public AiApiService.ChatEnd endChat(String chatSq, String type) {
        if ("C".equals(type)) {
            return finishChat(chatSq, requireActorEmpNo(), AiApiService.ChatEndStatus.COMPLETED);
        }
        if ("X".equals(type)) {
            return finishChat(chatSq, requireActorEmpNo(), AiApiService.ChatEndStatus.CANCELED);
        }
        throw new IllegalArgumentException("type must be C or X.");
    }

    public AiApiService.ChatEnd compleeChat(String chatSq, String actionEmpNo) {
        return endChat(chatSq, actionEmpNo, AiApiService.ChatEndStatus.COMPLETED);
    }

    public AiApiService.ChatEnd cancelChat(String chatSq, String actorEmpNo) {
        return endChat(chatSq, actorEmpNo, AiApiService.ChatEndStatus.CANCELED);
    }

    private AiApiService.ChatEnd endChat(String chatSq, String actorEmpNo,
                                        AiApiService.ChatEndStatus status) {
        if (!requireActorEmpNo().equals(actorEmpNo)) {
            throw new SecurityException("The employee does not match the authenticated session.");
        }
        return finishChat(chatSq, actorEmpNo, status);
    }

    private AiApiService.ChatEnd finishChat(String chatSq, String actorEmpNo,
                                           AiApiService.ChatEndStatus status) {
        if (chatSq == null || chatSq.trim().isEmpty()) {
            throw new IllegalArgumentException("room_index is required.");
        }
        if (!(aiService instanceof AiApiService.EndStore)
                || !(helperClient instanceof AiApiService.ClosingHelperClient)) {
            throw new IllegalStateException("The chat end store and AI closing client must be configured.");
        }

        AiApiService.EndStore store = (AiApiService.EndStore) aiService;
        AiApiService.ClosingHelperClient client = (AiApiService.ClosingHelperClient) helperClient;
        Optional<AiApiService.ChatEnd> saved = store.findChatEnd(chatSq, actorEmpNo);
        if (saved.isPresent()) {
            if (saved.get().status != status) {
                throw new IllegalStateException("The room already has a different terminal status.");
            }
            return saved.get();
        }

        AiApiService.SendContext context = store.findSendContext(chatSq, actorEmpNo)
                .orElseThrow(() -> new NoSuchElementException("No active chat room was found."));
        Object draft = null;
        if (status == AiApiService.ChatEndStatus.COMPLETED) {
            draft = Objects.requireNonNull(client.complete(context.agentSessionId, actorEmpNo), "AI draft");
        } else {
            client.closeSession(context.agentSessionId, actorEmpNo);
        }
        return store.saveChatEnd(chatSq, actorEmpNo, context.agentSessionId,
                new AiApiService.ChatEnd(chatSq, status, draft));
    }

    private List<AiApiService.Message> findHistory(AiApiService.SessionTransaction tx,
                                                   String chatSq, String actorEmpNo, long afterSeq, int limit) {
        return tx.findHistory(chatSq, actorEmpNo, afterSeq, limit);
    }

    private String requireActorEmpNo() {
        String actorEmpNo = currentEmpNo.get();
        if (actorEmpNo == null || actorEmpNo.trim().isEmpty()) {
            throw new SecurityException("An authenticated employee session is required.");
        }
        return actorEmpNo;
    }
}
