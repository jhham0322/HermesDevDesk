package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.apache.ibatis.exceptions.PersistenceException;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.Executors;

public final class AiChatApplication {
    private static final int MAX_REQUEST = 1024 * 1024;
    private final ObjectMapper json;
    private final PostgresChatStore store;
    private final AiApiService.ClosingHelperClient helper;
    private final Map<String, String> tokens;

    AiChatApplication(ObjectMapper json, PostgresChatStore store, AiApiService.ClosingHelperClient helper,
                      Map<String, String> tokens) {
        this.json = json;
        this.store = store;
        this.helper = helper;
        this.tokens = Map.copyOf(tokens);
        if (tokens.isEmpty() || new HashSet<>(tokens.values()).size() != tokens.size()
                || tokens.entrySet().stream().anyMatch(e -> e.getKey().isBlank() || e.getValue().length() < 32
                || e.getValue().chars().anyMatch(c -> c <= 32 || c >= 127))) {
            throw new IllegalArgumentException("Configure distinct employee bearer tokens of at least 32 ASCII characters.");
        }
    }

    public static void main(String[] args) throws IOException {
        Map<String, String> env = System.getenv();
        var json = new ObjectMapper();
        var helper = new AiHelperHttpClient(json, URI.create(required(env, "AI_BASE_URL")),
                env.getOrDefault("AI_TOKEN", ""), required(env, "AI_OPEN_PATH"), required(env, "AI_CLOSE_PATH"));
        var store = new PostgresChatStore(required(env, "CHAT_DB_URL"), required(env, "CHAT_DB_USER"),
                env.getOrDefault("CHAT_DB_PASSWORD", ""), json, helper, required(env, "AI_VISIBILITY"));
        var tokens = json.readValue(required(env, "CHAT_USER_TOKENS_JSON"), new TypeReference<Map<String, String>>() {});
        var app = new AiChatApplication(json, store, helper, tokens);
        if ("true".equalsIgnoreCase(env.get("CHAT_INIT_SCHEMA"))) store.initializeSchema();
        int port = Integer.parseInt(env.getOrDefault("CHAT_PORT", "8080"));
        app.start(port);
        System.out.println("AI chatbot listening at http://127.0.0.1:" + port);
    }

    HttpServer start(int port) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 32);
        server.setExecutor(Executors.newFixedThreadPool(12, task -> {
            Thread thread = new Thread(task, "chat-http");
            thread.setDaemon(true);
            return thread;
        }));
        server.createContext("/", this::handle);
        server.start();
        return server;
    }

    private void handle(HttpExchange exchange) throws IOException {
        try (exchange) {
            exchange.getResponseHeaders().set("Cache-Control", "no-store");
            exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
            exchange.getResponseHeaders().set("Content-Security-Policy",
                    "default-src 'self'; frame-ancestors 'none'; style-src 'self' 'unsafe-inline'");
            String path = exchange.getRequestURI().getPath();
            if ("/".equals(path) || "/chat.js".equals(path)) {
                staticResource(exchange, path);
                return;
            }
            if (!path.startsWith("/chat/")) {
                respond(exchange, 404, Map.of("error", "Unknown route."));
                return;
            }
            if (!"POST".equals(exchange.getRequestMethod())) {
                exchange.getResponseHeaders().set("Allow", "POST");
                respond(exchange, 405, Map.of("error", "Use POST."));
                return;
            }
            String actor = authenticate(exchange);
            if (actor == null) {
                exchange.getResponseHeaders().set("WWW-Authenticate", "Bearer");
                respond(exchange, 401, Map.of("error", "Authentication required."));
                return;
            }
            Object result;
            try {
                byte[] body = exchange.getRequestBody().readNBytes(MAX_REQUEST + 1);
                if (body.length > MAX_REQUEST) {
                    respond(exchange, 413, Map.of("error", "Request is too large."));
                    return;
                }
                JsonNode input = json.readTree(body);
                if (input == null || !input.isObject()) throw new IllegalArgumentException("Expected a JSON object.");
                var controller = new AiChatControlle(new AiChatService(() -> actor, store, helper));
                result = store.ordered(actor, () -> dispatch(controller, path, input));
            } catch (NoSuchElementException e) {
                respond(exchange, 404, Map.of("error", e.getMessage()));
                return;
            } catch (IllegalArgumentException | com.fasterxml.jackson.core.JsonProcessingException e) {
                respond(exchange, 400, Map.of("error", "Invalid chat request."));
                return;
            } catch (AiHelperHttpClient.HelperFailure e) {
                respond(exchange, 502, Map.of("error", e.getMessage()));
                return;
            } catch (PersistenceException e) {
                System.err.println("Chat database operation failed: " + e.getClass().getSimpleName());
                respond(exchange, 500, Map.of("error", "Chat database operation failed."));
                return;
            } catch (IllegalStateException e) {
                respond(exchange, 409, Map.of("error", e.getMessage()));
                return;
            }
            respond(exchange, 200, result);
        }
    }

    private Object dispatch(AiChatControlle controller, String path, JsonNode input) {
        if ("/chat/start".equals(path)) return controller.startChat(null);
        String room = text(input, "room_index");
        if (!room.isEmpty() && !room.matches("[1-9][0-9]{0,18}")) {
            throw new IllegalArgumentException("Invalid room index.");
        }
        if (!room.isEmpty()) Long.parseLong(room);
        return switch (path) {
            case "/chat/continue" -> controller.continueChat(null, room, text(input, "status"),
                    integer(input, "afterSeq", 0, Long.MAX_VALUE), (int) integer(input, "limit", 50, 200));
            case "/chat/send" -> controller.sendMessage(null, room, text(input, "message"),
                    text(input, "type"), text(input, "chat_index"));
            case "/chat/end" -> controller.endChat(null, room, text(input, "type"));
            default -> throw new NoSuchElementException("Unknown chat route.");
        };
    }

    private String authenticate(HttpExchange exchange) {
        String header = exchange.getRequestHeaders().getFirst("Authorization");
        if (header == null || !header.startsWith("Bearer ")) return null;
        byte[] supplied = header.substring(7).getBytes(StandardCharsets.UTF_8);
        for (var token : tokens.entrySet()) {
            if (MessageDigest.isEqual(token.getValue().getBytes(StandardCharsets.UTF_8), supplied)) {
                return token.getKey();
            }
        }
        return null;
    }

    private void staticResource(HttpExchange exchange, String path) throws IOException {
        if (!"GET".equals(exchange.getRequestMethod())) {
            exchange.getResponseHeaders().set("Allow", "GET");
            respond(exchange, 405, Map.of("error", "Use GET."));
            return;
        }
        boolean page = "/".equals(path);
        try (var resource = getClass().getResourceAsStream(page ? "/web/index.html" : "/web/chat.js")) {
            if (resource == null) throw new IOException("Missing chat UI resource.");
            byte[] body = resource.readAllBytes();
            exchange.getResponseHeaders().set("Content-Type", page ? "text/html; charset=utf-8" : "text/javascript; charset=utf-8");
            exchange.sendResponseHeaders(200, body.length);
            exchange.getResponseBody().write(body);
        }
    }

    private void respond(HttpExchange exchange, int status, Object value) throws IOException {
        byte[] body = json.writeValueAsBytes(value);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, body.length);
        exchange.getResponseBody().write(body);
    }

    private static String text(JsonNode input, String field) {
        JsonNode value = input.get(field);
        if (value == null || value.isNull()) return "";
        if (!value.isTextual()) throw new IllegalArgumentException("Expected string.");
        return value.textValue();
    }

    private static long integer(JsonNode input, String field, long fallback, long max) {
        JsonNode value = input.get(field);
        if (value == null) return fallback;
        if (!value.isIntegralNumber() || !value.canConvertToLong() || value.longValue() < 0 || value.longValue() > max) {
            throw new IllegalArgumentException("Invalid paging number.");
        }
        return value.longValue();
    }

    private static String required(Map<String, String> values, String key) {
        String value = values.get(key);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing environment variable " + key + ".");
        return value;
    }
}
