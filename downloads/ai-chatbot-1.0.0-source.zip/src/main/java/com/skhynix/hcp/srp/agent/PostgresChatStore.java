package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.datasource.unpooled.UnpooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

final class PostgresChatStore implements AiApiService.EndStore {
    private static final String NS = "com.skhynix.hcp.srp.agent.AiMapper.";
    private final UnpooledDataSource source;
    private final SqlSessionFactory sessions;
    private final ObjectMapper json;
    private final AiHelperHttpClient helper;
    private final String visibility;

    PostgresChatStore(String url, String user, String password, ObjectMapper json,
                      AiHelperHttpClient helper, String visibility) throws IOException {
        this.source = new UnpooledDataSource("org.postgresql.Driver", url, user, password);
        this.json = json;
        this.helper = helper;
        this.visibility = visibility;
        Configuration config = new Configuration(new Environment("postgres", new JdbcTransactionFactory(), source));
        config.setDefaultStatementTimeout(15);
        String resource = "mapper/AiMapper.xml";
        try (InputStream xml = PostgresChatStore.class.getClassLoader().getResourceAsStream(resource)) {
            if (xml == null) throw new IOException("Missing " + resource);
            new XMLMapperBuilder(xml, config, resource, config.getSqlFragments()).parse();
        }
        this.sessions = new SqlSessionFactoryBuilder().build(config);
    }

    void initializeSchema() {
        transaction(s -> {
            for (String statement : List.of("createChatMaster", "createChatDetail", "addDetailSelectedFlag",
                    "createActiveRoomIndex", "createCompletionDetailIndex")) {
                s.update(NS + statement);
            }
            return null;
        });
    }

    // Separate session lock orders requests across app instances without holding a DB transaction during AI HTTP calls.
    <T> T ordered(String actor, Supplier<T> work) {
        try (var connection = source.getConnection();
             var lock = connection.prepareStatement(
                     "SELECT pg_advisory_lock(hashtext('SRP_AI_CHAT_HTTP'), hashtext(?))")) {
            lock.setQueryTimeout(75);
            lock.setString(1, actor);
            lock.execute();
            return work.get();
        } catch (SQLException e) {
            throw new IllegalStateException("Could not acquire the chat operation lock.", e);
        }
    }

    @Override public Optional<String> findActiveSessions(String actor) {
        return read(s -> Optional.ofNullable(s.selectOne(NS + "findActiveSessions", args(actor, null))));
    }

    @Override public <T> T inSessionTransaction(String actor, Function<AiApiService.SessionTransaction, T> action) {
        return transaction(s -> {
            lock(s, actor);
            return action.apply(new Transaction(s));
        });
    }

    @Override public Optional<AiApiService.SendContext> findSendContext(String room, String actor) {
        Map<String, Object> params = args(actor, room);
        Map<String, Object> bound = read(s -> row(s, "findSendContext", params));
        if (bound != null) return Optional.of(context(bound));
        String active = read(s -> s.selectOne(NS + "findSession", params));
        if (active == null) return Optional.empty();

        String sessionId = helper.openSession(actor, visibility);
        params.put("agentSessionId", sessionId);
        params.put("visibility", visibility);
        return transaction(s -> {
            lock(s, actor);
            requireRows(s.update(NS + "bindAgentSession", params), 1);
            return Optional.of(new AiApiService.SendContext(sessionId, visibility));
        });
    }

    @Override public Optional<AiApiService.SentMessage> findSentMessage(String room, String actor,
                                                                      String id, String content) {
        return read(s -> sent(s, args(actor, room, "messageId", id), content));
    }

    @Override public AiApiService.SentMessage saveTurn(String room, String actor, String id, String content,
                                                       Instant sent, String session, AiApiService.HelperResponse reply) {
        Map<String, Object> params = args(actor, room, "messageId", id, "content", content,
                "userSentAt", sent.toString(), "agentSessionId", session, "response", reply.message,
                "sentAt", reply.sent_at, "referencesJson", encode(reply.references));
        return transaction(s -> {
            lock(s, actor);
            Optional<AiApiService.SentMessage> cached = sent(s, params, content);
            if (cached.isPresent()) return cached.get();
            requireRows(s.insert(NS + "insertMessagePair", params), 2);
            requireRows(s.update(NS + "refreshSessionSummary", params), 1);
            return sent(s, params, content).orElseThrow();
        });
    }

    @Override public Optional<AiApiService.ChatEnd> findChatEnd(String room, String actor) {
        return read(s -> chatEnd(s, args(actor, room)));
    }

    @Override public AiApiService.ChatEnd saveChatEnd(String room, String actor, String session,
                                                      AiApiService.ChatEnd end) {
        Map<String, Object> params = args(actor, room, "agentSessionId", session);
        return transaction(s -> {
            lock(s, actor);
            Optional<AiApiService.ChatEnd> cached = chatEnd(s, params);
            if (cached.isPresent()) {
                if (cached.get().status != end.status) throw new IllegalStateException("Chat has already ended.");
                return cached.get();
            }
            if (end.status == AiApiService.ChatEndStatus.COMPLETED) {
                String draftJson = encode(end.draft);
                params.put("draftJson", draftJson);
                params.put("message", end.draft instanceof String text ? text : draftJson);
                requireRows(s.insert(NS + "insertCompletionDetail", params), 1);
                requireRows(s.update(NS + "refreshSessionSummary", params), 1);
                requireRows(s.update(NS + "markChatCompleted", params), 1);
            } else {
                requireRows(s.update(NS + "markChatCanceled", params), 1);
            }
            return end;
        });
    }

    private final class Transaction implements AiApiService.SessionTransaction {
        private final SqlSession sql;
        private Transaction(SqlSession sql) { this.sql = sql; }

        @Override public Optional<String> findSession(String room, String actor) {
            return Optional.ofNullable(sql.selectOne(NS + "findSession", args(actor, room)));
        }

        @Override public List<AiApiService.Message> findHistory(String room, String actor, long after, int limit) {
            return sql.<Map<String, Object>>selectList(NS + "findHistory",
                            args(actor, room, "afterSeq", after, "limit", limit)).stream()
                    .map(r -> new AiApiService.Message(str(r, "userid"), str(r, "room_index"), str(r, "chat_index"),
                            str(r, "message"), str(r, "time"), str(r, "isbot"), str(r, "slected"))).toList();
        }

        @Override public void refreshSessionSummary(String room, String actor) {
            requireRows(sql.update(NS + "refreshSessionSummary", args(actor, room)), 1);
        }

        @Override public String resetSession(String expected, String actor) {
            String active = sql.selectOne(NS + "findActiveSessions", args(actor, null));
            if (!expected.equals(active == null ? "" : active)) throw new IllegalStateException("Active room changed. Reload chat.");
            if (active != null) requireRows(sql.update(NS + "closeActiveRoomForReset", args(actor, active)), 1);
            Map<String, Object> params = args(actor, null, "agentSessionId", null, "visibility", visibility);
            requireRows(sql.insert(NS + "insertChatMaster", params), 1);
            return params.get("chatSq").toString();
        }
    }

    private Optional<AiApiService.SentMessage> sent(SqlSession s, Map<String, Object> params, String content) {
        Map<String, Object> result = row(s, "findSentMessage", params);
        if (result == null) return Optional.empty();
        if (!content.equals(str(result, "user_message"))) throw new IllegalStateException("Message ID was already used.");
        String references = str(result, "references_json");
        List<?> items = references == null ? List.of() : decode(references, List.class);
        var reply = new AiApiService.HelperResponse(str(result, "message"), str(result, "sent_at"), items);
        return Optional.of(new AiApiService.SentMessage(str(result, "chat_index"), reply));
    }

    private Optional<AiApiService.ChatEnd> chatEnd(SqlSession s, Map<String, Object> params) {
        Map<String, Object> result = row(s, "findChatEnd", params);
        if (result == null) return Optional.empty();
        String draft = str(result, "draft_json");
        return Optional.of(new AiApiService.ChatEnd(str(result, "room_index"),
                AiApiService.ChatEndStatus.valueOf(str(result, "status")),
                draft == null ? null : decode(draft, Object.class)));
    }

    private static AiApiService.SendContext context(Map<String, Object> row) {
        return new AiApiService.SendContext(str(row, "agent_session_id"), str(row, "visibility"));
    }

    private static Map<String, Object> row(SqlSession s, String id, Map<String, Object> params) {
        return s.selectOne(NS + id, params);
    }

    private static Map<String, Object> args(String actor, String room, Object... fields) {
        Map<String, Object> params = new HashMap<>();
        params.put("actorEmpNo", actor);
        params.put("chatSq", room);
        for (int i = 0; i < fields.length; i += 2) params.put((String) fields[i], fields[i + 1]);
        return params;
    }

    private static String str(Map<String, Object> row, String key) {
        return (String) row.get(key);
    }

    private static void requireRows(int actual, int expected) {
        if (actual != expected) throw new NoSuchElementException("Chat changed before the operation could be saved.");
    }

    private static void lock(SqlSession s, String actor) {
        s.selectOne(NS + "lockEmployeeRooms", args(actor, null));
    }

    private <T> T read(Function<SqlSession, T> action) {
        try (SqlSession session = sessions.openSession()) { return action.apply(session); }
    }

    private <T> T transaction(Function<SqlSession, T> action) {
        try (SqlSession session = sessions.openSession()) {
            T result = action.apply(session);
            session.commit();
            return result;
        }
    }

    private String encode(Object value) {
        try { return json.writeValueAsString(value); }
        catch (JsonProcessingException e) { throw new IllegalArgumentException("Invalid chat JSON.", e); }
    }

    private <T> T decode(String value, Class<T> type) {
        try { return json.readValue(value, type); }
        catch (JsonProcessingException e) { throw new IllegalStateException("Stored chat JSON could not be read.", e); }
    }
}
