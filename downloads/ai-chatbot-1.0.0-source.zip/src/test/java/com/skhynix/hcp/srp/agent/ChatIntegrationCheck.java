package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.DriverManager;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/** Runs against a disposable PostgreSQL database and a local fake AI helper. */
public final class ChatIntegrationCheck {
    private static final String TOKEN = "synthetic-employee-token-000000001";
    private static final String OTHER = "synthetic-employee-token-000000002";
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static void main(String[] args) throws Exception {
        String jdbc = required("CHAT_TEST_DB_URL");
        String user = required("CHAT_TEST_DB_USER");
        String password = required("CHAT_TEST_DB_PASSWORD");
        String schema = "chat_test_" + UUID.randomUUID().toString().replace("-", "");
        try (var connection = DriverManager.getConnection(jdbc, user, password);
             var statement = connection.createStatement()) {
            statement.execute("CREATE SCHEMA " + schema);
            try {
                run(jdbc + (jdbc.contains("?") ? "&" : "?") + "currentSchema=" + schema, user, password);
            } finally {
                statement.execute("DROP SCHEMA " + schema + " CASCADE");
            }
        }
    }

    private static void run(String jdbc, String user, String password) throws Exception {
        var posts = new AtomicInteger();
        var completions = new AtomicInteger();
        var closes = new AtomicInteger();
        var ai = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 8);
        ai.createContext("/", exchange -> {
            try (exchange) {
                var request = JSON.readTree(exchange.getRequestBody());
                int status = 200;
                Object reply;
                if (!"POST".equals(exchange.getRequestMethod()) || !request.hasNonNull("emp_no")) {
                    status = 400;
                    reply = Map.of();
                } else {
                    reply = switch (exchange.getRequestURI().getPath()) {
                        case "/fixture/open" -> Map.of("session_id", UUID.randomUUID().toString());
                        case "/api/v1/sr/helper/message" -> {
                            check(request.hasNonNull("session_id") && request.hasNonNull("visibility")
                                    && request.hasNonNull("sent_at"), "helper request fields");
                            posts.incrementAndGet();
                            if ("fail".equals(request.path("message").asText())) {
                                status = 503;
                                yield Map.of();
                            }
                            yield Map.of("message", "answer", "sent_at", "2026-11-19T10:00:00Z",
                                    "references", java.util.List.of(Map.of("title", "fixture")));
                        }
                        case "/api/v1/sr/helper/complete" -> {
                            completions.incrementAndGet();
                            yield Map.of("draft", Map.of("text", "draft"));
                        }
                        case "/fixture/close" -> {
                            closes.incrementAndGet();
                            yield Map.of();
                        }
                        default -> { status = 404; yield Map.of(); }
                    };
                }
                byte[] bytes = JSON.writeValueAsBytes(reply);
                exchange.sendResponseHeaders(status, bytes.length);
                exchange.getResponseBody().write(bytes);
            }
        });
        ai.start();
        HttpServer chatbot = null;
        try {
            var helper = new AiHelperHttpClient(JSON, url(ai), "", "/fixture/open", "/fixture/close");
            var store = new PostgresChatStore(jdbc, user, password, JSON, helper, "fixture");
            store.initializeSchema();
            store.initializeSchema();
            chatbot = new AiChatApplication(JSON, store, helper, Map.of("EMP1", TOKEN, "EMP2", OTHER)).start(0);
            URI base = url(chatbot);
            call(base, "start", "", Map.of(), 401);
            check(call(base, "start", TOKEN, Map.of("userid", "EMP2"), 200).path("has_open_chat").asText().equals("F"), "read-only start");
            String room = startRoom(base, "");
            check(call(base, "start", TOKEN, Map.of(), 200).path("room_index").asText().equals(room), "active room");
            call(base, "continue", OTHER, Map.of("room_index", room, "status", "R"), 404);
            call(base, "send", TOKEN, send(room, "fail", "failed"), 502);
            var request = send(room, "hello", "message-1");
            JsonNode first = call(base, "send", TOKEN, request, 200);
            check(first.path("chat_index").asText().equals("2") && first.path("references").size() == 1, "reply contract");
            check(first.equals(call(base, "send", TOKEN, request, 200)) && posts.get() == 2, "cached reply");
            call(base, "send", TOKEN, send(room, "different", "message-1"), 409);
            JsonNode history = call(base, "continue", TOKEN, Map.of("room_index", room, "status", "R"), 200).path("messages");
            check(history.size() == 2 && history.get(0).path("chat_index").asText().equals("1")
                    && history.get(1).path("isbot").asText().equals("Y")
                    && history.get(1).path("slected").asText().equals("N"), "sequence and history");
            JsonNode page = call(base, "continue", TOKEN, Map.of("room_index", room, "status", "R", "afterSeq", 1, "limit", 1), 200).path("messages");
            check(page.size() == 1 && page.get(0).path("chat_index").asText().equals("2"), "history paging");
            var same = send(room, "parallel", "message-2");
            var a = HTTP.sendAsync(request(base, "send", TOKEN, same), HttpResponse.BodyHandlers.ofString());
            var b = HTTP.sendAsync(request(base, "send", TOKEN, same), HttpResponse.BodyHandlers.ofString());
            check(a.get().statusCode() == 200 && b.get().statusCode() == 200
                    && a.get().body().equals(b.get().body()) && posts.get() == 3, "concurrent replay");
            JsonNode done = call(base, "end", TOKEN, Map.of("room_index", room, "type", "C"), 200);
            check(done.path("status").asText().equals("COMPLETED") && done.path("draft").path("text").asText().equals("draft"), "completed draft");
            check(done.equals(call(base, "end", TOKEN, Map.of("room_index", room, "type", "C"), 200))
                    && completions.get() == 1, "completion retry");
            call(base, "end", TOKEN, Map.of("room_index", room, "type", "X"), 409);
            String abandoned = startRoom(base, "");
            String replacement = startRoom(base, abandoned);
            call(base, "continue", TOKEN, Map.of("room_index", abandoned, "status", "N"), 409);
            check(call(base, "end", TOKEN, Map.of("room_index", replacement, "type", "X"), 200)
                    .path("status").asText().equals("CANCELED") && closes.get() == 1, "cancellation");
            try (var c = DriverManager.getConnection(jdbc, user, password);
                 var s = c.prepareStatement("SELECT CHAT_STAT_CD, MESSAE_CNT, LAST_MESSAGE_CONT FROM SRP_AI_CHAT_MST WHERE CHAT_SQ = ?")) {
                s.setLong(1, Long.parseLong(room));
                try (var r = s.executeQuery()) {
                    check(r.next() && "COMPLETED".equals(r.getString(1)) && r.getLong(2) == 5
                            && r.getString(3).contains("draft"), "completion DTL and MST summary");
                }
                s.setLong(1, Long.parseLong(abandoned));
                try (var r = s.executeQuery()) { check(r.next() && "CLOSED".equals(r.getString(1)), "reset closed old room"); }
            }
            check(HTTP.send(HttpRequest.newBuilder(base).GET().build(), HttpResponse.BodyHandlers.ofString())
                    .body().contains("AI 챗봇"), "UI entry");
            check(HTTP.send(HttpRequest.newBuilder(base.resolve("/chat.js")).GET().build(),
                    HttpResponse.BodyHandlers.ofString()).statusCode() == 200, "UI script");
            System.out.println("PASS: PostgreSQL/MyBatis/HTTP stages 1–5, ownership, paging, retry, concurrency, failure, UI resources");
        } finally {
            if (chatbot != null) chatbot.stop(0);
            ai.stop(0);
        }
    }

    private static String startRoom(URI base, String previous) throws Exception {
        return call(base, "continue", TOKEN, Map.of("room_index", previous, "status", "N"), 200).path("room_index").asText();
    }
    private static Map<String, String> send(String room, String message, String id) {
        return Map.of("room_index", room, "message", message, "chat_index", id, "type", "S");
    }
    private static JsonNode call(URI base, String action, String token, Map<String, ?> data, int expected) throws Exception {
        var result = HTTP.send(request(base, action, token, data), HttpResponse.BodyHandlers.ofString());
        check(result.statusCode() == expected, action + ": expected " + expected + " got " + result.statusCode() + " " + result.body());
        return JSON.readTree(result.body());
    }
    private static HttpRequest request(URI base, String action, String token, Map<String, ?> data) throws Exception {
        return HttpRequest.newBuilder(base.resolve("/chat/" + action)).header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(data))).build();
    }
    private static URI url(HttpServer server) { return URI.create("http://127.0.0.1:" + server.getAddress().getPort()); }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static String required(String name) {
        String value = System.getenv(name);
        if (value == null) throw new IllegalArgumentException("Missing " + name);
        return value;
    }
}
