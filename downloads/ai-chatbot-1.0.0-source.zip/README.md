# AI 챗봇 1.0.0

Java 17, Maven, MyBatis, PostgreSQL을 사용하는 독립 실행 프로젝트입니다. 브라우저 화면과 1~5단계 JSON API가 같은 서버에서 동작합니다.

## 실행

1. 빈 PostgreSQL 데이터베이스와 계정을 준비합니다.
2. 아래 환경 변수를 설정합니다. 비밀번호와 API 토큰은 실행 환경에서 주입합니다.
3. `mvn clean package`를 실행한 뒤 `java -jar target/ai-chatbot-1.0.0.jar`를 실행합니다.
4. `http://127.0.0.1:8080`에서 서버에 등록한 사용자 토큰으로 채팅을 시작합니다.

| 환경 변수 | 값 |
| --- | --- |
| `CHAT_DB_URL` | 예시 `jdbc:postgresql://127.0.0.1:5432/chat` |
| `CHAT_DB_USER`, `CHAT_DB_PASSWORD` | PostgreSQL 계정과 암호 |
| `CHAT_INIT_SCHEMA` | 새 DB를 만들 때만 `true`. 기본은 DDL 실행 없이 시작 |
| `CHAT_USER_TOKENS_JSON` | 사번을 키로, 서로 다른 32자 이상의 무작위 토큰을 값으로 갖는 JSON 객체 |
| `CHAT_PORT` | 기본값 `8080`. 서버는 루프백 주소에 바인딩 |
| `AI_BASE_URL` | AI helper 서버 원점. HTTPS 또는 테스트용 루프백 HTTP |
| `AI_OPEN_PATH`, `AI_CLOSE_PATH` | 대상 helper의 실제 세션 열기·닫기 경로 |
| `AI_VISIBILITY` | 대상 helper가 허용하는 visibility 값 |
| `AI_TOKEN` | AI helper가 요구하는 경우 사용하는 Bearer 토큰 |

독립 실행판은 서버 설정의 Bearer 토큰에서 사번을 확인합니다. 기존 사내 앱에 이식할 때는 `AiChatService`의 사번 공급자를 `CommonUtility::getCurrentEmpNo`로 연결합니다.

## 호출 계약

모든 아래 요청은 `POST`이며 JSON 본문과 `Authorization: Bearer <token>` 헤더를 사용합니다.

| 경로 | 본문 | 성공 응답 |
| --- | --- | --- |
| `/chat/start` | `{}` | `room_index`, `has_open_chat` |
| `/chat/continue` | `room_index`, `status: "R"`, 선택 `afterSeq`, `limit` | 기존 `room_index`, `messages[]` |
| `/chat/continue` | `room_index` 또는 빈 문자열, `status: "N"` | 새 `room_index` |
| `/chat/send` | `room_index`, `message`, `type: "S"`, 요청 식별자 `chat_index` | AI 답변 `message`, `sent_at`, `references`, 답변 순번 `chat_index` |
| `/chat/end` | `room_index`, `type: "C"` 또는 `"X"` | `room_index`, `status`, `draft` |

처음 메시지를 전송하거나 빈 방을 종료할 때 helper의 세션을 연결합니다. 세션 열기는 `{emp_no, visibility}`를 보내고 `{session_id}`를 받는 POST 계약을 사용합니다. 세션 닫기와 완료는 `{session_id, emp_no}`를 보냅니다. 완료 응답은 `{draft}`, 메시지 응답은 `{message, sent_at, references}`를 사용하며 `sent_at`은 시간대가 포함된 ISO 8601 문자열입니다. 실제 helper의 개설·종료 계약이 다르면 `AiHelperHttpClient`를 맞춰야 합니다.

새 DB의 DDL과 1~5단계 SQL은 `src/main/resources/mapper/AiMapper.xml`에 있습니다. 기존 사내 DB에 적용할 때는 테이블과 컬럼을 실제 DDL에 대조하고, 기존 DB를 대상으로 자동 초기화를 사용하기 전에 마이그레이션을 검토합니다.

사용자 메시지와 답변, 완료 결과와 상태 갱신은 각각 DB 트랜잭션으로 저장합니다. 재전송에는 동일 요청 식별자를 사용합니다. 이미 저장된 요청은 기존 답변을 반환합니다. AI에서 성공한 직후 프로세스 장애가 발생하면 원격 처리와 DB 저장이 갈라질 수 있으므로, 해당 구간의 원격 중복 방지에는 실제 helper 측 멱등성 계약이 필요합니다.

## PostgreSQL 통합 검사

빈 테스트 DB에서 `CHAT_TEST_DB_URL`, `CHAT_TEST_DB_USER`, `CHAT_TEST_DB_PASSWORD`를 설정합니다. 검사는 임의 이름의 스키마를 생성하고 검사 후 해당 스키마만 제거합니다. 외부 AI 호출 대신 루프백 테스트 서버를 사용합니다.

Windows PowerShell

```powershell
mvn clean package
java -cp 'target/test-classes;target/ai-chatbot-1.0.0.jar' com.skhynix.hcp.srp.agent.ChatIntegrationCheck
```

macOS 또는 Linux

```sh
mvn clean package
java -cp 'target/test-classes:target/ai-chatbot-1.0.0.jar' com.skhynix.hcp.srp.agent.ChatIntegrationCheck
```
