package com.skhynix.hcp.srp.agent.ai;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.skhynix.hcp.srp.agent.PostgresChatStore;

import java.io.IOException;

/** PostgreSQL adapter for the evidence-review tables. */
public final class AiEvidenceReviewChat extends PostgresChatStore {
    public AiEvidenceReviewChat(String url, String user, String password, ObjectMapper json,
                                SessionOpener openHelper, String visibility) throws IOException {
        super(url, user, password, json, openHelper, visibility, "mapper/ai/AiEvidenceReviewChatMapper.xml",
                "com.skhynix.hcp.srp.agent.ai.AiEvidenceReviewChatMapper.");
    }
}
