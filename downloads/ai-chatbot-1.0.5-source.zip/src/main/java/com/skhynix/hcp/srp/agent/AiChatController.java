package com.skhynix.hcp.srp.agent;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public final class AiChatController {
    private static final int DEFAULT_HISTORY_LIMIT = 50;

    private final AiChatService chatService;

    public AiChatController(AiChatService chatService) {
        this.chatService = Objects.requireNonNull(chatService, "chatService");
    }

    public Map<String, String> startChat(String userid) {
        // The session supplies the actor. The UI argument is kept for compatibility.
        String roomIndex = chatService.startChat();
        Map<String, String> response = new LinkedHashMap<>();
        response.put("room_index", roomIndex);
        response.put("has_open_chat", roomIndex.isEmpty() ? "F" : "T");
        return Collections.unmodifiableMap(response);
    }

    public Map<String, Object> continueChat(String userid, String roomIndex, String status) {
        return continueChat(userid, roomIndex, status, 0, DEFAULT_HISTORY_LIMIT);
    }

    public Map<String, Object> continueChat(String userid, String roomIndex, String status, long afterSeq, int limit) {
        return chatService.continueChat(roomIndex, status, afterSeq, limit);
    }

    public AiApiService.SentMessage sendMessage(String userid, String roomIndex, String message,
                                                 String type, String chatIndex) {
        if (!"S".equals(type)) {
            throw new IllegalArgumentException("type must be S.");
        }
        return chatService.sendMessage(roomIndex, chatIndex, message);
    }

    public AiApiService.ChatEnd endChat(String userid, String roomIndex, String type) {
        return chatService.endChat(roomIndex, type);
    }
}
