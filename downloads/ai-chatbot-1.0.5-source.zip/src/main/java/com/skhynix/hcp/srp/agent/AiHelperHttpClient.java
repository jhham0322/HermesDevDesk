package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;

final class AiHelperHttpClient implements AiApiService.ClosingHelperClient {
    private final Transport transport;
    private final Duration timeout;

    @FunctionalInterface
    interface Transport {
        Reply send(HttpRequest request) throws IOException, InterruptedException;
    }

    record Reply(int status, byte[] body) {}
    private final ObjectMapper json;
    private final URI origin;
    private final String token;
    private final String openPath;
    private final String closePath;

    AiHelperHttpClient(ObjectMapper json, URI origin, String token, String openPath, String closePath) {
        this(json, origin, token, openPath, closePath, Duration.ofSeconds(60));
    }

    AiHelperHttpClient(ObjectMapper json, URI origin, String token, String openPath, String closePath,
                       Duration timeout) {
        this(json, origin, token, openPath, closePath, defaultTransport(), timeout);
    }

    AiHelperHttpClient(ObjectMapper json, URI origin, String token, String openPath, String closePath,
                       Transport transport) {
        this(json, origin, token, openPath, closePath, transport, Duration.ofSeconds(60));
    }

    private AiHelperHttpClient(ObjectMapper json, URI origin, String token, String openPath, String closePath,
                               Transport transport, Duration timeout) {
        this.transport = transport;
        this.timeout = timeout;
        this.json = json;
        this.origin = origin;
        this.token = token;
        this.openPath = openPath;
        this.closePath = closePath;
        if (!"https".equals(origin.getScheme()) && !("http".equals(origin.getScheme())
                && ("127.0.0.1".equals(origin.getHost()) || "localhost".equals(origin.getHost())))) {
            throw new IllegalArgumentException("AI_BASE_URL must use HTTPS or local HTTP.");
        }
        endpoint(openPath);
        endpoint(closePath);
    }

    String openSession(String actor, String visibility, String room) {
        return requiredText(post(openPath, Map.of("emp_no", actor, "visibility", visibility), actor, visibility, room), "session_id");
    }

    @Override public AiApiService.HelperResponse postMessage(AiApiService.HelperRequest request) {
        JsonNode result = post("/api/v1/sr/helper/message", request, request.emp_no, request.session_id, request.requestId);
        JsonNode references = result.get("references");
        if (references != null && !references.isNull() && !references.isArray()) {
            throw new HelperFailure("Invalid AI references payload.");
        }
        List<?> items = references == null || references.isNull() ? List.of() : json.convertValue(references, List.class);
        String sentAt = requiredText(result, "sent_at");
        try {
            sentAt = OffsetDateTime.parse(sentAt).toInstant().toString();
        } catch (DateTimeParseException e) {
            throw new HelperFailure("AI helper returned an invalid sent_at value.");
        }
        return new AiApiService.HelperResponse(requiredText(result, "message"), sentAt, items);
    }

    @Override public Object complete(String session, String actor) {
        JsonNode draft = post("/api/v1/sr/helper/complete", Map.of("session_id", session, "emp_no", actor), actor, session).get("draft");
        if (draft == null || !draft.isObject()) throw new HelperFailure("AI helper did not return a draft object.");
        return draft;
    }

    @Override public void closeSession(String session, String actor) {
        post(closePath, Map.of("session_id", session, "emp_no", actor), actor, session);
    }

    private URI endpoint(String path) {
        if (!path.startsWith("/") || path.startsWith("//") || path.indexOf('\\') >= 0) {
            throw new IllegalArgumentException("AI endpoint must be an absolute path on AI_BASE_URL.");
        }
        return origin.resolve(path);
    }

    private JsonNode post(String path, Object payload, String... deduplicationScope) {
        try {
            HttpRequest.Builder request = HttpRequest.newBuilder(endpoint(path)).timeout(timeout)
                    .header("Content-Type", "application/json").header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofByteArray(json.writeValueAsBytes(payload)));
            if (deduplicationScope.length != 0) {
                request.header("Idempotency-Key", operationKey(path, deduplicationScope));
            }
            if (!token.isEmpty()) request.header("Authorization", "Bearer " + token);
            Reply response = transport.send(request.build());
            if (response.status() < 200 || response.status() >= 300) {
                throw new HelperFailure("AI helper returned HTTP " + response.status() + ".");
            }
            if (response.body().length == 0) return json.createObjectNode();
            JsonNode result = json.readTree(response.body());
            if (result == null || !result.isObject()) throw new HelperFailure("Invalid AI response.");
            return result;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new HelperFailure("AI request was interrupted.");
        } catch (HttpTimeoutException e) {
            throw new HelperFailure(504, "AI helper request timed out.");
        } catch (IOException e) {
            throw new HelperFailure("AI helper request failed.");
        }
    }

    private String operationKey(String path, String[] scope) throws IOException {
        try {
            byte[] payload = json.writeValueAsBytes(List.of(path, List.of(scope)));
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(payload));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is unavailable.", e);
        }
    }

    private static Transport defaultTransport() {
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
        return request -> {
            HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
            return new Reply(response.statusCode(), response.body());
        };
    }

    private static String requiredText(JsonNode node, String field) {
        JsonNode value = node.get(field);
        if (value == null || !value.isTextual() || value.textValue().isBlank()) {
            throw new HelperFailure("AI helper response is missing " + field + ".");
        }
        return value.textValue();
    }

    static final class HelperFailure extends RuntimeException {
        final int status;

        HelperFailure(String message) { this(502, message); }

        HelperFailure(int status, String message) {
            super(message);
            this.status = status;
        }
    }
}
