param([switch]$Verify)

$ErrorActionPreference = 'Stop'
$previousJavaHome = $env:JAVA_HOME
Push-Location $PSScriptRoot
try {
    $env:JAVA_HOME = Join-Path $env:USERPROFILE '.jdk\jdk-21.0.10'
    & 'C:\tools\apache-maven-3.9.6\bin\mvn.cmd' -B -ntp -o verify
    if ($LASTEXITCODE -ne 0) { throw 'Could not build the persistent demo.' }
    $options = if ($Verify) { @('--verify') } else { @() }
    & python .\tools\run-local-postgres-demo.py @options
    if ($LASTEXITCODE -ne 0) { throw 'The persistent demo reported an error.' }
} finally {
    $env:JAVA_HOME = $previousJavaHome
    Pop-Location
}
