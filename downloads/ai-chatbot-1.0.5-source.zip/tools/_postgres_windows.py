"""Windows-only helpers for disposable PostgreSQL authentication."""
import ctypes
import secrets
import threading
from ctypes import wintypes


def password_pipe(secret):
    kernel=ctypes.WinDLL("kernel32",use_last_error=True)
    kernel.CreateNamedPipeW.argtypes=[wintypes.LPCWSTR]+[wintypes.DWORD]*6+[wintypes.LPVOID]
    kernel.CreateNamedPipeW.restype=wintypes.HANDLE
    kernel.ConnectNamedPipe.argtypes=[wintypes.HANDLE,wintypes.LPVOID]
    kernel.WriteFile.argtypes=[wintypes.HANDLE,wintypes.LPCVOID,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),wintypes.LPVOID]
    for fn in (kernel.FlushFileBuffers,kernel.DisconnectNamedPipe,kernel.CloseHandle): fn.argtypes=[wintypes.HANDLE]
    pipe_name=r"\\.\pipe\sol-pg-"+secrets.token_hex(12)
    pipe=kernel.CreateNamedPipeW(pipe_name,0x00080002,0x00000008,1,4096,4096,0,None)
    if pipe==ctypes.c_void_p(-1).value: raise OSError("Could not create ephemeral password pipe")
    def send_password():
        try:
            if kernel.ConnectNamedPipe(pipe,None) or ctypes.get_last_error()==535:
                payload=(secret+"\n").encode("ascii")
                wrote=wintypes.DWORD()
                if kernel.WriteFile(pipe,payload,len(payload),ctypes.byref(wrote),None):
                    kernel.FlushFileBuffers(pipe)
                kernel.DisconnectNamedPipe(pipe)
        finally:
            kernel.CloseHandle(pipe)
    threading.Thread(target=send_password,daemon=True).start()
    return pipe_name
