package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.ibatis.builder.xml.XMLMapperBuilder;
import org.apache.ibatis.datasource.unpooled.UnpooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

public class PostgresChatStore implements AiApiService.EndStore, AiApiService.RoomDirectory {
    private final String namespace;
    private final UnpooledDataSource source;
    private final SqlSessionFactory sessions;
    private final ObjectMapper json;
    @FunctionalInterface
    public interface SessionOpener {
        String open(String actor, String visibility, String room);
    }

    private final SessionOpener openHelper;
    private final String visibility;

    PostgresChatStore(String url, String user, String password, ObjectMapper json,
                      AiHelperHttpClient helper, String visibility) throws IOException {
        this(url, user, password, json, helper::openSession, visibility, null,
                "com.skhynix.hcp.srp.agent.AiMapper.");
    }

    protected PostgresChatStore(String url, String user, String password, ObjectMapper json,
                                SessionOpener openHelper, String visibility,
                                String resource, String namespace) throws IOException {
        this.namespace = namespace;
        this.openHelper = openHelper;
        this.source = new UnpooledDataSource("org.postgresql.Driver", url, user, password);
        this.json = json;
        this.visibility = visibility;
        Configuration config = new Configuration(new Environment("postgres", new JdbcTransactionFactory(), source));
        config.setDefaultStatementTimeout(15);
        try (InputStream xml = resource == null
                ? new ByteArrayInputStream(CHAT_MAPPER_XML.getBytes(StandardCharsets.UTF_8))
                : PostgresChatStore.class.getClassLoader().getResourceAsStream(resource)) {
            if (xml == null) throw new IOException("Missing " + resource);
            String mapperName = resource == null ? "PostgresChatStore:AiMapper" : resource;
            new XMLMapperBuilder(xml, config, mapperName, config.getSqlFragments()).parse();
        }
        this.sessions = new SqlSessionFactoryBuilder().build(config);
    }

    public void initializeSchema() {
        transaction(s -> {
            for (String statement : List.of("createChatMaster", "createChatDetail", "addDetailSelectedFlag",
                    "createActiveRoomIndex", "createCompletionDetailIndex", "createRoomPreference")) {
                s.update(namespace + statement);
            }
            return null;
        });
    }

    // Separate session lock orders requests across app instances without holding a DB transaction during AI HTTP calls.
    <T> T ordered(String actor, Supplier<T> work) {
        try (var connection = source.getConnection();
             var lock = connection.prepareStatement(
                     "SELECT pg_advisory_lock(hashtext('SRP_AI_CHAT_HTTP'), hashtext(?))")) {
            lock.setQueryTimeout(75);
            lock.setString(1, actor);
            lock.execute();
            return work.get();
        } catch (SQLException e) {
            throw new IllegalStateException("Could not acquire the chat operation lock.", e);
        }
    }

    @Override public Optional<String> findActiveSessions(String actor) {
        return read(s -> Optional.ofNullable(s.selectOne(namespace + "findActiveSessions", args(actor, null))));
    }

    @Override public AiApiService.RoomList listRooms(String actor, String before, int limit) {
        return read(s -> {
            var params = args(actor, null, "before", before, "limit", limit);
            List<AiApiService.RoomSummary> rooms = s.<Map<String, Object>>selectList(namespace + "listOwnedRooms", params)
                    .stream().map(row -> new AiApiService.RoomSummary(str(row, "room_index"), str(row, "status")))
                    .toList();
            String selected = s.selectOne(namespace + "findRoomPreference", params);
            return new AiApiService.RoomList(rooms, selected == null ? "" : selected);
        });
    }

    @Override public List<AiApiService.Message> readRoom(String room, String actor, long after, int limit,
                                                        boolean remember) {
        return transaction(s -> {
            var params = args(actor, room);
            if (s.selectOne(namespace + "findOwnedRoom", params) == null) {
                throw new NoSuchElementException("Chat room was not found.");
            }
            if (remember) requireRows(s.insert(namespace + "saveRoomPreference", params), 1);
            return messages(s, room, actor, after, limit, true);
        });
    }

    @Override public <T> T inSessionTransaction(String actor, Function<AiApiService.SessionTransaction, T> action) {
        return transaction(s -> {
            lock(s, actor);
            return action.apply(new Transaction(s));
        });
    }

    @Override public Optional<AiApiService.SendContext> findSendContext(String room, String actor) {
        Map<String, Object> params = args(actor, room);
        Map<String, Object> bound = read(s -> row(s, "findSendContext", params));
        if (bound != null) return Optional.of(context(bound));
        String active = read(s -> s.selectOne(namespace + "findSession", params));
        if (active == null) return Optional.empty();

        String sessionId = openHelper.open(actor, visibility, room);
        params.put("agentSessionId", sessionId);
        params.put("visibility", visibility);
        return transaction(s -> {
            lock(s, actor);
            requireRows(s.update(namespace + "bindAgentSession", params), 1);
            return Optional.of(new AiApiService.SendContext(sessionId, visibility));
        });
    }

    @Override public Optional<AiApiService.SentMessage> findSentMessage(String room, String actor,
                                                                      String id, String content) {
        return read(s -> sent(s, args(actor, room, "messageId", id), content));
    }

    @Override public AiApiService.SentMessage saveTurn(String room, String actor, String id, String content,
                                                       Instant sent, String session, AiApiService.HelperResponse reply) {
        Map<String, Object> params = args(actor, room, "messageId", id, "content", content,
                "userSentAt", sent.toString(), "agentSessionId", session, "response", reply.message,
                "sentAt", reply.sent_at, "referencesJson", encode(reply.references));
        return transaction(s -> {
            lock(s, actor);
            Optional<AiApiService.SentMessage> cached = sent(s, params, content);
            if (cached.isPresent()) return cached.get();
            requireRows(s.insert(namespace + "insertMessagePair", params), 2);
            requireRows(s.update(namespace + "refreshSessionSummary", params), 1);
            return sent(s, params, content).orElseThrow();
        });
    }

    @Override public Optional<AiApiService.ChatEnd> findChatEnd(String room, String actor) {
        return read(s -> chatEnd(s, args(actor, room)));
    }

    @Override public AiApiService.ChatEnd saveChatEnd(String room, String actor, String session,
                                                      AiApiService.ChatEnd end) {
        Map<String, Object> params = args(actor, room, "agentSessionId", session);
        return transaction(s -> {
            lock(s, actor);
            Optional<AiApiService.ChatEnd> cached = chatEnd(s, params);
            if (cached.isPresent()) {
                if (cached.get().status != end.status) throw new IllegalStateException("Chat has already ended.");
                return cached.get();
            }
            if (end.status == AiApiService.ChatEndStatus.COMPLETED) {
                String draftJson = encode(end.draft);
                params.put("draftJson", draftJson);
                params.put("message", end.draft instanceof String text ? text : draftJson);
                requireRows(s.insert(namespace + "insertCompletionDetail", params), 1);
                requireRows(s.update(namespace + "refreshSessionSummary", params), 1);
                requireRows(s.update(namespace + "markChatCompleted", params), 1);
            } else {
                requireRows(s.update(namespace + "markChatCanceled", params), 1);
            }
            return end;
        });
    }

    private List<AiApiService.Message> messages(SqlSession sql, String room, String actor, long after,
                                                 int limit, boolean excludeCompletion) {
        return sql.<Map<String, Object>>selectList(namespace + "findHistory",
                        args(actor, room, "afterSeq", after, "limit", limit, "excludeCompletion", excludeCompletion))
                .stream().map(row -> new AiApiService.Message(str(row, "userid"), str(row, "room_index"),
                        str(row, "chat_index"), str(row, "message"), str(row, "time"), str(row, "isbot"),
                        str(row, "slected"))).toList();
    }

    private final class Transaction implements AiApiService.SessionTransaction {
        private final SqlSession sql;
        private Transaction(SqlSession sql) { this.sql = sql; }

        @Override public Optional<String> findSession(String room, String actor) {
            return Optional.ofNullable(sql.selectOne(namespace + "findSession", args(actor, room)));
        }

        @Override public List<AiApiService.Message> findHistory(String room, String actor, long after, int limit) {
            return messages(sql, room, actor, after, limit, false);
        }

        @Override public void refreshSessionSummary(String room, String actor) {
            requireRows(sql.update(namespace + "refreshSessionSummary", args(actor, room)), 1);
        }

        @Override public String resetSession(String expected, String actor) {
            String active = sql.selectOne(namespace + "findActiveSessions", args(actor, null));
            if (!expected.equals(active == null ? "" : active)) throw new IllegalStateException("Active room changed. Reload chat.");
            if (active != null) requireRows(sql.update(namespace + "closeActiveRoomForReset", args(actor, active)), 1);
            Map<String, Object> params = args(actor, null, "agentSessionId", null, "visibility", visibility);
            requireRows(sql.insert(namespace + "insertChatMaster", params), 1);
            return params.get("chatSq").toString();
        }
    }

    private Optional<AiApiService.SentMessage> sent(SqlSession s, Map<String, Object> params, String content) {
        Map<String, Object> result = row(s, "findSentMessage", params);
        if (result == null) return Optional.empty();
        if (!content.equals(str(result, "user_message"))) throw new IllegalStateException("Message ID was already used.");
        String references = str(result, "references_json");
        List<?> items = references == null ? List.of() : decode(references, List.class);
        var reply = new AiApiService.HelperResponse(str(result, "message"), str(result, "sent_at"), items);
        return Optional.of(new AiApiService.SentMessage(str(result, "chat_index"), reply));
    }

    private Optional<AiApiService.ChatEnd> chatEnd(SqlSession s, Map<String, Object> params) {
        Map<String, Object> result = row(s, "findChatEnd", params);
        if (result == null) return Optional.empty();
        String draft = str(result, "draft_json");
        return Optional.of(new AiApiService.ChatEnd(str(result, "room_index"),
                AiApiService.ChatEndStatus.valueOf(str(result, "status")),
                draft == null ? null : decode(draft, Object.class)));
    }

    private static AiApiService.SendContext context(Map<String, Object> row) {
        return new AiApiService.SendContext(str(row, "agent_session_id"), str(row, "visibility"));
    }

    private Map<String, Object> row(SqlSession s, String id, Map<String, Object> params) {
        return s.selectOne(namespace + id, params);
    }

    private static Map<String, Object> args(String actor, String room, Object... fields) {
        Map<String, Object> params = new HashMap<>();
        params.put("actorEmpNo", actor);
        params.put("chatSq", room);
        for (int i = 0; i < fields.length; i += 2) params.put((String) fields[i], fields[i + 1]);
        return params;
    }

    private static String str(Map<String, Object> row, String key) {
        return (String) row.get(key);
    }

    private static void requireRows(int actual, int expected) {
        if (actual != expected) throw new NoSuchElementException("Chat changed before the operation could be saved.");
    }

    private void lock(SqlSession s, String actor) {
        s.selectOne(namespace + "lockEmployeeRooms", args(actor, null));
    }

    private <T> T read(Function<SqlSession, T> action) {
        try (SqlSession session = sessions.openSession()) { return action.apply(session); }
    }

    private <T> T transaction(Function<SqlSession, T> action) {
        try (SqlSession session = sessions.openSession()) {
            T result = action.apply(session);
            session.commit();
            return result;
        }
    }

    private String encode(Object value) {
        try { return json.writeValueAsString(value); }
        catch (JsonProcessingException e) { throw new IllegalArgumentException("Invalid chat JSON.", e); }
    }

    private <T> T decode(String value, Class<T> type) {
        try { return json.readValue(value, type); }
        catch (JsonProcessingException e) { throw new IllegalStateException("Stored chat JSON could not be read.", e); }
    }

    private static final String CHAT_MAPPER_XML = """
            <?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
                    "https://mybatis.org/dtd/mybatis-3-mapper.dtd">
            <mapper namespace="com.skhynix.hcp.srp.agent.AiMapper">

                <!-- Bootstrap for a new PostgreSQL schema. Run createChatMaster, createChatDetail,
                     and the indexes in that order. For an existing deployment, compare the schema
                     before running DDL. Only addDetailSelectedFlag is intended as a narrow migration.
                     The room key, employee key, initial OPEN/Y state, request ID, message kind,
                     references, and draft columns are proposed integration columns. -->
                <update id="createChatMaster">
                    CREATE TABLE IF NOT EXISTS SRP_AI_CHAT_MST (
                        CHAT_SQ bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                        EMP_NO text NOT NULL,
                        AGENT_SESSION_ID text,
                        VISIBILITY text,
                        CHAT_STAT_CD varchar(16) NOT NULL DEFAULT 'OPEN',
                        USE_FG char(1) NOT NULL DEFAULT 'Y' CHECK (USE_FG IN ('Y', 'N')),
                        LAST_MESSAGE_CONT text,
                        MESSAE_CNT bigint NOT NULL DEFAULT 0,
                        CREATED_DTTM timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        UPDATED_DTTM timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )
                </update>

                <update id="createChatDetail">
                    CREATE TABLE IF NOT EXISTS SRP_AI_CAT_DTL (
                        CHAT_SQ bigint NOT NULL REFERENCES SRP_AI_CHAT_MST (CHAT_SQ),
                        CHAT_INDEX bigint NOT NULL CHECK (CHAT_INDEX > 0),
                        EMP_NO text NOT NULL,
                        MESSAGE_CONT text,
                        SENT_AT timestamptz NOT NULL,
                        ISBOT_FG char(1) NOT NULL CHECK (ISBOT_FG IN ('Y', 'N')),
                        SELECD_FG char(1) NOT NULL DEFAULT 'N' CHECK (SELECD_FG IN ('Y', 'N')),
                        MESSAGE_KIND varchar(16) NOT NULL CHECK (MESSAGE_KIND IN ('MESSAGE', 'COMPLETE')),
                        REQUEST_ID text,
                        REFERENCES_JSON jsonb,
                        DRAFT_JSON jsonb,
                        PRIMARY KEY (CHAT_SQ, CHAT_INDEX),
                        UNIQUE (CHAT_SQ, REQUEST_ID, ISBOT_FG)
                    )
                </update>

                <update id="createRoomPreference">
                    CREATE TABLE IF NOT EXISTS SRP_AI_CHAT_ROOM_PREF (
                        EMP_NO text PRIMARY KEY,
                        CHAT_SQ bigint NOT NULL REFERENCES SRP_AI_CHAT_MST (CHAT_SQ) ON DELETE CASCADE
                    )
                </update>

                <update id="addDetailSelectedFlag">
                    ALTER TABLE SRP_AI_CAT_DTL
                        ADD COLUMN IF NOT EXISTS SELECD_FG char(1) NOT NULL DEFAULT 'N'
                            CHECK (SELECD_FG IN ('Y', 'N'))
                </update>

                <update id="createActiveRoomIndex">
                    CREATE UNIQUE INDEX IF NOT EXISTS UX_SRP_AI_CHAT_MST_ACTIVE_EMP
                        ON SRP_AI_CHAT_MST (EMP_NO)
                        WHERE USE_FG = 'Y' AND CHAT_STAT_CD NOT IN ('CLOSED', 'COMPLETED', 'CANCELED')
                </update>

                <update id="createCompletionDetailIndex">
                    CREATE UNIQUE INDEX IF NOT EXISTS UX_SRP_AI_CAT_DTL_COMPLETION
                        ON SRP_AI_CAT_DTL (CHAT_SQ) WHERE MESSAGE_KIND = 'COMPLETE'
                </update>

                <sql id="activeRoom">
                    USE_FG = 'Y' AND CHAT_STAT_CD NOT IN ('CLOSED', 'COMPLETED', 'CANCELED')
                </sql>

                <!-- Acquire this lock inside the same transaction as every room mutation.
                     Do not hold the transaction open during an AI HTTP call. Recheck the
                     active room and agent session when saving the AI result. -->
                <select id="lockEmployeeRooms" parameterType="map" resultType="int"
                        flushCache="true" useCache="false">
                    SELECT 1 FROM pg_advisory_xact_lock(hashtext('SRP_AI_CHAT_MST'), hashtext(#{actorEmpNo}))
                </select>

                <select id="findActiveSessions" parameterType="map" resultType="string">
                    SELECT CAST(CHAT_SQ AS text)
                    FROM SRP_AI_CHAT_MST
                    WHERE EMP_NO = #{actorEmpNo} AND <include refid="activeRoom"/>
                    ORDER BY UPDATED_DTTM DESC, CHAT_SQ DESC
                    LIMIT 1
                </select>

                <select id="findSession" parameterType="map" resultType="string">
                    SELECT CAST(CHAT_SQ AS text)
                    FROM SRP_AI_CHAT_MST
                    WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                      AND <include refid="activeRoom"/>
                </select>

                <select id="listOwnedRooms" parameterType="map" resultType="map">
                    SELECT CAST(CHAT_SQ AS text) AS room_index, CHAT_STAT_CD AS status
                    FROM SRP_AI_CHAT_MST
                    WHERE EMP_NO = #{actorEmpNo}
                    <if test="before != ''">AND CHAT_SQ &lt; CAST(#{before} AS bigint)</if>
                    ORDER BY CHAT_SQ DESC
                    LIMIT #{limit}
                </select>

                <select id="findRoomPreference" parameterType="map" resultType="string">
                    SELECT CAST(p.CHAT_SQ AS text)
                    FROM SRP_AI_CHAT_ROOM_PREF p
                    JOIN SRP_AI_CHAT_MST m ON m.CHAT_SQ = p.CHAT_SQ AND m.EMP_NO = p.EMP_NO
                    WHERE p.EMP_NO = #{actorEmpNo}
                </select>

                <select id="findOwnedRoom" parameterType="map" resultType="string">
                    SELECT CAST(CHAT_SQ AS text) FROM SRP_AI_CHAT_MST
                    WHERE EMP_NO = #{actorEmpNo} AND CHAT_SQ = CAST(#{chatSq} AS bigint)
                </select>

                <insert id="saveRoomPreference" parameterType="map">
                    INSERT INTO SRP_AI_CHAT_ROOM_PREF (EMP_NO, CHAT_SQ)
                    SELECT EMP_NO, CHAT_SQ FROM SRP_AI_CHAT_MST
                    WHERE EMP_NO = #{actorEmpNo} AND CHAT_SQ = CAST(#{chatSq} AS bigint)
                    ON CONFLICT (EMP_NO) DO UPDATE SET CHAT_SQ = EXCLUDED.CHAT_SQ
                </insert>

                <select id="findHistory" parameterType="map" resultType="map">
                    SELECT d.EMP_NO AS userid, CAST(d.CHAT_SQ AS text) AS room_index,
                           CAST(d.CHAT_INDEX AS text) AS chat_index, d.MESSAGE_CONT AS message,
                           to_char(d.SENT_AT AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS "time",
                           d.ISBOT_FG AS isbot, d.SELECD_FG AS slected
                    FROM SRP_AI_CAT_DTL d
                    JOIN SRP_AI_CHAT_MST m ON m.CHAT_SQ = d.CHAT_SQ
                    WHERE d.CHAT_SQ = CAST(#{chatSq} AS bigint) AND m.EMP_NO = #{actorEmpNo}
                      AND d.CHAT_INDEX &gt; #{afterSeq}
                    <if test="excludeCompletion">AND d.MESSAGE_KIND = 'MESSAGE'</if>
                    ORDER BY d.CHAT_INDEX
                    LIMIT #{limit}
                </select>

                <select id="findSendContext" parameterType="map" resultType="map">
                    SELECT AGENT_SESSION_ID AS agent_session_id, VISIBILITY AS visibility
                    FROM SRP_AI_CHAT_MST
                    WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                      AND <include refid="activeRoom"/>
                      AND AGENT_SESSION_ID IS NOT NULL AND VISIBILITY IS NOT NULL
                </select>

                <update id="refreshSessionSummary" parameterType="map">
                    UPDATE SRP_AI_CHAT_MST m
                    SET LAST_MESSAGE_CONT = (
                            SELECT d.MESSAGE_CONT FROM SRP_AI_CAT_DTL d
                            WHERE d.CHAT_SQ = m.CHAT_SQ ORDER BY d.CHAT_INDEX DESC LIMIT 1
                        ),
                        MESSAE_CNT = (SELECT COUNT(*) FROM SRP_AI_CAT_DTL d WHERE d.CHAT_SQ = m.CHAT_SQ),
                        UPDATED_DTTM = CURRENT_TIMESTAMP
                    WHERE m.CHAT_SQ = CAST(#{chatSq} AS bigint) AND m.EMP_NO = #{actorEmpNo}
                      AND <include refid="activeRoom"/>
                </update>

                <update id="closeActiveRoomForReset" parameterType="map">
                    UPDATE SRP_AI_CHAT_MST
                    SET CHAT_STAT_CD = 'CLOSED', USE_FG = 'N', UPDATED_DTTM = CURRENT_TIMESTAMP
                    WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                      AND <include refid="activeRoom"/>
                </update>

                <!-- Reset: lock, read active room, compare the submitted index, close if present,
                     and insert one replacement. A stale index fails before the close/insert. -->
                <insert id="insertChatMaster" parameterType="map" useGeneratedKeys="true"
                        keyProperty="chatSq" keyColumn="chat_sq">
                    INSERT INTO SRP_AI_CHAT_MST (EMP_NO, AGENT_SESSION_ID, VISIBILITY)
                    VALUES (#{actorEmpNo}, #{agentSessionId,jdbcType=VARCHAR}, #{visibility,jdbcType=VARCHAR})
                </insert>

                <update id="bindAgentSession" parameterType="map">
                    UPDATE SRP_AI_CHAT_MST
                    SET AGENT_SESSION_ID = #{agentSessionId}, VISIBILITY = #{visibility},
                        UPDATED_DTTM = CURRENT_TIMESTAMP
                    WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                      AND AGENT_SESSION_ID IS NULL AND <include refid="activeRoom"/>
                </update>

                <!-- Map user_message for request-ID/content verification before returning cached results. -->
                <select id="findSentMessage" parameterType="map" resultType="map">
                    SELECT u.MESSAGE_CONT AS user_message, CAST(b.CHAT_INDEX AS text) AS chat_index,
                           b.MESSAGE_CONT AS message,
                           to_char(b.SENT_AT AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS sent_at,
                           CAST(b.REFERENCES_JSON AS text) AS references_json
                    FROM SRP_AI_CAT_DTL u
                    JOIN SRP_AI_CAT_DTL b ON b.CHAT_SQ = u.CHAT_SQ AND b.REQUEST_ID = u.REQUEST_ID
                    JOIN SRP_AI_CHAT_MST m ON m.CHAT_SQ = u.CHAT_SQ
                    WHERE u.CHAT_SQ = CAST(#{chatSq} AS bigint) AND m.EMP_NO = #{actorEmpNo}
                      AND u.REQUEST_ID = #{messageId} AND u.ISBOT_FG = 'N' AND b.ISBOT_FG = 'Y'
                </select>

                <!-- Save a turn: lock, check replay, insert exactly two rows, refresh the summary,
                     and retrieve the committed reply index using findSentMessage. -->
                <insert id="insertMessagePair" parameterType="map">
                    WITH room AS (
                        SELECT CHAT_SQ
                        FROM SRP_AI_CHAT_MST
                        WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                          AND AGENT_SESSION_ID = #{agentSessionId} AND <include refid="activeRoom"/>
                    ), next_index AS (
                        SELECT r.CHAT_SQ, COALESCE(MAX(d.CHAT_INDEX), 0) + 1 AS first_index
                        FROM room r LEFT JOIN SRP_AI_CAT_DTL d ON d.CHAT_SQ = r.CHAT_SQ
                        GROUP BY r.CHAT_SQ
                    )
                    INSERT INTO SRP_AI_CAT_DTL
                        (CHAT_SQ, CHAT_INDEX, EMP_NO, MESSAGE_CONT, SENT_AT, ISBOT_FG,
                         MESSAGE_KIND, REQUEST_ID, REFERENCES_JSON)
                    SELECT CHAT_SQ, first_index, #{actorEmpNo}, #{content},
                           CAST(#{userSentAt,jdbcType=VARCHAR} AS timestamptz), 'N', 'MESSAGE', #{messageId}, NULL
                    FROM next_index
                    UNION ALL
                    SELECT CHAT_SQ, first_index + 1, #{actorEmpNo}, #{response},
                           CAST(#{sentAt,jdbcType=VARCHAR} AS timestamptz), 'Y', 'MESSAGE', #{messageId},
                           CAST(#{referencesJson,jdbcType=VARCHAR} AS jsonb)
                    FROM next_index
                </insert>

                <select id="findChatEnd" parameterType="map" resultType="map">
                    SELECT CAST(m.CHAT_SQ AS text) AS room_index, m.CHAT_STAT_CD AS status,
                           CAST(d.DRAFT_JSON AS text) AS draft_json
                    FROM SRP_AI_CHAT_MST m
                    LEFT JOIN SRP_AI_CAT_DTL d ON d.CHAT_SQ = m.CHAT_SQ AND d.MESSAGE_KIND = 'COMPLETE'
                    WHERE m.CHAT_SQ = CAST(#{chatSq} AS bigint) AND m.EMP_NO = #{actorEmpNo}
                      AND m.CHAT_STAT_CD IN ('COMPLETED', 'CANCELED')
                </select>

                <!-- Complete: after the AI draft is obtained, lock, check terminal replay,
                     insert the completion detail, refresh summary, and mark completed.
                     Require the expected row counts and roll back the entire transaction on failure. -->
                <insert id="insertCompletionDetail" parameterType="map">
                    INSERT INTO SRP_AI_CAT_DTL
                        (CHAT_SQ, CHAT_INDEX, EMP_NO, MESSAGE_CONT, SENT_AT, ISBOT_FG, MESSAGE_KIND, DRAFT_JSON)
                    SELECT m.CHAT_SQ, COALESCE(MAX(d.CHAT_INDEX), 0) + 1, m.EMP_NO,
                           #{message,jdbcType=VARCHAR}, CURRENT_TIMESTAMP, 'Y', 'COMPLETE',
                           CAST(#{draftJson,jdbcType=VARCHAR} AS jsonb)
                    FROM SRP_AI_CHAT_MST m
                    LEFT JOIN SRP_AI_CAT_DTL d ON d.CHAT_SQ = m.CHAT_SQ
                    WHERE m.CHAT_SQ = CAST(#{chatSq} AS bigint) AND m.EMP_NO = #{actorEmpNo}
                      AND m.AGENT_SESSION_ID = #{agentSessionId} AND <include refid="activeRoomForMaster"/>
                    GROUP BY m.CHAT_SQ, m.EMP_NO
                </insert>

                <sql id="activeRoomForMaster">
                    m.USE_FG = 'Y' AND m.CHAT_STAT_CD NOT IN ('CLOSED', 'COMPLETED', 'CANCELED')
                </sql>

                <update id="markChatCompleted" parameterType="map">
                    UPDATE SRP_AI_CHAT_MST
                    SET CHAT_STAT_CD = 'COMPLETED', UPDATED_DTTM = CURRENT_TIMESTAMP
                    WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                      AND AGENT_SESSION_ID = #{agentSessionId} AND <include refid="activeRoom"/>
                </update>

                <update id="markChatCanceled" parameterType="map">
                    UPDATE SRP_AI_CHAT_MST
                    SET CHAT_STAT_CD = 'CANCELED', UPDATED_DTTM = CURRENT_TIMESTAMP
                    WHERE CHAT_SQ = CAST(#{chatSq} AS bigint) AND EMP_NO = #{actorEmpNo}
                      AND AGENT_SESSION_ID = #{agentSessionId} AND <include refid="activeRoom"/>
                </update>
            </mapper>
            """;
}
