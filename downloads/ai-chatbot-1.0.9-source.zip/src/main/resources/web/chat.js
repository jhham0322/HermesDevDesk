"use strict";

const chatApi = new URL("chat/", document.currentScript.src);
const byId = id => document.getElementById(id);
const tokenInput = byId("token");
const messageInput = byId("message");
const messages = byId("messages");
const status = byId("status");
const list = byId("room-list");
const reviewType = byId("review-type");
const roomStatuses = {OPEN: "진행 중", COMPLETED: "완료", CANCELED: "취소", CLOSED: "종료"};
let token = "";
let activeRoom = "";
let selectedRoom = "";
let writable = false;
let pending = null;
let busy = false;
let nextRoom = "";

async function post(path, body = {}) {
    const response = await fetch(new URL(path, chatApi), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
        body: JSON.stringify({...body, review_type: reviewType.value})
    });
    const result = await response.json();
    if (!response.ok) {
        const error = new Error(result.error || "요청에 실패했습니다.");
        error.status = response.status;
        throw error;
    }
    return result;
}

async function run(action) {
    if (busy) return;
    busy = true;
    const controls = [...document.querySelectorAll("button, select, textarea")].filter(control => !control.disabled && !control.closest("#draft"));
    controls.forEach(control => { control.disabled = true; });
    status.textContent = "처리 중…";
    try {
        await action();
        if (status.textContent === "처리 중…") status.textContent = "";
    } catch (error) {
        status.textContent = error.message;
    } finally {
        controls.forEach(control => { control.disabled = false; });
        busy = false;
    }
}

function append(author, text) {
    const entry = document.createElement("li");
    entry.textContent = author + " · " + (text ?? "");
    messages.append(entry);
    messages.scrollTop = messages.scrollHeight;
}

function clearDraft() {
    byId("draft-title").value = "";
    byId("draft-description").value = "";
    byId("evidence-summary").textContent = "";
    byId("draft").hidden = byId("evidence-result").hidden = true;
}

function setWritable(enabled) {
    writable = enabled;
    byId("send").hidden = !enabled;
    byId("complete").hidden = byId("cancel").hidden = !enabled;
}

function selectHighlight() {
    for (const button of list.querySelectorAll("button")) {
        if (button.dataset.room === selectedRoom) button.setAttribute("aria-current", "true");
        else button.removeAttribute("aria-current");
    }
}

async function loadRooms(before = "") {
    const limit = 30;
    const result = await post("list", {before_room_index: before, limit});
    if (!before) {
        list.replaceChildren();
        selectedRoom = result.selected_room_index;
    }
    result.rooms.forEach(entry => {
        const row = document.createElement("li");
        const button = document.createElement("button");
        button.type = "button";
        button.dataset.room = entry.room_index;
        button.textContent = "대화 " + entry.room_index + " · " + (roomStatuses[entry.status] || "종료");
        row.append(button);
        list.append(row);
    });
    nextRoom = result.rooms.length === limit ? result.rooms.at(-1).room_index : "";
    byId("more-rooms").hidden = !nextRoom;
    byId("no-rooms").hidden = list.children.length > 0;
    byId("rooms").hidden = false;
    selectHighlight();
}

async function displayHistory(id, endpoint, mode) {
    let afterSeq = 0;
    const history = [];
    while (true) {
        const batchSize = 100;
        const page = await post(endpoint, {room_index: id, status: mode, afterSeq, limit: batchSize});
        id = page.room_index;
        const batch = page.messages || [];
        history.push(...batch);
        if (batch.length < batchSize) break;
        if (endpoint === "select") endpoint = "history";
        afterSeq = Number(batch.at(-1).chat_index);
        if (!Number.isSafeInteger(afterSeq)) throw new Error("메시지 순서를 읽을 수 없습니다.");
    }
    messages.replaceChildren();
    for (const entry of history) append(entry.isbot === "Y" ? "AI" : "나", entry.message);
    pending = null;
    clearDraft();
    messageInput.value = "";
    byId("viewed-room").textContent = "대화 " + id + (mode ? "" : " · 읽기 전용");
    byId("chat").hidden = false;
    setWritable(Boolean(mode));
    return id;
}

function updateChoices() {
    byId("resume").hidden = byId("choice-prompt").hidden = !activeRoom || writable;
}

async function connect() {
    activeRoom = selectedRoom = "";
    pending = null;
    setWritable(false);
    clearDraft();
    messages.replaceChildren();
    list.replaceChildren();
    byId("chat").hidden = byId("choice").hidden = byId("rooms").hidden = true;
    const result = await post("start");
    activeRoom = result.room_index;
    byId("choice").hidden = false;
    updateChoices();
    await loadRooms();
    if (selectedRoom) {
        try {
            await displayHistory(selectedRoom, "history");
        } catch (error) {
            if (error.status !== 404) throw error;
            selectedRoom = "";
            selectHighlight();
        }
    }
}

byId("access").addEventListener("submit", event => {
    event.preventDefault();
    run(async () => {
        token = tokenInput.value;
        tokenInput.value = "";
        await connect();
    });
});
reviewType.addEventListener("change", () => {
    if (token) run(connect);
});

list.addEventListener("click", event => {
    const button = event.target.closest("button[data-room]");
    if (!button) return;
    run(async () => {
        await displayHistory(button.dataset.room, "select");
        selectedRoom = button.dataset.room;
        selectHighlight();
        updateChoices();
    });
});
byId("more-rooms").addEventListener("click", () => run(() => loadRooms(nextRoom)));
byId("resume").addEventListener("click", () => run(async () => {
    await displayHistory(activeRoom, "continue", "R");
    updateChoices();
}));
byId("reset").addEventListener("click", () => run(async () => {
    activeRoom = await displayHistory(activeRoom, "continue", "N");
    updateChoices();
    await loadRooms();
}));

byId("send").addEventListener("submit", event => {
    event.preventDefault();
    const content = messageInput.value;
    if (!writable || !content.trim()) return;
    run(async () => {
        if (!pending || pending.content !== content) pending = {id: crypto.randomUUID(), content};
        const reply = await post("send", {room_index: activeRoom, type: "S", message: content, chat_index: pending.id});
        append("나", content);
        append("AI", reply.message);
        if (reply.references?.length) append("참고", JSON.stringify(reply.references));
        pending = null;
        messageInput.value = "";
    });
});

function finish(type) {
    return run(async () => {
        const result = await post("end", {room_index: activeRoom, type});
        activeRoom = "";
        pending = null;
        setWritable(false);
        updateChoices();
        status.textContent = type === "C" ? "작업이 완료됐습니다." : "채팅을 취소했습니다.";
        if (type === "C" && reviewType.value === "evidence") {
            byId("evidence-summary").textContent = result.draft?.summary ?? "";
            byId("evidence-result").hidden = false;
        } else if (type === "C") {
            byId("draft-title").value = result.draft?.title ?? "";
            byId("draft-description").value = result.draft?.description ?? "";
            byId("draft").hidden = false;
            byId("draft-title").focus();
        }
        await loadRooms();
    });
}

byId("complete").addEventListener("click", () => finish("C"));
byId("cancel").addEventListener("click", () => finish("X"));
