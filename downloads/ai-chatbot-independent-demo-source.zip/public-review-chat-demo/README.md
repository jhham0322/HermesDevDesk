# Independent review chat demo

새로 작성한 공개 후보입니다. 외부 코드·기존 저장소·사내 자료를 사용하지 않습니다. Java 17+; 합성 데이터만 허용합니다.

## 빠른 실행 (네트워크 불필요)
JDK 17+ (jdk.compiler 포함):
```sh
sh build-local.sh
java -cp build/classes demo.LocalDemo 8080
```
브라우저에서 http://127.0.0.1:8080/ . Ctrl+C로 종료합니다. 외부 주소에 바인딩하지 않습니다. 이 실행 모드는 JSP 엔진이 아닌 Java HTTP 어댑터이며 JSP와 같은 View를 렌더링합니다.

보안성 검토/보안증적 검토는 별도 대화로 시작합니다. 새 대화 생성, 목록 선택, 합성 질문 전송을 지원합니다. 마지막 선택은 로컬 모드에서 HttpOnly 쿠키로 복원합니다. 대화는 프로세스 메모리이므로 서버 재시작 시 사라집니다.

## JSP / Maven
```sh
mvn package
```
`target/review-chat-demo-1.0.0.war`를 별도 로컬 Tomcat 10.1+에 배포합니다. Maven은 최초 사용 시 플러그인 다운로드가 필요할 수 있습니다. 오프라인 Java 빌드는 `build/review-chat-demo.war`도 생성합니다. Tomcat은 loopback Connector와 작은 maxPostSize(8192 권장)로 제한하세요. 실제 운영 서버에 배포하지 마세요.
JSP는 HTTP 세션별 저장소와 마지막 대화 선택을 사용합니다. 같은 유효 세션의 재접속만 복원하며, 30분 세션 만료 또는 컨테이너 재시작 이후 영속 복원은 구현하지 않습니다.

## PostgreSQL / agent 경계
`sql/schema.sql`은 서로 분리된 두 예제 스키마와 대화·메시지·마지막 선택 테이블입니다. 실행 모드는 DB에 연결하지 않습니다. 영속 저장을 원하면 JDBC 저장소와 로그인된 owner_id 매핑을 별도로 구현해야 합니다. 스키마 분리만으로 사용자 권한이 보장되지는 않습니다.
`MockAgent`는 로컬 상수 응답만 반환합니다. `mock-webhook.json`은 합성 webhook 계약 예시일 뿐 실제 외부 webhook 엔드포인트/발송 기능은 없습니다. 외부 agent 연결 전 서명 검증·시간창·eventId 중복 방지·대화 소유권·허용 목적지를 구현하세요.

## 보안/운영 전 필수
- 인증 없는 단일 사용자 로컬 데모입니다. 인터넷/공용 프록시에 공개하지 마세요.
- 실제 환경은 OIDC 등 인증, 매 요청 소유권 검증, 세션 회전, TLS/Secure/SameSite 쿠키, CSRF, 접근 로그의 민감정보 마스킹이 필요합니다.
- DB 최소 권한 계정, 각 owner 범위 검증/RLS, 파라미터 SQL, 보존/삭제 정책 및 백업을 설계하세요.
- 실제 비밀·인증 토큰·회사 문서를 입력하지 마세요. AI 답변은 보안 승인이나 실제 증적이 아닙니다.
- 합성 webhook JSON을 그대로 신뢰하거나 실제 계정에 연결하지 마세요.
- 로컬 데모는 입력 크기/대화 수/메시지 수 제한과 HTML 이스케이프, CSRF, Host 검증, CSP를 적용합니다. 침투시험 완료 제품은 아닙니다.

## 검증 범위
`TEST-RESULTS.md` 참조. Java 컴파일·단위/HTTP 시험과 WAR 패키징을 실제 실행합니다. Maven 및 JSP 컨테이너, PostgreSQL 실행은 도구가 없으면 미검증으로 명시합니다.
