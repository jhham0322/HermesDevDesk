#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes build/test-classes
java com.sun.tools.javac.Main -source 17 -target 17 -encoding UTF-8 -d build/classes src/main/java/demo/*.java
java com.sun.tools.javac.Main -source 17 -target 17 -encoding UTF-8 -cp build/classes -d build/test-classes src/test/java/demo/*.java
java -cp build/classes:build/test-classes demo.DemoTest
mkdir -p build/war/WEB-INF/classes
cp -R src/main/webapp/. build/war/
cp -R build/classes/demo build/war/WEB-INF/classes/
java sun.tools.jar.Main --create --file build/review-chat-demo.war -C build/war .
