import subprocess,time,urllib.request,urllib.parse,urllib.error,re,http.cookiejar
p=subprocess.Popen(['java','-cp','build/classes','demo.LocalDemo','18089'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
n=0
try:
 for _ in range(40):
  try:
   cj=http.cookiejar.CookieJar();o=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj));base='http://127.0.0.1:18089/'
   r=o.open(base);h=r.read().decode();break
  except OSError:time.sleep(.1)
 else:raise AssertionError('server did not start')
 def check(b):
  global n
  n+=1
  assert b,n
 check('보안성 검토 예제' in h and '보안증적 검토 예제' in h)
 csrf=re.search("name='csrf' value='([^']+)'",h)[1]
 ids=re.findall("href='\?chat=([^']+)'",h)
 data=urllib.parse.urlencode({'csrf':csrf,'action':'send','chat':ids[1],'text':'<script>synthetic</script>'}).encode()
 h=o.open(base,data=data).read().decode();check('&lt;script&gt;synthetic' in h);check('[합성 응답]' in h)
 h=o.open(base).read().decode();check('&lt;script&gt;synthetic' in h)
 h=o.open(base+'?chat='+ids[0]).read().decode();check('&lt;script&gt;synthetic' not in h)
 for req,expected in [(urllib.request.Request(base,data=b'action=send'),403),(urllib.request.Request(base,headers={'Host':'evil.invalid'}),403),(urllib.request.Request(base+'missing'),404),(urllib.request.Request(base,data=b'x'*8193),413)]:
  try:o.open(req);raise AssertionError('expected rejection')
  except urllib.error.HTTPError as e:check(e.code==expected)
 h=o.open(base,data=urllib.parse.urlencode({'csrf':csrf,'action':'create','kind':'security'}).encode()).read().decode();check('새 보안성 검토' in h)
 try:
  o.open(base,data=urllib.parse.urlencode({'csrf':csrf,'action':'create'}).encode());raise AssertionError('missing kind must fail')
 except urllib.error.HTTPError as e:check(e.code==400)
 print('PASS',n,'HTTP assertions; synthetic loopback only')
finally:
 p.terminate();p.wait(timeout=5)
