-- PostgreSQL example ONLY. Not connected to the memory-only local demo.
-- Run in a disposable empty database after review; no credentials included.
BEGIN;
CREATE SCHEMA security_review;
CREATE SCHEMA evidence_review;
CREATE TABLE security_review.conversation (id uuid PRIMARY KEY, owner_id uuid NOT NULL, title text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,owner_id));
CREATE TABLE security_review.message (id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, conversation_id uuid NOT NULL REFERENCES security_review.conversation(id), role text NOT NULL CHECK(role IN ('user','agent')), body text NOT NULL CHECK(length(body)<=10000), created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE evidence_review.conversation (id uuid PRIMARY KEY, owner_id uuid NOT NULL, title text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,owner_id));
CREATE TABLE evidence_review.message (id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, conversation_id uuid NOT NULL REFERENCES evidence_review.conversation(id), role text NOT NULL CHECK(role IN ('user','agent')), body text NOT NULL CHECK(length(body)<=10000), created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE security_review.last_selection (owner_id uuid PRIMARY KEY, conversation_id uuid NOT NULL, FOREIGN KEY(conversation_id,owner_id) REFERENCES security_review.conversation(id,owner_id));
CREATE TABLE evidence_review.last_selection (owner_id uuid PRIMARY KEY, conversation_id uuid NOT NULL, FOREIGN KEY(conversation_id,owner_id) REFERENCES evidence_review.conversation(id,owner_id));
REVOKE ALL ON SCHEMA security_review,evidence_review FROM PUBLIC;
COMMIT;
-- Production requires separate least-privilege DB roles, owner-scoped queries or RLS,
-- parameterized SQL, encrypted transport, migrations and retention/deletion policy.
