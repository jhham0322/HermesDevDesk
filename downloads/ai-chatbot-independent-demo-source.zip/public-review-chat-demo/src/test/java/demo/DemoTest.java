package demo;
public class DemoTest {
 static int n;static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
 public static void main(String[]args){ChatStore s=new ChatStore();check(s.list().size()==2);var a=s.list().get(0);var b=s.list().get(1);s.send(a.id(),"<script>alert(1)</script>");check(s.get(a.id()).messages().size()==2);check(s.get(b.id()).messages().isEmpty());check(!View.render(s,a.id(),"test").contains("<script>"));check(View.render(s,a.id(),"test").contains("&lt;script&gt;"));check(MockAgent.reply("evidence","x").contains("증적"));try{s.send("missing","x");throw new AssertionError();}catch(IllegalArgumentException ok){n++;}try{s.create("other","x");throw new AssertionError();}catch(IllegalArgumentException ok){n++;}try{s.send(a.id()," ");throw new AssertionError();}catch(IllegalArgumentException ok){n++;}check(s.create("evidence","new").kind().equals("evidence"));System.out.println("PASS "+n+" assertions");}
}
