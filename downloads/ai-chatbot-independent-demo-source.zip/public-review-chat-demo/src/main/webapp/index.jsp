<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" import="demo.*,java.util.UUID" %><%
request.setCharacterEncoding("UTF-8");
response.setHeader("Cache-Control","no-store");
response.setHeader("X-Content-Type-Options","nosniff");
response.setHeader("Content-Security-Policy","default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
ChatStore store=(ChatStore)session.getAttribute("demoStore");
if(store==null){store=new ChatStore();session.setAttribute("demoStore",store);}
String csrf=(String)session.getAttribute("csrf");
if(csrf==null){csrf=UUID.randomUUID().toString();session.setAttribute("csrf",csrf);}
String selected=request.getParameter("chat");
if(selected==null)selected=(String)session.getAttribute("lastChat");
if("POST".equals(request.getMethod())){
 if(!csrf.equals(request.getParameter("csrf"))){response.sendError(403);return;}
 try{
  if("create".equals(request.getParameter("action"))){String k=request.getParameter("kind");selected=store.create(k,"security".equals(k)?"새 보안성 검토":"새 보안증적 검토").id();}
  else if("send".equals(request.getParameter("action"))){store.send(selected,request.getParameter("text"));}
  else throw new IllegalArgumentException();
  session.setAttribute("lastChat",selected);response.sendRedirect("index.jsp?chat="+selected);return;
 }catch(IllegalArgumentException e){response.sendError(400);return;}
}
if(selected!=null){try{store.get(selected);session.setAttribute("lastChat",selected);}catch(IllegalArgumentException e){selected=null;}}
out.print(View.render(store,selected,csrf));
%>