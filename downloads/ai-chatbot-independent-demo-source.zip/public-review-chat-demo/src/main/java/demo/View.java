package demo;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
public final class View {
 public static String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
 public static String render(ChatStore store,String selected,String csrf){
  var chats=store.list();if(selected==null||selected.isBlank())selected=chats.get(0).id();
  ChatStore.Chat active;try{active=store.get(selected);}catch(IllegalArgumentException e){active=chats.get(0);}
  StringBuilder h=new StringBuilder("<!doctype html><html lang='ko'><meta charset='UTF-8'><meta name='viewport' content='width=device-width'><title>독립 검토 채팅 데모</title><style>body{font:16px system-ui;max-width:980px;margin:30px auto;padding:16px;background:#f4f6fa}main{display:grid;grid-template-columns:240px 1fr;gap:24px}nav,section{background:white;padding:20px;border-radius:12px}a{display:block;padding:8px}textarea{width:95%;min-height:90px}button{padding:10px}article{white-space:pre-wrap;border-bottom:1px solid #ddd;padding:12px}@media(max-width:600px){main{display:block}}</style><h1>검토 채팅</h1><p>로컬 합성 데모 · 실제 비밀/사내 자료를 입력하지 마세요.</p><main><nav><h2>대화 목록</h2>");
  for(var c:chats)h.append("<a href='?chat=").append(c.id()).append("'>").append(esc(c.title())).append("</a>");
  h.append("<form method='post'><input type='hidden' name='csrf' value='").append(esc(csrf)).append("'><input type='hidden' name='action' value='create'><select name='kind'><option value='security'>보안성 검토</option><option value='evidence'>보안증적 검토</option></select><button>새 대화</button></form></nav><section><h2>").append(esc(active.title())).append("</h2>");
  for(var m:active.messages())h.append("<article><b>").append(esc(m.role())).append("</b>: ").append(esc(m.text())).append("</article>");
  h.append("<form method='post'><input type='hidden' name='csrf' value='").append(esc(csrf)).append("'><input type='hidden' name='action' value='send'><input type='hidden' name='chat' value='").append(active.id()).append("'><label>합성 질문<textarea name='text' maxlength='2000' required></textarea></label><button>보내기</button></form><p>동일 브라우저 재접속 시 마지막 선택 복원. 서버 재시작 시 데모 대화 초기화.</p></section></main></html>");return h.toString();
 }
}
