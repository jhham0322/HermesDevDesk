package demo;
/** Replace only after authentication, authorization and webhook signature verification are designed. */
public final class MockAgent {
 private MockAgent(){}
 public static String reply(String kind,String input){return kind.equals("security")?
  "[합성 응답] 접근 제어·입력 검증·로그 보존을 점검하세요. 실제 보안 판정이 아닙니다.":
  "[합성 응답] 증적의 작성일·담당자·검토 범위를 확인하세요. 실제 증적을 수집하지 않습니다.";}
}
