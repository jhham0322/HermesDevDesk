package demo;
import com.sun.net.httpserver.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;
/** No JSP engine: standalone adapter renders the same Java view used by index.jsp. */
public final class LocalDemo {
 private final ChatStore store=new ChatStore();private final String csrf=UUID.randomUUID().toString();
 public static void main(String[] args)throws Exception{int port=args.length==0?8080:Integer.parseInt(args[0]);new LocalDemo().start(port);}
 void start(int port)throws Exception {var server=HttpServer.create(new InetSocketAddress("127.0.0.1",port),0);server.createContext("/",this::handle);server.start();System.out.println("LOCAL_DEMO http://127.0.0.1:"+port);}
 static Map<String,String> params(String raw){Map<String,String> m=new HashMap<>();if(raw!=null)for(String part:raw.split("&")){String[] a=part.split("=",2);m.put(URLDecoder.decode(a[0],StandardCharsets.UTF_8),a.length==2?URLDecoder.decode(a[1],StandardCharsets.UTF_8):"");}return m;}
 void handle(HttpExchange x)throws java.io.IOException{
  x.getResponseHeaders().set("Content-Type","text/html; charset=UTF-8");x.getResponseHeaders().set("X-Content-Type-Options","nosniff");x.getResponseHeaders().set("Cache-Control","no-store");x.getResponseHeaders().set("Content-Security-Policy","default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
  try{
   if(!x.getRequestURI().getPath().equals("/")){reply(x,404,"Not found");return;}
   String host=x.getRequestHeaders().getFirst("Host");if(host==null||!host.equals("127.0.0.1:"+x.getLocalAddress().getPort())){reply(x,403,"Host rejected");return;}
   String selected=params(x.getRequestURI().getRawQuery()).get("chat");
   if(selected==null){String cookies=x.getRequestHeaders().getFirst("Cookie");if(cookies!=null)for(String c:cookies.split(";"))if(c.trim().startsWith("demoLast="))selected=c.trim().substring(9);}
   if(x.getRequestMethod().equals("POST")){
    byte[] bytes=x.getRequestBody().readNBytes(8193);if(bytes.length>8192){reply(x,413,"Too large");return;}
    var f=params(new String(bytes,StandardCharsets.UTF_8));if(!csrf.equals(f.get("csrf"))){reply(x,403,"CSRF rejected");return;}
    if("create".equals(f.get("action"))){String k=f.get("kind");if(k==null)throw new IllegalArgumentException("missing kind");selected=store.create(k,"security".equals(k)?"새 보안성 검토":"새 보안증적 검토").id();}
    else if("send".equals(f.get("action"))){selected=f.get("chat");store.send(selected,f.get("text"));}else throw new IllegalArgumentException("action");
    x.getResponseHeaders().set("Location","/?chat="+selected);x.sendResponseHeaders(303,-1);x.close();return;
   }else if(!x.getRequestMethod().equals("GET")){reply(x,405,"Method not allowed");return;}
   if(selected!=null){try{store.get(selected);x.getResponseHeaders().add("Set-Cookie","demoLast="+selected+"; Path=/; Max-Age=2592000; HttpOnly; SameSite=Strict");}catch(IllegalArgumentException ignored){selected=null;}}
   reply(x,200,View.render(store,selected,csrf));
  }catch(IllegalArgumentException e){reply(x,400,"Invalid demo input");}
 }
 static void reply(HttpExchange x,int status,String body)throws java.io.IOException{byte[] b=body.getBytes(StandardCharsets.UTF_8);x.sendResponseHeaders(status,b.length);x.getResponseBody().write(b);x.close();}
}
