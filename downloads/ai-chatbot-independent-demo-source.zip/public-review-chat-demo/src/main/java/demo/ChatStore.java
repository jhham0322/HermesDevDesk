package demo;
import java.util.*;
/** Synthetic, single-user, memory-only repository. No production data or outbound calls. */
public final class ChatStore {
 public record Message(String role,String text) {}
 public record Chat(String id,String kind,String title,List<Message> messages) {}
 private final Map<String,Chat> chats=new LinkedHashMap<>();
 public ChatStore(){ create("security","보안성 검토 예제");create("evidence","보안증적 검토 예제"); }
 public synchronized Chat create(String kind,String title){
  if(!Set.of("security","evidence").contains(kind))throw new IllegalArgumentException("invalid kind");
  if(chats.size()>=100)throw new IllegalArgumentException("demo conversation limit");
  String id=UUID.randomUUID().toString(); Chat c=new Chat(id,kind,title,new ArrayList<>());chats.put(id,c);return copy(c);
 }
 private Chat copy(Chat c){return new Chat(c.id(),c.kind(),c.title(),List.copyOf(c.messages()));}
 public synchronized List<Chat> list(){return chats.values().stream().map(this::copy).toList();}
 public synchronized Chat get(String id){Chat c=chats.get(id);if(c==null)throw new IllegalArgumentException("unknown chat");return copy(c);}
 public synchronized void send(String id,String text){
  get(id);if(text==null||text.isBlank()||text.length()>2000)throw new IllegalArgumentException("1–2000 characters required");
  Chat c=chats.get(id);if(c.messages().size()>=200)throw new IllegalArgumentException("demo message limit");
  c.messages().add(new Message("user",text));
  c.messages().add(new Message("agent",MockAgent.reply(c.kind(),text)));
 }
}
