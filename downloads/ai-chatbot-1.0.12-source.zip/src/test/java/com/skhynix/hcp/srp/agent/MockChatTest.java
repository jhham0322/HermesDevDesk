package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.net.URI;
import java.nio.ByteBuffer;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Flow;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

class MockChatTest {
    private static final String TOKEN = "synthetic-employee-token-000000001";
    private static final String OTHER = "synthetic-employee-token-000000002";
    private final ObjectMapper json = new ObjectMapper();
    private final Map<String, Integer> requests = new HashMap<>();
    private final AiHelperHttpClient helper = new AiHelperHttpClient(json, URI.create("http://127.0.0.1"),
            "", "/mock/open", "/mock/close", request -> {
        String path = request.uri().getPath();
        requests.merge(path, 1, Integer::sum);
        JsonNode input = json.readTree(readBody(request.bodyPublisher().orElseThrow()));
        assertEquals("EMP1", input.path("emp_no").asText());
        Object reply = switch (path) {
            case "/mock/open" -> Map.of("session_id", "demo-session");
            case "/api/v1/sr/helper/message" -> {
                assertEquals("demo-session", input.path("session_id").asText());
                assertEquals("fixture", input.path("visibility").asText());
                assertTrue(input.path("sent_at").asText().endsWith("+09:00"));
                yield Map.of("message", "answer", "sent_at", "2026-11-19T19:00:00+09:00");
            }
            case "/api/v1/sr/helper/complete" -> Map.of("draft",
                    Map.of("title", " draft ", "description", "local notes", "unknown", "omit"));
            case "/mock/close" -> Map.of();
            default -> throw new AssertionError(path);
        };
        int status = "fail".equals(input.path("message").asText()) ? 503 : 200;
        if (path.equals(AiHelperHttpClient.MESSAGE_PATH) || path.equals(AiHelperHttpClient.COMPLETE_PATH)) {
            reply = status == 200 ? Map.of("responseAt", "2026-11-19T19:00:00+09:00", "message", "fixture success", "data", reply)
                    : Map.of("error", Map.of("code", "SR-HELPER-UNAVAILABLE", "message", "Fixture unavailable."),
                            "responseAt", "2026-11-19T19:00:00+09:00", "message", "failed", "data", Map.of());
        }
        return new AiHelperHttpClient.Reply(status, json.writeValueAsBytes(reply));
    });
    private final MemoryChatStore store = new MemoryChatStore(helper);
    private final ChatServlet servlet = new ChatServlet(json, store, helper, Map.of("EMP1", TOKEN, "EMP2", OTHER), store::ordered);

    @Test
    void chatFlowWithMockApi() throws Exception {
        call("start", "", Map.of(), 401);
        assertEquals("", call("start", TOKEN, Map.of(), 200).path("room_index").asText());
        String room = call("continue", TOKEN, Map.of("status", "N"), 200).path("room_index").asText();
        assertFalse(room.isBlank());
        assertEquals(room, call("start", TOKEN, Map.of(), 200).path("room_index").asText());
        var resume = Map.of("status", "R", "room_index", room);
        call("continue", OTHER, resume, 404);
        call("send", TOKEN, send(room, "fail", "failed"), 502);
        var firstTurn = send(room, "first", "1");
        var first = call("send", TOKEN, firstTurn, 200);
        assertEquals(first, call("send", TOKEN, firstTurn, 200));
        call("send", TOKEN, send(room, "second", "2"), 200);
        JsonNode resumed = call("continue", TOKEN, resume, 200);
        assertEquals(room, resumed.path("room_index").asText());
        JsonNode history = resumed.path("messages");
        assertEquals(4, history.size());
        assertEquals(List.of("first", "answer", "second", "answer"),
                java.util.stream.StreamSupport.stream(history.spliterator(), false)
                        .map(n -> n.path("message").asText()).toList());
        assertEquals(3, requests.get("/api/v1/sr/helper/message"));

        var complete = Map.of("room_index", room, "type", "C");
        JsonNode done = call("end", TOKEN, complete, 200);
        assertEquals("COMPLETED", done.path("status").asText());
        assertEquals(json.<JsonNode>valueToTree(Map.of("title", "draft", "description", "local notes")), done.path("draft"));
        assertEquals(done, call("end", TOKEN, complete, 200));
        assertEquals(1, requests.get("/api/v1/sr/helper/complete"));
        call("end", TOKEN, Map.of("room_index", room, "type", "X"), 409);

        String next = call("continue", TOKEN, Map.of("status", "N"), 200).path("room_index").asText();
        assertNotEquals(room, next);
        JsonNode canceled = call("end", TOKEN, Map.of("room_index", next, "type", "X"), 200);
        assertEquals("CANCELED", canceled.path("status").asText());
        assertTrue(canceled.path("draft").isNull());
        assertEquals(1, requests.get("/mock/close"));
        assertEquals(1, requests.get("/api/v1/sr/helper/complete"));
    }

    @Test
    void retainsExplicitSelectionAndProtectsReadOnlyHistory() throws Exception {
        String older = call("continue", TOKEN, Map.of("status", "N"), 200).path("room_index").asText();
        call("send", TOKEN, send(older, "older message", "older"), 200);
        String newer = call("continue", TOKEN, Map.of("status", "N", "room_index", older), 200)
                .path("room_index").asText();
        assertNotEquals(older, newer);
        var before = Map.copyOf(requests);
        var query = Map.of("room_index", older);
        assertEquals(2, call("select", TOKEN, query, 200).path("messages").size());
        assertEquals(older, call("list", TOKEN, Map.of(), 200).path("selected_room_index").asText());
        assertEquals(older, call("history", TOKEN, query, 200).path("room_index").asText());
        assertEquals(newer, call("start", TOKEN, Map.of(), 200).path("room_index").asText());
        assertTrue(call("list", OTHER, Map.of(), 200).path("rooms").isEmpty());
        assertEquals("", call("list", OTHER, Map.of(), 200).path("selected_room_index").asText());
        call("select", OTHER, query, 404);
        call("history", OTHER, query, 404);
        call("list", TOKEN, Map.of("review_type", "evidence"), 409);
        assertEquals(before, requests);
    }

    @Test
    void initializesDedicatedEvidenceMapperWithoutAConnection() throws Exception {
        assertDoesNotThrow(() -> new com.skhynix.hcp.srp.agent.ai.AiEvidenceReviewChat(
                "jdbc:postgresql://127.0.0.1:5432/db", "synthetic", "", json, helper::openSession, "fixture"));
    }

    private static Map<String, String> send(String room, String text, String id) {
        return Map.of("room_index", room, "message", text, "chat_index", id, "type", "S");
    }

    private JsonNode call(String action, String token, Map<String, ?> data, int expected) throws Exception {
        var request = new MockHttpServletRequest("POST", "/chat/" + action);
        request.addHeader("Authorization", "Bearer " + token);
        request.setContent(json.writeValueAsBytes(data));
        var response = new MockHttpServletResponse();
        servlet.service(request, response);
        assertEquals(expected, response.getStatus(), response.getContentAsString());
        return json.readTree(response.getContentAsByteArray());
    }

    private static byte[] readBody(java.net.http.HttpRequest.BodyPublisher publisher) {
        var result = new CompletableFuture<byte[]>();
        var buffer = new ByteArrayOutputStream();
        publisher.subscribe(new Flow.Subscriber<ByteBuffer>() {
            @Override public void onSubscribe(Flow.Subscription subscription) { subscription.request(Long.MAX_VALUE); }
            @Override public void onNext(ByteBuffer chunk) {
                byte[] bytes = new byte[chunk.remaining()];
                chunk.get(bytes);
                buffer.writeBytes(bytes);
            }
            @Override public void onError(Throwable error) { result.completeExceptionally(error); }
            @Override public void onComplete() { result.complete(buffer.toByteArray()); }
        });
        return result.join();
    }

}

/** Test double. PostgreSQL ownership, transactions and schema are exercised by ChatIntegrationCheck. */
final class MemoryChatStore implements AiApiService.EndStore, AiApiService.SessionTransaction, AiApiService.RoomDirectory {
    private final AiHelperHttpClient helper;
    private final Map<String, String> active = new HashMap<>();
    private final Map<String, Room> rooms = new HashMap<>();
    private final Map<String, String> selected = new HashMap<>();
    private final java.util.concurrent.atomic.AtomicLong sequence;

    MemoryChatStore(AiHelperHttpClient helper) {
        this(helper, new java.util.concurrent.atomic.AtomicLong());
    }

    MemoryChatStore(AiHelperHttpClient helper, java.util.concurrent.atomic.AtomicLong sequence) {
        this.helper = helper;
        this.sequence = sequence;
    }

    @Override public AiApiService.RoomList listRooms(String actor, String before, int limit) {
        long boundary = before.isEmpty() ? Long.MAX_VALUE : Long.parseLong(before);
        var page = rooms.entrySet().stream()
                .filter(entry -> entry.getValue().owner.equals(actor) && Long.parseLong(entry.getKey()) < boundary)
                .sorted((a, b) -> Long.compare(Long.parseLong(b.getKey()), Long.parseLong(a.getKey())))
                .limit(limit)
                .map(entry -> new AiApiService.RoomSummary(entry.getKey(), entry.getValue().status)).toList();
        return new AiApiService.RoomList(page, selected.getOrDefault(actor, ""));
    }

    @Override public List<AiApiService.Message> readRoom(String room, String actor, long after, int limit, boolean remember) {
        Room state = rooms.get(room);
        if (state == null || !state.owner.equals(actor)) throw new java.util.NoSuchElementException("Chat room was not found.");
        if (remember) selected.put(actor, room);
        return findHistory(room, actor, after, limit);
    }

    synchronized Object ordered(String actor, Supplier<Object> work) {
        return work.get();
    }

    @Override public Optional<String> findActiveSessions(String actor) {
        return Optional.ofNullable(active.get(actor));
    }

    @Override public <T> T inSessionTransaction(String actor, Function<AiApiService.SessionTransaction, T> action) {
        return action.apply(this);
    }

    @Override public Optional<String> findSession(String room, String actor) {
        return findActiveSessions(actor).filter(room::equals);
    }

    @Override public List<AiApiService.Message> findHistory(String room, String actor, long after, int limit) {
        return rooms.get(room).history.stream().skip(after).limit(limit).toList();
    }

    @Override public void refreshSessionSummary(String room, String actor) {
        // The test double keeps the history directly.
    }

    @Override public String resetSession(String expected, String actor) {
        if (!expected.equals(active.getOrDefault(actor, ""))) throw new IllegalStateException("Active room changed.");
        if (!expected.isEmpty()) rooms.get(expected).status = "CLOSED";
        String id = Long.toString(sequence.incrementAndGet());
        active.put(actor, id);
        rooms.put(id, new Room(actor));
        return id;
    }

    @Override public Optional<AiApiService.SendContext> findSendContext(String room, String actor) {
        return findSession(room, actor).map(id -> {
            Room state = rooms.get(id);
            if (state.session == null) state.session = helper.openSession(actor, "fixture", id);
            return new AiApiService.SendContext(state.session, "fixture");
        });
    }

    @Override public Optional<AiApiService.SentMessage> findSentMessage(String room, String actor, String id, String content) {
        Turn turn = rooms.get(room).turns.get(id);
        if (turn == null) return Optional.empty();
        if (!turn.content.equals(content)) throw new IllegalStateException("Message ID was already used.");
        return Optional.of(turn.reply);
    }

    @Override public AiApiService.SentMessage saveTurn(String room, String actor, String id, String content,
                                                       Instant sent, String session, AiApiService.HelperResponse reply) {
        Room state = rooms.get(room);
        state.append(room, content, sent.toString(), "N");
        state.append(room, reply.message, reply.sent_at, "Y");
        var saved = new AiApiService.SentMessage(Integer.toString(state.history.size()), reply);
        state.turns.put(id, new Turn(content, saved));
        return saved;
    }

    @Override public Optional<AiApiService.ChatEnd> findChatEnd(String room, String actor) {
        return Optional.ofNullable(rooms.get(room)).filter(state -> state.owner.equals(actor)).map(state -> state.end);
    }

    @Override public AiApiService.ChatEnd saveChatEnd(String room, String actor, String session, AiApiService.ChatEnd result) {
        rooms.get(room).end = result;
        rooms.get(room).status = result.status.name();
        active.remove(actor);
        return result;
    }

    private record Turn(String content, AiApiService.SentMessage reply) {}

    private static final class Room {
        final String owner;
        final List<AiApiService.Message> history = new ArrayList<>();
        final Map<String, Turn> turns = new HashMap<>();
        String session;
        String status = "OPEN";
        AiApiService.ChatEnd end;

        Room(String owner) {
            this.owner = owner;
        }

        void append(String room, String message, String time, String bot) {
            history.add(new AiApiService.Message(owner, room, Integer.toString(history.size() + 1),
                    message, time, bot, "N"));
        }
    }
}
