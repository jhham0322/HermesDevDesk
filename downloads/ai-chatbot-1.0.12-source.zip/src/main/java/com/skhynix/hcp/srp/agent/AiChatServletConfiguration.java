package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.net.URI;

/** Import explicitly from the host application's Spring Boot configuration. */
public class AiChatServletConfiguration {
    static final String CHAT2_SEND_PATH = "/api/ai-agent/chat2/send";

    @Bean
    public ServletRegistrationBean<HttpServlet> chatServletRegistration(Environment env) throws IOException {
        var json = new ObjectMapper();
        var helper = new AiHelperHttpClient(json, URI.create(env.getRequiredProperty("AI_BASE_URL")),
                env.getProperty("AI_TOKEN", ""), env.getRequiredProperty("AI_OPEN_PATH"),
                env.getRequiredProperty("AI_CLOSE_PATH"));
        var store = new PostgresChatStore(env.getRequiredProperty("CHAT_DB_URL"),
                env.getRequiredProperty("CHAT_DB_USER"), env.getProperty("CHAT_DB_PASSWORD", ""),
                json, helper, env.getRequiredProperty("AI_VISIBILITY"));
        var tokens = json.readValue(env.getRequiredProperty("CHAT_USER_TOKENS_JSON"),
                new TypeReference<java.util.Map<String, String>>() {});
        return registration(new ChatServlet(json, store, helper, tokens, store::ordered));
    }

    static ServletRegistrationBean<HttpServlet> registration(ChatServlet servlet) {
        var registration = new ServletRegistrationBean<HttpServlet>(servlet,
                "/chat.js", "/chat/*", "/chat1", "/chat2", "/chat2.jsp", CHAT2_SEND_PATH);
        registration.setName("aiChatServlet");
        return registration;
    }
}
