package com.skhynix.hcp.srp.agent;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

@FunctionalInterface
public interface AiApiService {
    /**
     * Reads the existing active room for this employee or returns an empty result.
     * The adapter applies the existing PostgreSQL active-session selection rules.
     */
    Optional<String> findActiveSessions(String actorEmpNo);

    interface ContinueStore extends AiApiService {
        /**
         * Runs on one PostgreSQL transaction. Serialize changes for this employee,
         * even when there is no existing room, and roll back on failure.
         */
        <T> T inSessionTransaction(String actorEmpNo, Function<SessionTransaction, T> action);
    }

    interface SessionTransaction {
        /** Finds a resumable room owned by the authenticated employee. */
        Optional<String> findSession(String chatSq, String actorEmpNo);

        /** Returns at most limit messages with sequence greater than afterSeq, in ascending order. */
        List<Message> findHistory(String chatSq, String actorEmpNo, long afterSeq, int limit);

        /** Refreshes LAST_MESSAGE_CONT, MESSAE_CNT and UPDATED_DTTM from the full room history. */
        void refreshSessionSummary(String chatSq, String actorEmpNo);

        /**
         * Closes the employee's active room (CHAT_STAT_CD=CLOSED, USE_FG=N) and inserts
         * one MST row. A supplied room index must match the active room. An empty index
         * means the UI found no active room. Reject stale selections before changing rows.
         */
        String resetSession(String expectedRoomIndex, String actorEmpNo);
    }

    interface RoomDirectory extends AiApiService {
        RoomList listRooms(String actorEmpNo, String before, int limit);

        List<Message> readRoom(String room, String actorEmpNo, long after, int limit, boolean remember);
    }

    record RoomSummary(String room_index, String status) {}

    record RoomList(List<RoomSummary> rooms, String selected_room_index) {}

    interface SendStore extends ContinueStore {
        /** Resolves the AI session and visibility for an active room owned by this employee. */
        Optional<SendContext> findSendContext(String chatSq, String actorEmpNo);

        /** Finds a committed response for this room and message ID. Reject reuse with different content. */
        Optional<SentMessage> findSentMessage(String chatSq, String actorEmpNo, String messageId, String content);

        /**
         * In one PostgreSQL transaction, recheck room ownership, active state and AI session,
         * then insert consecutive user and AI detail rows and update the MST summary.
         * Serialize with reset and other sends. If this ID was committed concurrently with
         * the same content, return that response instead of inserting a second pair.
         */
        SentMessage saveTurn(String chatSq, String actorEmpNo, String messageId,
                             String content, Instant userSentAt, String agentSessionId, HelperResponse response);
    }

    interface EndStore extends SendStore {
        /** Reads a persisted terminal result for a room owned by this employee. */
        Optional<ChatEnd> findChatEnd(String chatSq, String actorEmpNo);

        /**
         * In one PostgreSQL transaction, recheck ownership, active state and AI session.
         * For COMPLETED, insert the AI completion response into DTL and update MST
         * status and summary. For CANCELED, persist the cancellation in MST.
         * Preserve an already committed result for the same action and reject an
         * incompatible terminal state. Serialize with sends and reset.
         */
        ChatEnd saveChatEnd(String chatSq, String actorEmpNo, String agentSessionId, ChatEnd result);
    }

    @FunctionalInterface
    interface HelperClient {
        /** Posts to /api/v1/sr/helper/message and returns a successfully decoded response. */
        HelperResponse postMessage(HelperRequest request);
    }

    interface ClosingHelperClient extends HelperClient {
        /** Posts to /api/v1/sr/helper/complete and returns the decoded draft. */
        Object complete(String agentSessionId, String actorEmpNo);

        /** Closes the AI session. Report a remote failure by throwing. */
        void closeSession(String agentSessionId, String actorEmpNo);
    }

    enum ChatEndStatus {
        COMPLETED, CANCELED
    }

    final class ChatEnd {
        public final String room_index;
        public final ChatEndStatus status;
        public final Object draft;

        public ChatEnd(String roomIndex, ChatEndStatus status, Object draft) {
            this.room_index = Objects.requireNonNull(roomIndex, "roomIndex");
            this.status = Objects.requireNonNull(status, "status");
            this.draft = draft;
        }
    }

    final class SendContext {
        public final String agentSessionId;
        public final String visibility;

        public SendContext(String agentSessionId, String visibility) {
            this.agentSessionId = Objects.requireNonNull(agentSessionId, "agentSessionId");
            this.visibility = Objects.requireNonNull(visibility, "visibility");
        }
    }

    final class HelperRequest {
        public final String session_id;
        public final String message;
        public final String visibility;
        public final String emp_no;
        public final String sent_at;
        final String requestId;

        public HelperRequest(SendContext context, String content, String actorEmpNo, Instant sentAt, String requestId) {
            this.requestId = Objects.requireNonNull(requestId);
            this.session_id = context.agentSessionId;
            this.message = content;
            this.visibility = context.visibility;
            this.emp_no = actorEmpNo;
            this.sent_at = sentAt.atOffset(ZoneOffset.ofHours(9)).format(java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        }
    }

    final class HelperResponse {
        public final String message;
        public final String sent_at;
        public final List<?> references;

        public HelperResponse(String message, String sentAt, List<?> references) {
            this.message = Objects.requireNonNull(message, "message");
            this.sent_at = Objects.requireNonNull(sentAt, "sentAt");
            this.references = references == null ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(references));
        }
    }

    final class SentMessage {
        public final String message;
        public final String sent_at;
        public final List<?> references;
        public final String chat_index;

        public SentMessage(String chatIndex, HelperResponse response) {
            this.chat_index = Objects.requireNonNull(chatIndex, "chatIndex");
            this.message = response.message;
            this.sent_at = response.sent_at;
            this.references = response.references;
        }
    }

    final class Message {
        public final String userid;
        public final String room_index;
        public final String chat_index;
        public final String message;
        public final String time;
        public final String isbot;
        public final String slected;

        public Message(String userid, String roomIndex, String chatIndex, String message,
                       String time, String isbot, String selected) {
            this.userid = userid;
            this.room_index = roomIndex;
            this.chat_index = chatIndex;
            this.message = message;
            this.time = time;
            this.isbot = isbot;
            this.slected = selected;
        }
    }
}
