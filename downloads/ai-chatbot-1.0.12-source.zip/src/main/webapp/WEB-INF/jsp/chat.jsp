<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" session="false" %>
<!doctype html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${chatTitle}</title>
    <style>
        body { background:#f4f6fa; color:#172237; font: 16px system-ui,sans-serif; margin:0; }
        main { max-width:760px; margin:3rem auto; padding:0 1rem; }
        section, form { display:flex; gap:.75rem; flex-wrap:wrap; margin-bottom:1rem; align-items:center; }
        [hidden] { display:none !important; }
        h1 { font-size:1.8rem; } button, input, textarea, select { font:inherit; padding:.65rem; border-radius:.4rem; border:1px solid #64748b; }
        button { background:#fff; color:#172237; cursor:pointer; } button:disabled { opacity:.6; }
        button[type=submit] { background:#1f4d9c; color:#fff; }
        #rooms { display:block; padding:1rem; background:#fff; border:1px solid #aab6ca; border-radius:.6rem; }
        #room-list { display:flex; flex-wrap:wrap; gap:.5rem; list-style:none; padding:0; }
        #room-list button[aria-current="true"] { background:#1f4d9c; color:#fff; }
        #viewed-room { font-size:1rem; }
        #messages { height:38vh; min-height:180px; overflow:auto; background:#fff; padding:1rem; border:1px solid #aab6ca; border-radius:.6rem; }
        #messages li { margin:0 0 .7rem 1rem; white-space:pre-wrap; overflow-wrap:anywhere; }
        textarea { flex:1; min-width:12rem; } #status { min-height:1.5rem; }
        #draft > div { width:100%; }
        #draft label { display:block; margin:.75rem 0; }
        #draft input, #draft textarea { display:block; width:100%; box-sizing:border-box; }
    </style>
    <script src="${pageContext.request.contextPath}/chat.js" data-send-path="${chatSendPath}" defer></script>
</head>
<body>
<main>
    <h1>${chatTitle}</h1>
    <form id="access">
        <label for="review-type">검토 유형</label>
        <select id="review-type">
            <option value="security">보안성 검토</option>
        </select>
        <label for="token">접근 토큰</label>
        <input id="token" type="password" autocomplete="off" required>
        <button type="submit">채팅 시작</button>
    </form>
    <section id="choice" hidden aria-label="미완료 채팅">
        <span id="choice-prompt">이어서 할까요, 새로 시작할까요?</span>
        <button id="resume" type="button">이어서 하기</button>
        <button id="reset" type="button">새로 시작</button>
    </section>
    <section id="rooms" aria-labelledby="rooms-heading" hidden>
        <h2 id="rooms-heading">내 대화 목록</h2>
        <p id="no-rooms">아직 대화가 없습니다.</p>
        <ul id="room-list"></ul>
        <button id="more-rooms" type="button" hidden>이전 대화 더 보기</button>
    </section>
    <p id="status" role="status"></p>
    <div id="chat" hidden>
        <h2 id="viewed-room"></h2>
        <ul id="messages" aria-live="polite" aria-label="메시지 이력"></ul>
        <form id="send">
            <label for="message">메시지</label>
            <textarea id="message" rows="2" required></textarea>
            <button type="submit">전송</button>
        </form>
        <section aria-label="채팅 상태">
            <button id="complete" type="button">작업 완료</button>
            <button id="cancel" type="button">취소</button>
        </section>
        <section id="evidence-result" hidden aria-labelledby="evidence-heading">
            <div>
                <h2 id="evidence-heading">가상 보안증적 요약</h2>
                <p id="evidence-summary"></p>
            </div>
        </section>
        <section id="draft" hidden aria-labelledby="draft-heading">
            <div>
                <h2 id="draft-heading">보안성 검토 신청서 초안</h2>
                <label for="draft-title">신청 제목</label>
                <input id="draft-title" maxlength="120">
                <label for="draft-description">검토 요청 내용</label>
                <textarea id="draft-description" rows="5" maxlength="2000"></textarea>
            </div>
        </section>
    </div>
</main>
</body>
</html>
