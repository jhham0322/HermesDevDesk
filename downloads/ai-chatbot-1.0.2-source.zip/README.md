# AI Chatbot 1.0.2

Windows source package for local AI chatbot demos and verification.

The build uses Java 21, Maven, Spring Boot 3.5.16, MyBatis and PostgreSQL.
Embedded Tomcat renders the Korean JSP from an executable WAR. The app
binds to loopback and accepts a local AI fixture and a dedicated local PostgreSQL
database. Run the database integration check only after the local database is
ready and approved.

For UI calls and examples, see the [chat UI integration guide](UI-CHAT-INTEGRATION.md).

## Build and mock verification

Use JDK 21 in the current PowerShell process and the existing Maven installation.

```powershell
$env:JAVA_HOME = Join-Path $env:USERPROFILE '.jdk\jdk-21.0.10'
& 'C:\tools\apache-maven-3.9.6\bin\mvn.cmd' -o verify
node --check src/main/resources/web/chat.js
```

`MockChatTest` uses Spring mock servlet requests, an in-memory test store and a
mock helper transport. It covers explicit start/resume, same-room message history,
ownership, upstream failure, retry, completion and cancellation. Spring Boot
packaging is part of the build. Running an actual HTTP listener, the PostgreSQL
integration check and company integration are separate checks.

To verify actual loopback HTTP, JSP rendering and chat with an in-memory test store:

```powershell
& "$env:JAVA_HOME\bin\java.exe" '-Dloader.path=target/test-classes,WEB-INF/classes,WEB-INF/lib' `
  '-Dloader.main=com.skhynix.hcp.srp.agent.ChatIntegrationCheck' `
  -cp target/ai-chatbot-1.0.2.war org.springframework.boot.loader.launch.PropertiesLauncher --memory
```

## Interactive local demo

In Windows PowerShell, run `.\run-local-demo.ps1` from the project folder and
open the printed **Chat demo** URL. The page identifies the in-memory demo and
pre-fills a test-only access token. Both the JSP app and its separate synthetic
AI HTTP API bind to `127.0.0.1` on unused ports. Ctrl+C stops the demo.
Ordinary `java -jar` runs the application without the test API and needs the
configured database and AI endpoints.

After starting a new chat, a sample conversation is:

1. Enter “사내 문서 검색 기능의 보안 검토를 요청합니다.”
2. Reply “열람 권한이 있는 문서만 검색하고 조회 이력을 남깁니다.”
3. Refresh, select “채팅 시작” and “이어서 하기” to restore the messages.
4. Select “작업 완료” to populate the editable application draft.
5. Start another chat and select “취소” to test cancellation.

Demo messages remain in memory only while the demo runs. Neither the test API
nor its credentials are packaged in the production WAR.

### Review types and conversation selection

The local demo has separate **보안성 검토** and **보안증적 검토 (가상)** modes.
For the evidence demo, enter sample text such as “가상 증적: 문서 조회 기록 1건을 확인했습니다.”
The separate mock AI asks about missing record timestamps and retention, and
returns a read-only sample summary. It has no upload, verdict, submission or
security-review application form. Company evidence fields, actual attachment
types, responses and integration have yet to be defined.

Select an item under **내 대화 목록** to see its history in read-only mode.
The server remembers the last explicit choice per signed-in user and review
type. Reconnect to restore that history. Choose **이어서 하기** to continue an
active chat. Ordinary demo history and selections remain until the demo stops.
For a second synthetic test user, replace the prefilled demo value with
`synthetic-browser-other-value-0001` before clicking **채팅 시작**.

### Persistent local demo when the existing connection is unavailable

In Windows PowerShell, run `.\run-local-postgres-demo.ps1`, then open the printed
**Chat demo** URL. The first launch uses the existing local `application.yml`
to provision a private SCRAM-only cluster with `db` and a non-superuser
`admin` login. It chooses a separate loopback port and stores synthetic data
under `%LOCALAPPDATA%\SolAiChat\postgres-demo`. The launcher reads the
credential directly and does not update the file or the Windows PostgreSQL
service. Ctrl+C stops the demo and its database process. The same launcher
reopens previously saved demo conversations on the next run.

Run `.\run-local-postgres-demo.ps1 -Verify` when each demo type has no active
conversation. It creates synthetic rooms, stops and restarts the dedicated
database and JVM, confirms both selections and histories, then sends another
turn and completes both rooms. The launcher keeps the resulting synthetic
history in the profile.

### Database artifacts for isolated testing

The security-review bootstrap adds the independent selection table
`srp_ai_chat_room_pref`. Existing room and message records remain in their
original tables. Evidence review uses the adapter
`com.skhynix.hcp.srp.agent.ai.AiEvidenceReviewChat` and mapper
`mapper/ai/AiEvidenceReviewChatMapper.xml`. This mapper owns new tables
`ai_evidence_review_chat_mst`, `ai_evidence_review_chat_dtl` and
`ai_evidence_review_chat_selection`. The evidence detail and selection tables
reference only its own master. No data migration from security review is required.

The evidence database adapter is wired only in the integration runner, which
creates a new random schema in the explicitly configured test database.
Existing schemas need a separately reviewed deployment of the new security
selection table before enabling the conversation list. The regular application
keeps evidence mode disabled. Do not run the integration runner using a real
business database.

## Local configuration

| Variable | Value |
| --- | --- |
| `CHAT_DB_URL` | Dedicated local database, for example `jdbc:postgresql://127.0.0.1:5432/chat` |
| `CHAT_DB_USER`, `CHAT_DB_PASSWORD` | Dedicated local PostgreSQL credentials |
| `CHAT_INIT_SCHEMA` | Set to `true` to initialize an empty local database |
| `CHAT_USER_TOKENS_JSON` | Owner IDs mapped to distinct bearer tokens with at least 32 printable ASCII characters |
| `CHAT_PORT` | Loopback app port, default 8080 |
| `AI_BASE_URL` | Local fixture origin, for example `http://127.0.0.1:8090` |
| `AI_OPEN_PATH`, `AI_CLOSE_PATH` | Paths exposed by the local fixture for session open and close |
| `AI_VISIBILITY`, `AI_TOKEN` | Fixture visibility and optional fixture bearer token |

With both local dependencies ready, start the packaged application using
`& "$env:JAVA_HOME\bin\java.exe" -jar target/ai-chatbot-1.0.2.war`.
Open `http://127.0.0.1:8080/` (or the configured `CHAT_PORT`) and enter the matching bearer token.

| POST route | Expected behavior |
| --- | --- |
| `/chat/start` | Find the authenticated owner's active room |
| `/chat/continue` with `R` | Resume the same room and read paginated message history |
| `/chat/continue` with `N` | Create a new room and close the previously selected active room, if present |
| `/chat/send` | Send a message, preserve its request ID for retry and save the user/AI pair transactionally |
| `/chat/end` with `C` | Complete the chat and populate an editable local draft |
| `/chat/end` with `X` | Cancel the chat through the configured close route |

The local completion fixture uses a `draft` object with optional string fields
`title` (120 characters) and `description` (2,000 characters). The server
checks format and length and returns these fields to the editor. The editor has
no submission action. The actual company session open/close contracts and actual
application fields still need confirmation. The inherited message and completion
paths are exercised only against mock data here.

## Later PostgreSQL verification

Set `CHAT_TEST_DB_URL`, `CHAT_TEST_DB_USER` and `CHAT_TEST_DB_PASSWORD` for a
dedicated local test database. The runner creates a randomly named test schema,
starts Spring Boot and a local HTTP fixture on ephemeral loopback ports, restarts
the app before checking persisted same-room history, and cleans up its schema.

```powershell
& "$env:JAVA_HOME\bin\java.exe" '-Dloader.path=target/test-classes,WEB-INF/classes,WEB-INF/lib' `
  '-Dloader.main=com.skhynix.hcp.srp.agent.ChatIntegrationCheck' `
  -cp target/ai-chatbot-1.0.2.war org.springframework.boot.loader.launch.PropertiesLauncher
```

The inherited transaction protects local writes. A failure after the helper
accepts a request but before local commit still requires confirmation of helper
idempotency before production use.

### Reproduce the Windows isolation and restart check

Build with Maven as above, then run `python .\tools\test-isolated-postgres.py`
with PostgreSQL 18 installed in the standard Windows location. The check
initializes a new SCRAM-only cluster below `target/` on a free loopback port,
uses synthetic data, verifies transaction rollback and both physical evidence
foreign keys, restarts the test DB, and starts a new JVM to verify the exact
selected IDs and histories. It stops only the test cluster. The normal database
and the local `application.yml` are outside this check.

AI operations include a stable `Idempotency-Key`. The local test API honors it
and the suite verifies retries after both timeouts and database write failures.
Upstream deduplication in another deployment requires that API to honor the
same key. The company API contract has not been verified.
