"""Run the synthetic Sol demo against its own persistent Windows PostgreSQL."""
import argparse
import base64
import hashlib
import hmac
import json
import msvcrt
import os
from pathlib import Path
import queue
import re
import secrets
import socket
import subprocess
import tempfile
import threading
from urllib.request import Request, ProxyHandler, build_opener
from uuid import uuid4

from _postgres_windows import password_pipe

PROJECT = Path(__file__).resolve().parents[1]
BIN = Path(r"C:\Program Files\PostgreSQL\18\bin")
JAVA = Path.home() / ".jdk/jdk-21.0.10/bin/java.exe"
ROOT = Path(os.environ["LOCALAPPDATA"]) / "SolAiChat" / "postgres-demo"
BASE_ENV = {
    key: value for key, value in os.environ.items()
    if not key.upper().startswith(("PG", "CHAT_", "SOL_PROFILE_", "AI_", "SPRING_", "SERVER_"))
    and key.upper() not in {"JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS", "JDK_JAVA_OPTIONS"}
}
DEMO = "synthetic-browser-test-value-0001"
OTHER = "synthetic-browser-other-value-0001"
BOOTSTRAP = "sol_demo_bootstrap"


def local_password(path):
    rows = [line.partition(":") for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    fields = {key.strip().casefold(): value.strip() for key, divider, value in rows if divider}
    if len(rows) != 5 or len(fields) != 5 or fields.pop("url", None) not in {"127.0.0.1", "localhost"}:
        raise RuntimeError("Expected the existing five-field loopback application.yml.")
    if fields.pop("port", None) != "5432" or fields.pop("username", None) != "admin":
        raise RuntimeError("The source settings must refer to the assigned local role and port.")
    password = fields.pop("password", "")
    if list(fields.values()) != ["db"] or not re.fullmatch(r"[!-~]+", password) or password[0] in "$'\042":
        raise RuntimeError("The DB name or literal password format could not be confirmed.")
    return password


def checked(label, args, *, env=BASE_ENV, input_text=None, quiet=False):
    streams = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL} if quiet else {"capture_output": True}
    result = subprocess.run([str(i) for i in args], env=env, input=input_text, text=True, encoding="utf-8",
                            errors="replace", timeout=70, **streams)
    if result.returncode:
        raise RuntimeError(f"{label} failed (exit {result.returncode}).")
    return result.stdout or ""


def check_local_profile(folder):
    data = folder / "data"
    rules = (data / "pg_hba.conf").read_text(encoding="utf-8")
    methods = [row.split()[-1] for row in rules.splitlines() if row.strip() and not row.lstrip().startswith("#")]
    if not methods or set(methods) != {"scram-sha-256"}:
        raise RuntimeError("This profile is not configured for SCRAM-only authentication.")
    if (data / "postmaster.pid").exists():
        raise RuntimeError("The dedicated profile is already running. Stop its launcher before starting another.")


def start_db(folder, port):
    check_local_profile(folder)
    checked("Dedicated PostgreSQL start", [BIN / "pg_ctl.exe", "-D", folder / "data", "-l",
            folder / "postgres.log", "-o", f"-h 127.0.0.1 -p {port}", "-w", "-t", "20", "start"], quiet=True)


def stop_db(folder):
    data = folder / "data"
    if (data / "postmaster.pid").exists():
        checked("Dedicated PostgreSQL stop", [BIN / "pg_ctl.exe", "-D", data, "-m", "fast", "-w", "-t", "20", "stop"])


def sql(port, role, password, database, command):
    env = dict(BASE_ENV, PGPASSWORD=password)
    return checked("Dedicated PostgreSQL SQL", [BIN / "psql.exe", "-X", "-w", "-h", "127.0.0.1", "-p", port,
                   "-U", role, "-d", database, "-Atq", "-v", "ON_ERROR_STOP=1"], env=env, input_text=command).strip()


def verifier(password):
    salt = secrets.token_bytes(16)
    salted = hashlib.pbkdf2_hmac("sha256", password.encode("ascii"), salt, 4096)
    client = hmac.digest(salted, b"Client Key", "sha256")
    stored = hashlib.sha256(client).digest()
    server = hmac.digest(salted, b"Server Key", "sha256")
    encode = lambda value: base64.b64encode(value).decode("ascii")
    return f"SCRAM-SHA-256$4096:{encode(salt)}${encode(stored)}:{encode(server)}"


def create_profile(folder, password):
    temp = Path(tempfile.mkdtemp(prefix="setup-", dir=folder.parent))
    with socket.socket() as guard:
        guard.bind(("127.0.0.1", 0))
        port = guard.getsockname()[1]
    if port == 5432:
        raise RuntimeError("Refused the existing PostgreSQL port.")
    root_secret = secrets.token_urlsafe(32)
    pipe = password_pipe(root_secret)
    checked("Dedicated PostgreSQL initialization", [BIN / "initdb.exe", "-D", temp / "data", "-U", BOOTSTRAP,
            "-A", "scram-sha-256", "--pwfile=" + pipe, "--no-locale", "-E", "UTF8"])
    try:
        start_db(temp, port)
        sql(port, BOOTSTRAP, root_secret, "postgres",
            "SET log_statement = 'none'; SET log_min_error_statement = 'panic';\n"
            "CREATE ROLE admin LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION "
            f"PASSWORD '{verifier(password)}';\nCREATE DATABASE db OWNER admin;\n"
            f"ALTER ROLE {BOOTSTRAP} NOLOGIN PASSWORD NULL;\n")
        if sql(port, "admin", password, "db", "SELECT 1;\n") != "1":
            raise RuntimeError("Dedicated database authentication could not be verified.")
    finally:
        stop_db(temp)
    (temp / "port").write_text(str(port), encoding="ascii")
    temp.rename(folder)
    return port


def launch_app(port, password):
    env = dict(BASE_ENV, SOL_PROFILE_DB_URL=f"jdbc:postgresql://127.0.0.1:{port}/db",
               SOL_PROFILE_DB_PASSWORD=password)
    child = subprocess.Popen([str(JAVA), "-Dspring.config.location=optional:classpath:/",
        "-Dlogging.level.org.apache.tomcat.util.http.parser.Cookie=OFF",
        "-Dloader.path=target/test-classes,WEB-INF/classes,WEB-INF/lib",
        "-Dloader.main=com.skhynix.hcp.srp.agent.LocalAiDemo", "-cp", "target/ai-chatbot-1.0.2.war",
        "org.springframework.boot.loader.launch.PropertiesLauncher", "--isolated-db"],
        cwd=PROJECT, env=env, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        text=True, encoding="utf-8", errors="replace")
    events = queue.Queue()

    def feed():
        with child.stdout:
            for line in child.stdout:
                if line.startswith("Chat demo: "):
                    events.put(line.removeprefix("Chat demo: ").strip())
        events.put(None)

    threading.Thread(target=feed, daemon=True).start()
    try:
        url = events.get(timeout=45)
        if not url or not re.fullmatch(r"http://127\.0\.0\.1:[1-9][0-9]{3,4}/", url):
            raise RuntimeError("The persistent JSP demo could not start.")
        print("Chat demo:", url, flush=True)
        return child, url
    except BaseException:
        stop_app(child)
        raise


def stop_app(child):
    if child.poll() is None:
        child.terminate()
        child.wait(timeout=15)


def post(url, action, typ, payload=None, token=DEMO):
    body = json.dumps({"review_type": typ, **(payload or {})}, ensure_ascii=False).encode()
    request = Request(url + "chat/" + action, body,
                      {"Content-Type": "application/json", "Authorization": "Bearer " + token})
    with build_opener(ProxyHandler({})).open(request, timeout=12) as response:
        return json.load(response)


def seed(url, kind, marker):
    open_id = post(url, "start", kind)["room_index"]
    if open_id:
        raise RuntimeError("Finish the open demo room before running the repeatable verification.")
    room = post(url, "continue", kind, {"room_index": "", "status": "N"})["room_index"]
    append_turn(url, kind, room, marker)
    post(url, "select", kind, {"room_index": room})
    return room


def append_turn(url, kind, room, message):
    return post(url, "send", kind, {"room_index": room, "type": "S", "chat_index": str(uuid4()), "message": message})


def verify(url, rooms):
    for kind, (room, marker) in rooms.items():
        directory = post(url, "list", kind)
        assert directory["selected_room_index"] == room
        assert post(url, "list", kind, token=OTHER)["rooms"] == []
        result = post(url, "history", kind, {"room_index": room})
        assert result["room_index"] == room and len(result["messages"]) == 2
        assert result["messages"][0]["message"] == marker
        assert post(url, "continue", kind, {"room_index": room, "status": "R"})["room_index"] == room
        append_turn(url, kind, room, marker + " (after restart)")
        end = post(url, "end", kind, {"room_index": room, "type": "C"})
        fields = {"title", "description"} if kind == "security" else {"summary"}
        assert end["status"] == "COMPLETED" and set(end["draft"]) == fields
    print("PASS: two physically separate chat flows, exact selections and histories after restart, and completed drafts.", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--settings", type=Path, default=PROJECT / "application.yml")
    parser.add_argument("--verify", action="store_true")
    options = parser.parse_args()
    password = local_password(options.settings)
    ROOT.mkdir(parents=True, exist_ok=True)
    folder = ROOT / "cluster"
    with (ROOT / "launcher.lock").open("a+b") as lock:
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        port = int((folder / "port").read_text(encoding="ascii")) if folder.exists() else create_profile(folder, password)
        if not 1024 <= port <= 65535 or port == 5432:
            raise RuntimeError("Rejected an invalid or non-isolated profile port.")
        start_db(folder, port)
        try:
            if sql(port, "admin", password, "db",
                   "SELECT current_user = 'admin' AND current_database() = 'db' AND NOT rolsuper "
                   "FROM pg_roles WHERE rolname = current_user;\n") != "t":
                raise RuntimeError("Dedicated role/database or privilege verification failed.")
            print(f"Dedicated PostgreSQL: 127.0.0.1:{port}/db (admin, SCRAM)", flush=True)
            child, url = launch_app(port, password)
            try:
                if not options.verify:
                    child.wait()
                    return
                marker = "Synthetic persistence check " + uuid4().hex
                rooms = {kind: (seed(url, kind, marker + " " + kind), marker + " " + kind)
                         for kind in ("security", "evidence")}
            finally:
                stop_app(child)
            stop_db(folder)
            start_db(folder, port)
            child, url = launch_app(port, password)
            try:
                verify(url, rooms)
                counts = sql(port, "admin", password, "db",
                    "SELECT (SELECT count(*) FROM srp_ai_cat_dtl), "
                    "(SELECT count(*) FROM ai_evidence_review_chat_dtl);\n")
                assert all(int(n) >= 5 for n in counts.split("|"))
                print("PASS: both PostgreSQL detail tables contain committed synthetic rows.", flush=True)
            finally:
                stop_app(child)
        finally:
            stop_db(folder)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except (RuntimeError, OSError, ValueError, queue.Empty, subprocess.TimeoutExpired, AssertionError) as error:
        print(str(error) if isinstance(error, RuntimeError) else f"Profile check failed: {type(error).__name__}.",
              flush=True)
        raise SystemExit(1)
