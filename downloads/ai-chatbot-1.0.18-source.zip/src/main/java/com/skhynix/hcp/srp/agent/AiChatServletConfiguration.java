package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.net.URI;

/** Builds the chat handler on demand inside the host application. */
@Configuration(proxyBeanMethods = false)
public class AiChatServletConfiguration {
    static final String PORTAL_CONTEXT_PATH = "/securityportal-apis";
    static final String CHAT2_JSP_PATH = "/chat2.jsp";
    static final String PORTAL_CHAT2_JSP_PATH = PORTAL_CONTEXT_PATH + CHAT2_JSP_PATH;
    static final String PORTAL_CHAT2_SEND_PATH = "/chat2/send";
    static final String PORTAL_CHAT2_FULL_PATH = PORTAL_CONTEXT_PATH + PORTAL_CHAT2_SEND_PATH;
    static final String CHAT2_SEND_PATH = "/api/ai-agent/chat2/send";

    @Bean
    ServletRegistrationBean<HttpServlet> chatJspEntryPoints(AiChatWebController controller) {
        // Jasper's *.jsp mapping takes precedence over the host's default MVC mapping.
        var entryPoints = new ServletRegistrationBean<HttpServlet>(new HttpServlet() {
            @Override
            protected void doGet(HttpServletRequest request, HttpServletResponse response)
                    throws IOException, ServletException {
                controller.page(request, response);
            }
        }, CHAT2_JSP_PATH, PORTAL_CHAT2_JSP_PATH);
        entryPoints.setName("chatJspEntryPoints");
        return entryPoints;
    }

    @Bean
    @Lazy
    ChatHandler chatHandler(Environment env) throws IOException {
        var json = new ObjectMapper();
        var helper = new AiHelperHttpClient(json, URI.create(env.getRequiredProperty("AI_BASE_URL")),
                env.getProperty("AI_TOKEN", ""), env.getRequiredProperty("AI_OPEN_PATH"),
                env.getRequiredProperty("AI_CLOSE_PATH"));
        var store = new PostgresChatStore(env.getRequiredProperty("CHAT_DB_URL"),
                env.getRequiredProperty("CHAT_DB_USER"), env.getProperty("CHAT_DB_PASSWORD", ""),
                json, helper, env.getRequiredProperty("AI_VISIBILITY"));
        var tokens = json.readValue(env.getProperty("CHAT_USER_TOKENS_JSON", "{}"),
                new TypeReference<java.util.Map<String, String>>() {});
        return new ChatHandler(new ChatServlet(json, store, helper, tokens, store::ordered));
    }

    record ChatHandler(ChatServlet servlet) {}
}
