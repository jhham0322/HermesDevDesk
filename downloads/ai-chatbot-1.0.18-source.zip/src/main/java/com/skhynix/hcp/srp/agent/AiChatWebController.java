package com.skhynix.hcp.srp.agent;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.CHAT2_JSP_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.CHAT2_SEND_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.PORTAL_CHAT2_FULL_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.PORTAL_CHAT2_JSP_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.PORTAL_CHAT2_SEND_PATH;

@RestController
@RequestMapping
public class AiChatWebController {
    private static final Logger LOG = LoggerFactory.getLogger(AiChatWebController.class);
    private final ObjectProvider<AiChatServletConfiguration.ChatHandler> handlers;

    public AiChatWebController(ObjectProvider<AiChatServletConfiguration.ChatHandler> handlers) {
        this.handlers = handlers;
    }

    @GetMapping({"/chat", "/chat/", "/chat/security", "/chat1", "/chat2",
            CHAT2_JSP_PATH, PORTAL_CHAT2_JSP_PATH, "/chat.js"})
    public void page(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        handle(request, response);
    }

    @PostMapping({"/chat/start", "/chat/list", "/chat/history", "/chat/select", "/chat/continue",
            "/chat/send", "/chat/end", CHAT2_SEND_PATH, PORTAL_CHAT2_SEND_PATH, PORTAL_CHAT2_FULL_PATH})
    public void chat(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        handle(request, response);
    }

    private void handle(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        AiChatServletConfiguration.ChatHandler handler;
        try {
            handler = handlers.getObject();
        } catch (BeansException e) {
            LOG.warn("Chat initialization failed ({}). Check the host chat configuration and mapper resources.",
                    e.getMostSpecificCause().getClass().getSimpleName());
            response.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
            response.setHeader("Cache-Control", "no-store");
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"error\":\"Chat service configuration is unavailable.\"}");
            return;
        }
        handler.servlet().service(request, response);
    }
}
