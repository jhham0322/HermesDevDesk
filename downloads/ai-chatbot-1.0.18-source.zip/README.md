# AI Chatbot 1.0.18

Chat component for an existing Spring Boot servlet application. It uses Java 21,
MyBatis and PostgreSQL. The Maven WAR provides classes and web resources for
integration into the host application.

For UI calls and examples, see the [chat UI integration guide](UI-CHAT-INTEGRATION.md).

For instructions to paste into a company AI coding session, see [COMPANY-AI-WORK-GUIDE.txt](COMPANY-AI-WORK-GUIDE.txt).

## Register on the existing server

Place the Java sources in the host module. Spring component scanning discovers
`AiChatWebController` under `com.skhynix.hcp.srp.agent`. Chat dependencies
initialize on the first chat request. Configuration errors return HTTP 503
from chat endpoints while the host continues serving other routes.
For example, with a host on port 9200, the chat helper page is `/securityportal-apis/chat2.jsp` and
the send endpoint is `POST /securityportal-apis/chat2/send` on that port.
Include the JSPs under `src/main/webapp/WEB-INF/jsp` in the host WAR.

The host servlet principal supplies the chat user identity. Use a stable ID
matching the existing chat owner and retain the host authentication and CSRF policies.

| Spring environment keys | Use |
| --- | --- |
| `CHAT_DB_URL`, `CHAT_DB_USER`, `CHAT_DB_PASSWORD` | Provisioned PostgreSQL database and credentials |
| `CHAT_USER_TOKENS_JSON` | Optional user IDs mapped to distinct bearer tokens |
| `AI_BASE_URL`, `AI_VISIBILITY`, `AI_TOKEN` | Helper origin, visibility and optional bearer token |
| `AI_OPEN_PATH`, `AI_CLOSE_PATH` | Helper session open and close paths |

| POST route | Expected behavior |
| --- | --- |
| `/chat/start` | Find the authenticated owner's active room |
| `/chat/continue` with `R` | Resume the same room and read paginated message history |
| `/chat/continue` with `N` | Create a new room and close the previously selected active room, if present |
| `/chat/send`, `/securityportal-apis/chat2/send` | Send a message, preserve its request ID for retry and save the user/AI pair transactionally |
| `/chat/end` with `C` | Complete the chat and populate an editable local draft |
| `/chat/end` with `X` | Cancel the chat through the configured close route |

The upstream message and completion endpoints accept JSON and return
`CommonResponse<T>`, with `responseAt`, a result `message`, and `data`.
The adapter expects message data with `message`, `sent_at`, and optional
`references`, and completion data with a `draft` object. These inner fields
follow the current project fixtures and require confirmation against the company API.
Outgoing message timestamps include the `+09:00` ISO 8601 offset. Configure
the confirmed HTTPS origin via `AI_BASE_URL`. Session open and close still
use the separately configured paths and require a confirmed session contract.

The local completion fixture uses a `draft` object with optional string fields
`title` (120 characters) and `description` (2,000 characters). The server
checks format and length and returns these fields to the editor. The editor has
no submission action. The actual company session open/close contracts and actual
application fields still need confirmation. The inherited message and completion
paths are exercised only against mock data here.

## Build and test

Run `mvn -B -ntp verify` with JDK 21. To run the local HTTP test from project root:

```powershell
java -cp 'target/test-classes;target/ai-chatbot-1.0.18/WEB-INF/classes;target/ai-chatbot-1.0.18/WEB-INF/lib/*' com.skhynix.hcp.srp.agent.ChatIntegrationCheck --memory
```

### Reproduce the Windows isolation and restart check

Build with Maven as above, then run `python .\tools\test-isolated-postgres.py`
with PostgreSQL 18 installed in the standard Windows location. The check
initializes a new SCRAM-only cluster below `target/` on a free loopback port,
uses synthetic data, verifies transaction rollback and both physical evidence
foreign keys, restarts the test DB, and starts a new JVM to verify the exact
selected IDs and histories. It stops only the test cluster. The normal database
and the local `application.yml` are outside this check.

AI operations include a stable `Idempotency-Key`. The local test API honors it
and the suite verifies retries after both timeouts and database write failures.
Upstream deduplication in another deployment requires that API to honor the
same key. The company API contract has not been verified.
