package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.DriverManager;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/** Runs against a disposable PostgreSQL database and a local fake AI helper. */
public final class ChatIntegrationCheck {
    private static final String TOKEN = "synthetic-employee-token-000000001";
    private static final String OTHER = "synthetic-employee-token-000000002";
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--memory".equals(args[0])) {
            run(null, null, null);
            verifyHostRegistration();
            verifyHostStartsWithoutChatSettings();
            return;
        }
        String jdbc = required("CHAT_TEST_DB_URL");
        validateLocalDatabase(jdbc);
        String user = required("CHAT_TEST_DB_USER");
        String password = required("CHAT_TEST_DB_PASSWORD");
        if (args.length > 0 && ("--keep-isolated".equals(args[0]) || "--verify-isolated".equals(args[0]))) {
            if (args.length != ("--verify-isolated".equals(args[0]) ? 4 : 2)
                    || !args[1].matches("chat_test_[0-9a-f]{32}")
                    || !jdbc.matches("jdbc:postgresql://127\\.0\\.0\\.1:(?!5432/)[0-9]+/sol_isolated")) {
                throw new IllegalArgumentException("Restart verification requires an isolated test database and schema.");
            }
            if ("--verify-isolated".equals(args[0])) {
                verifyRestart(jdbc + "?currentSchema=" + args[1], user, password, args[2], args[3]);
                return;
            }
        } else if (args.length != 0) {
            throw new IllegalArgumentException("Unsupported integration test option.");
        }

        boolean keep = args.length == 2;
        String schema = keep ? args[1] : "chat_test_" + UUID.randomUUID().toString().replace("-", "");
        try (var connection = DriverManager.getConnection(jdbc, user, password);
             var statement = connection.createStatement()) {
            statement.execute("CREATE SCHEMA " + schema);
            boolean success = false;
            try {
                run(jdbc + (jdbc.contains("?") ? "&" : "?") + "currentSchema=" + schema, user, password);
                success = true;
            } finally {
                if (!keep || !success) statement.execute("DROP SCHEMA " + schema + " CASCADE");
            }
        }
    }

    private static void run(String jdbc, String user, String password) throws Exception {
        var posts = new AtomicInteger();
        var completions = new AtomicInteger();
        var closes = new AtomicInteger();
        var badCompletion = new AtomicBoolean();
        var completedReplies = new ConcurrentHashMap<String, Object>();
        var messageTexts = new ConcurrentHashMap<String, String>();
        var ai = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 8);
        ai.createContext("/", exchange -> {
            try (exchange) {
                var request = JSON.readTree(exchange.getRequestBody());
                int status = 200;
                Object reply;
                if (!"POST".equals(exchange.getRequestMethod()) || !request.hasNonNull("emp_no")) {
                    status = 400;
                    reply = Map.of();
                } else {
                    reply = switch (exchange.getRequestURI().getPath()) {
                        case "/fixture/open" -> completedReplies.computeIfAbsent(key(exchange), ignored -> Map.of("session_id", UUID.randomUUID().toString()));
                        case "/api/v1/sr/helper/message" -> {
                            check(request.hasNonNull("session_id") && request.hasNonNull("visibility")
                                    && request.hasNonNull("sent_at") && !request.has("requestId"), "helper request fields");
                            String key = key(exchange);
                            String content = request.path("message").asText();
                            if ("fail".equals(content)) {
                                posts.incrementAndGet();
                                status = 503;
                                yield Map.of();
                            }
                            if (messageTexts.containsKey(key)) {
                                check(content.equals(messageTexts.get(key)), "stable content for idempotency key");
                                yield completedReplies.get(key);
                            }
                            posts.incrementAndGet();
                            Object response = Map.of("message", "answer", "sent_at", "2026-11-19T10:00:00Z",
                                    "references", java.util.List.of(Map.of("title", "fixture")));
                            messageTexts.put(key, content);
                            completedReplies.put(key, response);
                            if ("delayed".equals(content)) {
                                try { Thread.sleep(1300); }
                                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                            }
                            yield response;
                        }
                        case "/api/v1/sr/helper/complete" -> {
                            if (badCompletion.getAndSet(false)) yield Map.of("draft", Map.of("invalid", "omit"));
                            yield completedReplies.computeIfAbsent(key(exchange), ignored -> {
                                completions.incrementAndGet();
                                return Map.of("draft", Map.of("title", " draft ", "description", 123,
                                        "unverified", "omit", "summary", "evidence summary"));
                            });
                        }
                        case "/fixture/close" -> {
                            yield completedReplies.computeIfAbsent(key(exchange), ignored -> {
                                closes.incrementAndGet();
                                return Map.of();
                            });
                        }
                        default -> { status = 404; yield Map.of(); }
                    };
                }
                String path = exchange.getRequestURI().getPath();
                if (status == 200 && (path.equals(AiHelperHttpClient.MESSAGE_PATH)
                        || path.equals(AiHelperHttpClient.COMPLETE_PATH))) {
                    reply = helperResponse(reply);
                }
                byte[] bytes = JSON.writeValueAsBytes(reply);
                exchange.sendResponseHeaders(status, bytes.length);
                exchange.getResponseBody().write(bytes);
            }
        });
        ai.start();
        org.springframework.context.ConfigurableApplicationContext chatbot = null;
        try {
            var helper = new AiHelperHttpClient(JSON, url(ai), "", "/fixture/open", "/fixture/close", Duration.ofSeconds(1));
            var tokens = Map.of("EMP1", TOKEN, "EMP2", OTHER);
            AiChatController servlet;
            if (jdbc == null) {
                var sequence = new java.util.concurrent.atomic.AtomicLong();
                var store = new MemoryChatStore(helper, sequence);
                var evidence = new MemoryChatStore(helper, sequence);
                servlet = new AiChatController(JSON, store, helper, tokens, store::ordered, evidence, helper);
            } else {
                var store = new PostgresChatStore(jdbc, user, password, JSON, helper, "fixture");
                store.initializeSchema();
                store.initializeSchema();
                var evidence = new com.skhynix.hcp.srp.agent.ai.AiEvidenceReviewChat(
                        jdbc, user, password, JSON, helper::openSession, "fixture-evidence");
                evidence.initializeSchema();
                servlet = new AiChatController(JSON, store, helper, tokens, store::ordered, evidence, helper);
            }
            chatbot = startTestHost(servlet);
            int port = ((ServletWebServerApplicationContext) chatbot).getWebServer().getPort();
            URI base = URI.create("http://127.0.0.1:" + port);
            call(base, "start", "", Map.of(), 401);
            check(call(base, "start", TOKEN, Map.of("userid", "EMP2"), 200).path("has_open_chat").asText().equals("F"), "read-only start");
            String room = startRoom(base, "");
            check(call(base, "start", TOKEN, Map.of(), 200).path("room_index").asText().equals(room), "active room");
            call(base, "continue", OTHER, Map.of("room_index", room, "status", "R"), 404);
            call(base, "send", TOKEN, send(room, "fail", "failed"), 502);
            var request = send(room, "hello", "message-1");
            call(base, AiChatController.CHAT2_SEND_PATH, "", request, 401);
            JsonNode first = call(base, AiChatController.PORTAL_CHAT2_FULL_PATH, TOKEN, request, 200);
            check(first.path("chat_index").asText().equals("2") && first.path("references").size() == 1, "reply contract");
            check(first.equals(call(base, "send", TOKEN, request, 200)) && posts.get() == 2, "cached reply");
            call(base, "send", TOKEN, send(room, "different", "message-1"), 409);
            JsonNode history = call(base, "continue", TOKEN, Map.of("room_index", room, "status", "R"), 200).path("messages");
            check(history.size() == 2 && history.get(0).path("chat_index").asText().equals("1")
                    && history.get(1).path("isbot").asText().equals("Y")
                    && history.get(1).path("slected").asText().equals("N"), "sequence and history");
            JsonNode page = call(base, "continue", TOKEN, Map.of("room_index", room, "status", "R", "afterSeq", 1, "limit", 1), 200).path("messages");
            check(page.size() == 1 && page.get(0).path("chat_index").asText().equals("2"), "history paging");
            var same = send(room, "parallel", "message-2");
            var a = HTTP.sendAsync(request(base, "send", TOKEN, same), HttpResponse.BodyHandlers.ofString());
            var b = HTTP.sendAsync(request(base, "send", TOKEN, same), HttpResponse.BodyHandlers.ofString());
            check(a.get().statusCode() == 200 && b.get().statusCode() == 200
                    && a.get().body().equals(b.get().body()) && posts.get() == 3, "concurrent replay");
            chatbot.close();
            chatbot = startTestHost(servlet);
            int restartedPort = ((ServletWebServerApplicationContext) chatbot).getWebServer().getPort();
            base = URI.create("http://127.0.0.1:" + restartedPort);
            JsonNode resumed = call(base, "continue", TOKEN, Map.of("room_index", room, "status", "R"), 200);
            check(room.equals(resumed.path("room_index").asText()) && resumed.path("messages").size() == 4,
                    "same room and both message pairs on resume");
            JsonNode done = call(base, "end", TOKEN, Map.of("room_index", room, "type", "C"), 200);
            check(done.path("status").asText().equals("COMPLETED") && done.path("draft").path("title").asText().equals("draft")
                    && done.path("draft").size() == 1, "completed draft");
            check(done.equals(call(base, "end", TOKEN, Map.of("room_index", room, "type", "C"), 200))
                    && completions.get() == 1, "completion retry");
            call(base, "end", TOKEN, Map.of("room_index", room, "type", "X"), 409);
            String abandoned = startRoom(base, "");
            String replacement = startRoom(base, abandoned);
            call(base, "continue", TOKEN, Map.of("room_index", abandoned, "status", "N"), 409);
            check(call(base, "end", TOKEN, Map.of("room_index", replacement, "type", "X"), 200)
                    .path("status").asText().equals("CANCELED") && closes.get() == 1, "cancellation");
            if (jdbc != null) {
                try (var c = DriverManager.getConnection(jdbc, user, password);
                     var s = c.prepareStatement("SELECT CHAT_STAT_CD, MESSAE_CNT, LAST_MESSAGE_CONT FROM SRP_AI_CHAT_MST WHERE CHAT_SQ = ?")) {
                    s.setLong(1, Long.parseLong(room));
                    try (var r = s.executeQuery()) {
                        check(r.next() && "COMPLETED".equals(r.getString(1)) && r.getLong(2) == 5
                                && r.getString(3).contains("draft"), "completion DTL and MST summary");
                    }
                    s.setLong(1, Long.parseLong(abandoned));
                    try (var r = s.executeQuery()) { check(r.next() && "CLOSED".equals(r.getString(1)), "reset closed old room"); }
                }
            }
            call(base, "select", TOKEN, Map.of("room_index", room), 200);
            check(call(base, "list", TOKEN, Map.of(), 200).path("selected_room_index").asText().equals(room),
                    "explicit selection from older security rooms");
            check(call(base, "list", OTHER, Map.of(), 200).path("rooms").isEmpty(), "no other-owner rooms");
            call(base, "history", OTHER, Map.of("room_index", room), 404);
            check(call(base, "history", TOKEN, Map.of("room_index", room), 200).path("messages").size() == 4,
                    "history is read-only and completion metadata is excluded");
            String firstEvidenceRoom = call(base, "continue", TOKEN,
                    Map.of("status", "N", "review_type", "evidence"), 200).path("room_index").asText();
            String evidence = call(base, "continue", TOKEN,
                    Map.of("status", "N", "review_type", "evidence", "room_index", firstEvidenceRoom),
                    200).path("room_index").asText();
            check(!room.equals(evidence), "review types use distinct selected IDs in the test");
            var evidenceSend = new java.util.HashMap<>(send(evidence, "synthetic evidence", "evidence-1"));
            evidenceSend.put("review_type", "evidence");
            int evidencePosts = posts.get();
            var evidenceA = HTTP.sendAsync(request(base, "send", TOKEN, evidenceSend), HttpResponse.BodyHandlers.ofString());
            var evidenceB = HTTP.sendAsync(request(base, "send", TOKEN, evidenceSend), HttpResponse.BodyHandlers.ofString());
            var evidenceReply = evidenceA.get();
            var evidenceReplay = evidenceB.get();
            check(evidenceReply.statusCode() == 200 && evidenceReplay.statusCode() == 200
                    && evidenceReply.body().equals(evidenceReplay.body()) && posts.get() == evidencePosts + 1,
                    "concurrent evidence replay");
            call(base, "history", OTHER, Map.of("room_index", evidence, "review_type", "evidence", "userid", "EMP1"), 404);
            call(base, "select", TOKEN, Map.of("room_index", evidence, "review_type", "evidence"), 200);
            check(call(base, "list", TOKEN, Map.of("review_type", "evidence"), 200)
                    .path("selected_room_index").asText().equals(evidence), "evidence selection");
            check(call(base, "list", TOKEN, Map.of(), 200).path("selected_room_index").asText().equals(room),
                    "evidence selection leaves security selection unchanged");
            var evidenceEnd = call(base, "end", TOKEN,
                    Map.of("room_index", evidence, "type", "C", "review_type", "evidence"), 200).path("draft");
            check(evidenceEnd.size() == 1 && evidenceEnd.path("summary").asText().equals("evidence summary"),
                    "evidence summary does not carry security application fields");
            if (jdbc != null) {
                try (var conn = DriverManager.getConnection(jdbc, user, password);
                     var statement = conn.createStatement();
                     var rows = statement.executeQuery("SELECT count(*) FROM ai_evidence_review_chat_dtl")) {
                    check(rows.next() && rows.getInt(1) == 3, "evidence writes to its own detail table");
                }
            }
            call(base, "send", TOKEN, send(room, "closed send", "closed-security"), 404);
            var closedEvidence = new java.util.HashMap<>(send(evidence, "closed send", "closed-evidence"));
            closedEvidence.put("review_type", "evidence");
            call(base, "send", TOKEN, closedEvidence, 404);

            for (String type : java.util.List.of("security", "evidence")) {
                String retryRoom = call(base, "continue", TOKEN, Map.of("status", "N", "review_type", type),
                        200).path("room_index").asText();
                var sendRetry = new java.util.HashMap<>(send(retryRoom, "delayed", "timeout-retry"));
                sendRetry.put("review_type", type);
                int before = posts.get();
                var historyRequest = Map.of("room_index", retryRoom, "review_type", type);
                call(base, "send", TOKEN, sendRetry, 504);
                check(call(base, "history", TOKEN, historyRequest, 200).path("messages").isEmpty(),
                        type + " timeout left no partial history");
                call(base, "send", TOKEN, sendRetry, 200);
                check(posts.get() == before + 1, type + " timeout retry reused remote result");
                var finish = Map.of("room_index", retryRoom, "review_type", type, "type", "C");
                badCompletion.set(true);
                call(base, "end", TOKEN, finish, 502);
                check(call(base, "start", TOKEN, Map.of("review_type", type), 200).path("room_index").asText().equals(retryRoom),
                        type + " invalid draft left room active");

                if (jdbc != null) {
                    String table = type.equals("evidence") ? "ai_evidence_review_chat_mst" : "srp_ai_chat_mst";
                    var rollback = new java.util.HashMap<>(send(retryRoom, "rollback", "rollback-retry"));
                    rollback.put("review_type", type);
                    int operations = posts.get();
                    setWriteFailure(jdbc, user, password, table, true);
                    try {
                        call(base, "send", TOKEN, rollback, 500);
                        check(call(base, "history", TOKEN, historyRequest, 200).path("messages").size() == 2,
                                type + " write failure rolled back both detail rows");
                    } finally {
                        setWriteFailure(jdbc, user, password, table, false);
                    }
                    call(base, "send", TOKEN, rollback, 200);
                    check(posts.get() == operations + 1, type + " rollback retry reused remote result");
                    check(call(base, "history", TOKEN, historyRequest, 200).path("messages").size() == 4,
                            type + " exactly one new pair after retry");
                    int finalized = completions.get();
                    setWriteFailure(jdbc, user, password, table, true);
                    try {
                        call(base, "end", TOKEN, finish, 500);
                        check(call(base, "start", TOKEN, Map.of("review_type", type), 200)
                                .path("room_index").asText().equals(retryRoom), type + " terminal write rolled back");
                    } finally {
                        setWriteFailure(jdbc, user, password, table, false);
                    }
                    call(base, "end", TOKEN, finish, 200);
                    check(completions.get() == finalized + 1, type + " completion retry reused remote result");
                } else {
                    call(base, "end", TOKEN, finish, 200);
                }
            }
            if (jdbc != null) {
                verifyEvidenceForeignKeys(jdbc, user, password);
                System.out.println("RESTORE_IDS " + room + " " + evidence);
                System.out.println("PASS: SCRAM test storage, independent evidence foreign keys, rollback and idempotent recovery.");
            }
            var pageResponse = HTTP.send(HttpRequest.newBuilder(base.resolve("/chat")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            check(pageResponse.statusCode() == 200
                    && pageResponse.headers().firstValue("Content-Type").orElse("").contains("UTF-8")
                    && pageResponse.body().contains("Sol AI 챗봇")
                    && pageResponse.body().contains("보안성 검토 신청서 초안")
                    && pageResponse.body().contains("id=\"draft-title\"")
                    && !pageResponse.body().contains("<%@"), "rendered Korean JSP");
            for (String path : List.of("/chat", "/chat/", "/chat/security", "/chat1", "/chat2", "/chat2.jsp", "/securityportal-apis/chat2.jsp")) {
                var response = HTTP.send(HttpRequest.newBuilder(base.resolve(path)).GET().build(),
                        HttpResponse.BodyHandlers.ofString());
                String title = switch (path) {
                    case "/chat1" -> "보안성 검토";
                    case "/chat2" -> "채팅도우미";
                    case "/chat2.jsp", "/securityportal-apis/chat2.jsp" -> "채팅도우미 테스트";
                    default -> "Sol AI 챗봇";
                };
                check(response.statusCode() == 200 && response.body().contains("<h1>" + title + "</h1>")
                                && response.body().contains("id=\"token\"")
                                && response.body().contains("src=\"/chat.js\"")
                                && response.body().contains("data-send-path=\""
                                + ((path.equals("/chat2") || path.endsWith("/chat2.jsp")) ? AiChatController.PORTAL_CHAT2_FULL_PATH : "") + "\""),
                        "chat UI " + path);
            }
            check(HTTP.send(HttpRequest.newBuilder(base.resolve("/WEB-INF/jsp/chat.jsp")).GET().build(),
                    HttpResponse.BodyHandlers.discarding()).statusCode() == 404, "JSP protected path");
            check(HTTP.send(HttpRequest.newBuilder(base.resolve("/chat.js")).GET().build(),
                    HttpResponse.BodyHandlers.ofString()).statusCode() == 200, "UI script");
            System.out.println("PASS: rendered JSP and local HTTP/AI fixture with " +
                    (jdbc == null ? "memory test storage." : "PostgreSQL/MyBatis."));
        } finally {
            if (chatbot != null) chatbot.close();
            ai.stop(0);
        }
    }

    @org.springframework.boot.autoconfigure.EnableAutoConfiguration
    @org.springframework.context.annotation.ComponentScan(basePackageClasses = AiChatController.class)
    static class ExistingHost {}

    private static void verifyHostRegistration() throws Exception {
        try (var host = org.springframework.boot.SpringApplication.run(ExistingHost.class,
                "--server.address=127.0.0.1", "--server.port=0", "--server.servlet.context-path=" + AiChatController.PORTAL_CONTEXT_PATH,
                "--AI_BASE_URL=http://127.0.0.1", "--AI_OPEN_PATH=/fixture/open",
                "--AI_CLOSE_PATH=/fixture/close", "--AI_VISIBILITY=fixture",
                "--CHAT_DB_URL=jdbc:postgresql://127.0.0.1:1/unused", "--CHAT_DB_USER=test",
                "--CHAT_USER_TOKENS_JSON=" + JSON.writeValueAsString(Map.of("EMP1", TOKEN)))) {
            int port = ((ServletWebServerApplicationContext) host).getWebServer().getPort();
            URI base = URI.create("http://127.0.0.1:" + port);
            call(base, AiChatController.PORTAL_CONTEXT_PATH + "/chat/start", "", Map.of(), 401);
            call(base, AiChatController.PORTAL_CHAT2_FULL_PATH, "", Map.of(), 401);
            var page = HTTP.send(HttpRequest.newBuilder(base.resolve("/securityportal-apis/chat2.jsp")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            check(page.statusCode() == 200 && page.body().contains("채팅도우미 테스트")
                    && page.body().contains("src=\"/securityportal-apis/chat.js\"")
                    && page.body().contains("data-send-path=\"/securityportal-apis/chat2/send\""), "host chat2 JSP");
            var script = HTTP.send(HttpRequest.newBuilder(base.resolve(AiChatController.PORTAL_CONTEXT_PATH + "/chat.js")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            check(script.statusCode() == 200 && script.body().contains("chatSendPath"), "host UI script");
            System.out.println("PASS: component-scanned chat routes on the host application's existing listener.");
        }
    }

    private static void verifyHostStartsWithoutChatSettings() throws Exception {
        try (var host = org.springframework.boot.SpringApplication.run(ExistingHost.class,
                "--server.address=127.0.0.1", "--server.port=0", "--AI_BASE_URL=")) {
            int port = ((ServletWebServerApplicationContext) host).getWebServer().getPort();
            URI base = URI.create("http://127.0.0.1:" + port);
            check(call(base, "/securityportal-apis/chat2/send", "", Map.of(), 503)
                    .path("error").asText().contains("configuration"), "chat settings error response");
            check(host.isActive(), "host remains active after chat configuration failure");
            System.out.println("PASS: the host starts and only chat returns 503 with invalid settings.");
        }
    }

    @org.springframework.boot.autoconfigure.EnableAutoConfiguration
    static class TestHost {}

    private static org.springframework.context.ConfigurableApplicationContext startTestHost(AiChatController servlet) {
        var app = new org.springframework.boot.SpringApplication(TestHost.class);
        app.addInitializers(context -> ((org.springframework.context.support.GenericApplicationContext) context)
                .registerBean(AiChatController.class, () -> servlet));
        return app.run("--server.address=127.0.0.1", "--server.port=0",
                "--spring.web.resources.add-mappings=false");
    }

    static void validateLocalDatabase(String jdbc) {
        if (!jdbc.matches("^jdbc:postgresql://(?:127\\.0\\.0\\.1|localhost)(?::[0-9]+)?/[^?,/]+(?:\\?.*)?$")) {
            throw new IllegalArgumentException("Use a dedicated local PostgreSQL URL.");
        }
    }

    static Map<String, Object> helperResponse(Object data) {
        return Map.of("responseAt", "2026-11-19T19:00:00+09:00", "message", "fixture success", "data", data);
    }

    private static void setWriteFailure(String jdbc, String user, String password, String table, boolean enable) throws Exception {
        try (var connection = DriverManager.getConnection(jdbc, user, password);
             var statement = connection.createStatement()) {
            if (enable) {
                statement.execute("CREATE FUNCTION fail_chat_write() RETURNS trigger LANGUAGE plpgsql AS "
                        + "$$ BEGIN RAISE EXCEPTION 'synthetic transaction failure'; END; $$");
                statement.execute("CREATE TRIGGER fail_chat_write BEFORE UPDATE ON " + table
                        + " FOR EACH ROW EXECUTE FUNCTION fail_chat_write()");
            } else {
                statement.execute("DROP TRIGGER fail_chat_write ON " + table);
                statement.execute("DROP FUNCTION fail_chat_write()");
            }
        }
    }

    private static void verifyEvidenceForeignKeys(String jdbc, String user, String password) throws Exception {
        try (var connection = DriverManager.getConnection(jdbc, user, password);
             var statement = connection.createStatement();
             var rows = statement.executeQuery("""
                     SELECT count(*) FROM pg_constraint
                     WHERE contype = 'f'
                       AND conrelid IN ('ai_evidence_review_chat_dtl'::regclass,
                                        'ai_evidence_review_chat_selection'::regclass)
                       AND confrelid = 'ai_evidence_review_chat_mst'::regclass
                     """)) {
            check(rows.next() && rows.getInt(1) == 2, "evidence detail and selection reference only evidence master");
        }
    }

    private static void verifyRestart(String jdbc, String user, String password, String room, String evidenceRoom)
            throws Exception {
        var helper = new AiHelperHttpClient(JSON, URI.create("http://127.0.0.1:1"), "", "/unused/open", "/unused/close",
                request -> { throw new AssertionError("History triggered a remote call"); });
        var store = new PostgresChatStore(jdbc, user, password, JSON, helper, "fixture");
        var evidence = new com.skhynix.hcp.srp.agent.ai.AiEvidenceReviewChat(
                jdbc, user, password, JSON, helper::openSession, "fixture-evidence");
        var servlet = new AiChatController(JSON, store, helper, Map.of("EMP1", TOKEN, "EMP2", OTHER),
                store::ordered, evidence, helper);
        try (var app = startTestHost(servlet)) {
            URI base = URI.create("http://127.0.0.1:" +
                    ((ServletWebServerApplicationContext) app).getWebServer().getPort());
            check(call(base, "list", TOKEN, Map.of(), 200).path("selected_room_index").asText().equals(room),
                    "security selection after full restart");
            check(call(base, "list", TOKEN, Map.of("review_type", "evidence"), 200).path("selected_room_index")
                    .asText().equals(evidenceRoom), "evidence selection after full restart");
            var security = call(base, "history", TOKEN, Map.of("room_index", room), 200).path("messages");
            var reviewEvidence = call(base, "history", TOKEN, Map.of("room_index", evidenceRoom,
                    "review_type", "evidence"), 200).path("messages");
            check(security.size() == 4 && security.get(0).path("message").asText().equals("hello"),
                    "security history after full restart");
            check(reviewEvidence.size() == 2 && reviewEvidence.get(0).path("message").asText().equals("synthetic evidence"),
                    "evidence history after full restart");
            call(base, "history", OTHER, Map.of("room_index", room), 404);
            call(base, "history", OTHER, Map.of("room_index", evidenceRoom, "review_type", "evidence"), 404);
        }
        System.out.println("PASS: both selected IDs, message histories and ownership after app/DB restart.");
    }

    private static String key(com.sun.net.httpserver.HttpExchange exchange) {
        String key = exchange.getRequestHeaders().getFirst("Idempotency-Key");
        check(key != null && key.matches("[a-f0-9]{64}"), "stable idempotency header");
        return key;
    }

    private static String startRoom(URI base, String previous) throws Exception {
        return call(base, "continue", TOKEN, Map.of("room_index", previous, "status", "N"), 200).path("room_index").asText();
    }
    private static Map<String, String> send(String room, String message, String id) {
        return Map.of("room_index", room, "message", message, "chat_index", id, "type", "S");
    }
    private static JsonNode call(URI base, String action, String token, Map<String, ?> data, int expected) throws Exception {
        var result = HTTP.send(request(base, action, token, data), HttpResponse.BodyHandlers.ofString());
        check(result.statusCode() == expected, action + ": expected " + expected + " got " + result.statusCode() + " " + result.body());
        return JSON.readTree(result.body());
    }
    private static HttpRequest request(URI base, String action, String token, Map<String, ?> data) throws Exception {
        return HttpRequest.newBuilder(base.resolve(action.startsWith("/") ? action : "/chat/" + action)).header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(data))).build();
    }
    private static URI url(HttpServer server) { return URI.create("http://127.0.0.1:" + server.getAddress().getPort()); }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static String required(String name) {
        String value = System.getenv(name);
        if (value == null) throw new IllegalArgumentException("Missing " + name);
        return value;
    }
}
