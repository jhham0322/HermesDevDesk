<%@ page session="false" %>
<jsp:forward page="/chat2/test" />
