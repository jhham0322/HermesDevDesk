from pathlib import Path
import os, re, socket, subprocess, tempfile, secrets
from _postgres_windows import password_pipe

project=Path(__file__).resolve().parents[1]
if not (project/"target/ai-chatbot-1.0.13.war").is_file():
    raise SystemExit("Run Maven verify before the isolated PostgreSQL check.")
bin_dir=Path(r"C:\Program Files\PostgreSQL\18\bin")
jdk=Path.home()/".jdk/jdk-21.0.10/bin/java.exe"
scratch=Path(tempfile.mkdtemp(prefix="sol-pg18-",dir=project/"target"))
data=scratch/"data"
db_log=scratch/"postgres.log"
secret=secrets.token_urlsafe(30)
role="sol_isolated_test"
db="sol_isolated"
with socket.socket() as guard:
    guard.bind(("127.0.0.1",0))
    port=guard.getsockname()[1]
assert port!=5432
base_env={k:v for k,v in os.environ.items() if not k.upper().startswith(("PG","CHAT_","AI_","SPRING_","SERVER_")) and k.upper() not in {"JAVA_TOOL_OPTIONS","JDK_JAVA_OPTIONS","_JAVA_OPTIONS"}}
def run(label,args,*,env=base_env,stdin=None,timeout=55):
    opts=({"stdout":subprocess.DEVNULL,"stderr":subprocess.DEVNULL} if label in {"start","restart"} else {"capture_output":True})
    result=subprocess.run([str(a) for a in args],cwd=project,env=env,input=stdin,text=True,encoding="utf-8",errors="replace",timeout=timeout,**opts)
    output=((result.stdout or "")+"\n"+(result.stderr or "")).replace(secret,"<redacted>")
    print(f"{label}: exit {result.returncode}",flush=True)
    for line in output.splitlines():
        if label not in {"integration","restore"} or any(x in line for x in ("PASS:","RESTORE_IDS","Exception","Error","Caused by")):
            if line.strip(): print(line,flush=True)
    if result.returncode: raise RuntimeError(label)
    return result.stdout
pipe_name=password_pipe(secret)
running=False
try:
    run("initdb",[bin_dir/"initdb.exe","-D",data,"-U",role,"-A","scram-sha-256","--pwfile="+pipe_name,"--no-locale",
        "-E","UTF8","--no-sync"])
    rules=(data/"pg_hba.conf").read_text(encoding="utf-8")
    assert "trust" not in " ".join(line for line in rules.splitlines() if not line.lstrip().startswith("#"))
    run("start",[bin_dir/"pg_ctl.exe","-D",data,"-l",db_log,"-o",f"-h 127.0.0.1 -p {port}","-w","-t","15","start"])
    running=True
    env=dict(base_env,PGPASSWORD=secret)
    psql=bin_dir/"psql.exe"
    def sql(query,database="postgres"):
        return run("sql",[psql,"-X","-w","-h","127.0.0.1","-p",port,"-U",role,"-d",database,"-At","-v","ON_ERROR_STOP=1","-c",query],env=env)
    sql("CREATE DATABASE "+db)
    env=dict(base_env,CHAT_TEST_DB_URL=f"jdbc:postgresql://127.0.0.1:{port}/{db}",CHAT_TEST_DB_USER=role,
           CHAT_TEST_DB_PASSWORD=secret,SPRING_CONFIG_LOCATION="optional:classpath:/")
    war_dir=project/"target/ai-chatbot-1.0.13/WEB-INF"
    classpath=os.pathsep.join(map(str, [project/"target/test-classes", war_dir/"classes", war_dir/"lib/*"]))
    java_args=[jdk, "-cp", classpath, "com.skhynix.hcp.srp.agent.ChatIntegrationCheck"]
    schema="chat_test_"+secrets.token_hex(16)
    report=run("integration",java_args+["--keep-isolated",schema],env=env,timeout=90)
    ids=re.search(r"^RESTORE_IDS (\d+) (\d+)$",report,re.M)
    assert ids
    run("restart",[bin_dir/"pg_ctl.exe","-D",data,"-l",db_log,"-o",f"-h 127.0.0.1 -p {port}",
        "-m","fast","-w","-t","15","restart"])
    run("restore",java_args+["--verify-isolated",schema,*ids.groups()],env=env,timeout=45)
finally:
    if running or (data/"postmaster.pid").exists():
        run("stop",[bin_dir/"pg_ctl.exe","-D",data,"-m","fast","-w","-t","15","stop"])
