package com.skhynix.hcp.srp.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.ibatis.exceptions.PersistenceException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.LinkedHashMap;
import java.util.function.BiFunction;
import java.util.function.Supplier;

import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.CHAT2_SEND_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.PORTAL_CHAT2_FULL_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.PORTAL_CHAT2_SEND_PATH;
import static com.skhynix.hcp.srp.agent.AiChatServletConfiguration.PORTAL_CONTEXT_PATH;

final class ChatServlet extends HttpServlet {
    private static final int MAX_REQUEST = 1024 * 1024;
    private final ObjectMapper json;
    private final AiApiService store;
    private final AiApiService evidenceStore;
    private final AiApiService.ClosingHelperClient evidenceHelper;
    private final BiFunction<String, Supplier<Object>, Object> ordered;
    private final AiApiService.ClosingHelperClient helper;
    private final Map<String, String> tokens;

    ChatServlet(ObjectMapper json, AiApiService store, AiApiService.ClosingHelperClient helper,
                Map<String, String> tokens, BiFunction<String, Supplier<Object>, Object> ordered) {
        this(json, store, helper, tokens, ordered, null, null);
    }

    ChatServlet(ObjectMapper json, AiApiService store, AiApiService.ClosingHelperClient helper,
                Map<String, String> tokens, BiFunction<String, Supplier<Object>, Object> ordered,
                AiApiService evidenceStore, AiApiService.ClosingHelperClient evidenceHelper) {
        this.json = json;
        this.evidenceStore = evidenceStore;
        this.evidenceHelper = evidenceHelper;
        this.store = store;
        this.helper = helper;
        this.ordered = ordered;
        this.tokens = Map.copyOf(tokens);
        if (tokens.isEmpty() || new HashSet<>(tokens.values()).size() != tokens.size()
                || tokens.entrySet().stream().anyMatch(e -> e.getKey().isBlank() || e.getValue().length() < 32
                || e.getValue().chars().anyMatch(c -> c <= 32 || c >= 127))) {
            throw new IllegalArgumentException("Configure distinct employee bearer tokens of at least 32 ASCII characters.");
        }
    }

    @Override protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Content-Security-Policy",
                "default-src 'self'; frame-ancestors 'none'; style-src 'self' 'unsafe-inline'");
        String path = request.getRequestURI().substring(request.getContextPath().length());
        if (isChatPage(path) || "/chat.js".equals(path)) {
            staticResource(request, response, path);
            return;
        }
        if (PORTAL_CHAT2_SEND_PATH.equals(path) || PORTAL_CHAT2_FULL_PATH.equals(path)) {
            path = CHAT2_SEND_PATH;
        }
        if (!path.startsWith("/chat/") && !CHAT2_SEND_PATH.equals(path)) {
            respond(response, 404, Map.of("error", "Unknown route."));
            return;
        }
        if (!"POST".equals(request.getMethod())) {
            response.setHeader("Allow", "POST");
            respond(response, 405, Map.of("error", "Use POST."));
            return;
        }
        String actor = authenticate(request);
        if (actor == null) {
            response.setHeader("WWW-Authenticate", "Bearer");
            respond(response, 401, Map.of("error", "Authentication required."));
            return;
        }
        Object result;
        try {
            byte[] body = request.getInputStream().readNBytes(MAX_REQUEST + 1);
            if (body.length > MAX_REQUEST) {
                respond(response, 413, Map.of("error", "Request is too large."));
                return;
            }
            JsonNode input = json.readTree(body);
            if (input == null || !input.isObject()) throw new IllegalArgumentException("Expected a JSON object.");
            String type = text(input, "review_type");
            if (!type.isEmpty() && !"security".equals(type) && !"evidence".equals(type)) {
                throw new IllegalArgumentException("Unknown review type.");
            }
            boolean evidence = "evidence".equals(type);
            if (evidence && evidenceStore == null) {
                throw new IllegalStateException("Security evidence review is available only in the local demo.");
            }
            var chatService = new AiChatService(() -> actor,
                    evidence ? evidenceStore : store, evidence ? evidenceHelper : helper,
                    draft -> {
                        var verified = draftFields(draft, evidence);
                        if (verified.isEmpty()) {
                            throw new AiHelperHttpClient.HelperFailure("AI draft has no valid fields.");
                        }
                        return verified;
                    });
            var controller = new AiChatController(chatService);
            String route = path;
            result = ordered.apply(actor, () -> dispatch(controller, chatService, route, input, evidence));
        } catch (NoSuchElementException e) {
            respond(response, 404, Map.of("error", e.getMessage()));
            return;
        } catch (IllegalArgumentException | com.fasterxml.jackson.core.JsonProcessingException e) {
            respond(response, 400, Map.of("error", "Invalid chat request."));
            return;
        } catch (AiHelperHttpClient.HelperFailure e) {
            respond(response, e.status, Map.of("error", e.getMessage()));
            return;
        } catch (PersistenceException e) {
            System.err.println("Chat database operation failed: " + e.getClass().getSimpleName());
            respond(response, 500, Map.of("error", "Chat database operation failed."));
            return;
        } catch (IllegalStateException e) {
            respond(response, 409, Map.of("error", e.getMessage()));
            return;
        }
        respond(response, 200, result);
    }

    private Object dispatch(AiChatController controller, AiChatService chatService, String path, JsonNode input, boolean evidence) {
        if ("/chat/start".equals(path)) return controller.startChat(null);
        if ("/chat/list".equals(path)) {
            return chatService.listRooms(index(input, "before_room_index"), (int) integer(input, "limit", 30, 100));
        }
        String room = index(input, "room_index");
        return switch (path) {
            case "/chat/history", "/chat/select" -> chatService.readRoom(room,
                    integer(input, "afterSeq", 0, Long.MAX_VALUE), (int) integer(input, "limit", 50, 200),
                    "/chat/select".equals(path));
            case "/chat/continue" -> controller.continueChat(null, room, text(input, "status"),
                    integer(input, "afterSeq", 0, Long.MAX_VALUE), (int) integer(input, "limit", 50, 200));
            case "/chat/send", CHAT2_SEND_PATH -> controller.sendMessage(null, room, text(input, "message"),
                    text(input, "type"), text(input, "chat_index"));
            case "/chat/end" -> localDraft(controller.endChat(null, room, text(input, "type")), evidence);
            default -> throw new NoSuchElementException("Unknown chat route.");
        };
    }

    private AiApiService.ChatEnd localDraft(AiApiService.ChatEnd end, boolean evidence) {
        if (end.status != AiApiService.ChatEndStatus.COMPLETED) return end;
        return new AiApiService.ChatEnd(end.room_index, end.status, draftFields(end.draft, evidence));
    }

    private Map<String, String> draftFields(Object value, boolean evidence) {
        JsonNode draft = json.valueToTree(value);
        var verified = new LinkedHashMap<String, String>();
        if (evidence) {
            copyField(draft, verified, "summary", 2000);
        } else {
            copyField(draft, verified, "title", 120);
            copyField(draft, verified, "description", 2000);
        }
        return verified;
    }

    private static void copyField(JsonNode draft, Map<String, String> verified, String key, int maxLength) {
        JsonNode field = draft.path(key);
        if (!field.isTextual()) return;
        String value = field.textValue().strip();
        if (!value.isEmpty() && value.length() <= maxLength
                && value.chars().noneMatch(c -> Character.isISOControl(c) && c != '\n' && c != '\t')
                && (!"title".equals(key) || value.chars().noneMatch(Character::isISOControl))) {
            verified.put(key, value);
        }
    }

    private String authenticate(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) return null;
        byte[] supplied = header.substring(7).getBytes(StandardCharsets.UTF_8);
        for (var token : tokens.entrySet()) {
            if (MessageDigest.isEqual(token.getValue().getBytes(StandardCharsets.UTF_8), supplied)) {
                return token.getKey();
            }
        }
        return null;
    }

    private static boolean isChatPage(String path) {
        return "/".equals(path) || "/chat".equals(path) || "/chat/".equals(path)
                || "/chat/security".equals(path) || "/chat1".equals(path) || "/chat2".equals(path) || "/chat2.jsp".equals(path);
    }

    private void staticResource(HttpServletRequest request, HttpServletResponse response, String path)
            throws IOException, ServletException {
        if (!"GET".equals(request.getMethod())) {
            response.setHeader("Allow", "GET");
            respond(response, 405, Map.of("error", "Use GET."));
            return;
        }
        if (isChatPage(path)) {
            if ("/chat2".equals(path) || "/chat2.jsp".equals(path)) {
                String context = request.getContextPath();
                String sendPath = context.isEmpty() || PORTAL_CONTEXT_PATH.equals(context)
                        ? PORTAL_CHAT2_FULL_PATH : context + CHAT2_SEND_PATH;
                request.setAttribute("chatSendPath", sendPath);
            }
            request.setAttribute("chatTitle", switch (path) {
                case "/chat1" -> "보안성 검토";
                case "/chat2" -> "채팅도우미";
                case "/chat2.jsp" -> "채팅도우미 테스트";
                default -> "Sol AI 챗봇";
            });
            String view = "/chat2.jsp".equals(path) ? "chat2.jsp" : "chat.jsp";
            request.getRequestDispatcher("/WEB-INF/jsp/" + view).forward(request, response);
            return;
        }
        try (var resource = getClass().getResourceAsStream("/web/chat.js")) {
            if (resource == null) throw new IOException("Missing chat script.");
            byte[] body = resource.readAllBytes();
            response.setContentType("text/javascript; charset=utf-8");
            response.setContentLength(body.length);
            response.getOutputStream().write(body);
        }
    }

    private void respond(HttpServletResponse response, int status, Object value) throws IOException {
        byte[] body = json.writeValueAsBytes(value);
        response.setHeader("Content-Type", "application/json; charset=utf-8");
        response.setStatus(status);
        response.setContentLength(body.length);
        response.getOutputStream().write(body);
    }

    private static String text(JsonNode input, String field) {
        JsonNode value = input.get(field);
        if (value == null || value.isNull()) return "";
        if (!value.isTextual()) throw new IllegalArgumentException("Expected string.");
        return value.textValue();
    }

    private static String index(JsonNode input, String field) {
        String value = text(input, field);
        if (!value.isEmpty()) {
            if (!value.matches("[1-9][0-9]{0,18}")) throw new IllegalArgumentException("Invalid room index.");
            Long.parseLong(value);
        }
        return value;
    }

    private static long integer(JsonNode input, String field, long fallback, long max) {
        JsonNode value = input.get(field);
        if (value == null) return fallback;
        if (!value.isIntegralNumber() || !value.canConvertToLong() || value.longValue() < 0 || value.longValue() > max) {
            throw new IllegalArgumentException("Invalid paging number.");
        }
        return value.longValue();
    }

}
